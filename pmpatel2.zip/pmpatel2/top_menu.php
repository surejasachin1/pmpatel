<ul id="menu_main" class="menu_main_nav">
 <?php
  
   include("functions.php");
 
	$menuListRec=$objFrontMenu->menuCategoryListFront("top");
	for($i=0;$i<count($menuListRec);$i++)
	{ 
		// Menu Link
			
			if($menuListRec[$i]['menuType']==3)
				$link = $menuListRec[$i]['menuUrl'];
			elseif($menuListRec[$i]['menuType']==2)
			{				
				$link = "content.php?id=".$menuListRec[$i]['id'];
			}
		
		// Main menu list
		
		$objFrontMenu->id=$menuListRec[$i]['id'];
		$menucount = $objFrontMenu->menuSubCategoryListFront();	// Submenu List
		
		// Menu item(s)
		?>
          <li class="<? if((count($menucount)>0) ||  $menuListRec[$i]['id']==3 ){ ?>menu-item menu-item-has-children<? } else { ?>menu-item<? } ?>">
			
             <a href="<?=$link;?>" title="<?=$menuListRec[$i]['menuName']; ?>"><?=$menuListRec[$i]['menuName'];?></a> 
         <?	
			
			if(count($menucount)>0)
			{
				
				menuSubMenu($menuListRec[$i]['id']); // Submenu
				
			}

// Category and Products	 

if($menuListRec[$i]['id']==3) { ?>
<ul class="sub-menu">
<?
$Categories = $objProCat->menuCategoryList(); 	 // Main Category List
						
			for($t=0; $t<count($Categories); $t++)
			{									
										
					if(count($Categories)>0)
					{	
						if($Categories[$t]['alias_name']!="")
								$link = $Categories[$t]['alias_name'].".html";
							else
								$link = "content.php?ctid=".$Categories[$t]['id'];					
					
						?>
                        <li class="menu-item"><a href="<?=$link;?>"><?php echo $Categories[$t]['category_name']; ?></a>
                        </li>
                        <? } } ?>
</ul>
<? } ?>
 </li>
		
        
        

  <? 
	 } ?>
  </ul>
						