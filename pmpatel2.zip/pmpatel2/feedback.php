<? include("template.php");
function main()
{ 
	include("sitecontrol/inc/clsObj.php"); 
	$objFrontMenu->id=1;
	$recDet = $objFrontMenu->selectRecById(); 
?>
  <script type="text/javascript">

<!--

function MM_validateForm() { //v4.0

  if (document.getElementById){

    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;

    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);

      if (val) { nm=val.name; if ((val=val.value)!="") {

        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');

          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';

        } else if (test!='R') { num = parseFloat(val);

          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';

          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');

            min=test.substring(8,p); max=test.substring(p+1);

            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';

      } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }

    } if (errors) alert('The following error(s) occurred:\n'+errors);

    document.MM_returnValue = (errors == '');

} }

//-->

</script>


<div class="page_content_wrap">

				

				<section class="grey_section">
					<div class="container">
						<div class="row">
							<div class="sc_contact_form sc_contact_form_standard">
								<h2 class="sc_contact_form_title">Feedback</h2>
								<div class="sc_contact_form contact_form_1">
								   <form action="sendinquiry.php" id="contact-form" method="post" enctype="multipart/form-data" name="inquiryFrm" onsubmit="MM_validateForm('name','','R','email','','RisEmail','num','','R','Code','','R');return document.MM_returnValue">
								        <div class="sc_contact_form_info">
											<div class="sc_contact_form_item sc_contact_form_field label_over">
								                <input type="text" name="name" id="name" placeholder="Name *">
								            </div>
								            <div class="sc_contact_form_item sc_contact_form_field label_over">
								                <input type="text" name="email" id="email" placeholder="Email *">
								            </div>
								            <div class="sc_contact_form_item sc_contact_form_field label_over">
								                <input type="text" name="num" id="num" placeholder="Phone Number">
								            </div>
								        </div>
								       
                                        
                                        <div class="sc_contact_form_info">
											
                 
											
                                             <div class="message sc_contact_form_item sc_contact_form_message label_over">
								            <textarea  id="message" class="textAreaSize" name="message" placeholder="Feedback "></textarea>
								        </div>
                                            <div class="sc_contact_form_item sc_contact_form_field label_over">
								                <input type="text" name="Code" id="Code" placeholder="Code *">
								            </div>
                                            <div class="sc_contact_form_item sc_contact_form_field label_over">
                                            <img src="captcha.php" style="margin: 8px;">
                                            </div>
                                            </div>
										<div class="sc_contact_form_item sc_contact_form_button">
											<div class="squareButton sc_button_size sc_button_style_global global">
												<input type="submit" name="feedback_submit" class="buttons" data-text="Send Message" value="Send Message">
											</div>
										</div>

								        <div class="result sc_infobox"></div>
								    </form>
								</div> 
							</div>
						</div>
				
            
        	
	</div>
				</section>
			</div>
            
            
    
<? } ?>