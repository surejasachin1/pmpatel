<div class="page_top_wrap page_top_title page_top_breadcrumbs">
  <div class="content_wrap">
    <div class="breadcrumbs"> <a class="breadcrumbs_item home" href="index.php">Home</a> <span class="breadcrumbs_delimiter"></span> <span class="breadcrumbs_item current">Services</span> </div>
    <h2 class="page_title"><? echo $category[0]['category_name'];?></h2>
  </div>
</div>
<div class="page_content_wrap">
  <div class="content_wrap">
    <div class="content">
      <article class="post_item post_item_single page">
        <section class="post_content">
          <div>
            <figure class="sc_image alignleft middle sc_image_shape_square title_approve ">
              <div> <img src="<?=CATEGORY_SMALL_IMAGE.$category[0]['image'];?>" alt=""> </div>
              <figcaption> <span></span> <? echo $category[0]['category_name'];?> </figcaption>
            </figure>
            <? echo $category[0]['description']; ?> </div>
        </section>
      </article>
    </div>
    <div class="sidebar widget_area bg_tint_light sidebar_style_light" role="complementary">
      <aside class="widget widget_categories">
        <h5 class="widget_title">Services</h5>
        <ul>
          <? $Categories = $objProCat->menuCategoryList(); 	 // Main Category List
						
			for($t=0; $t<count($Categories); $t++)
			{									
										
					if(count($Categories)>0)
					{	
						if($Categories[$t]['alias_name']!="")
								$link = $Categories[$t]['alias_name'].".html";
							else
								$link = "content.php?ctid=".$Categories[$t]['id'];					
					
						?>
          <li class="cat-item"> <a title="" href="<?=$link;?>">
            <?=$Categories[$t]['category_name'];?>
            </a> </li>
          <? }  }?>
        </ul>
      </aside>
    </div>
  </div>
</div>
