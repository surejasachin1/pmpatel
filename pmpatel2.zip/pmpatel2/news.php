<? include("template.php");
function main()
{ 
	include("sitecontrol/inc/clsObj.php"); 
	$objFrontMenu->id=1;
	$recDet = $objFrontMenu->selectRecById(); 
?>
  

<div class="page_top_wrap page_top_title page_top_breadcrumbs">
				<div class="content_wrap">
					<div class="breadcrumbs">
						<a class="breadcrumbs_item home" href="index1.php">Home</a>
						<span class="breadcrumbs_delimiter"></span>
						<span class="breadcrumbs_item current">News</span>
					</div>
					<h1 class="page_title">News </h1>
				</div>
			</div>
<div class="page_content_wrap">
				<div class="content_wrap">
					<div class="content">
						<? $news=$objTest1->select(); 
						for($i=0; $i<count($news); $i++){
						?>
						<article class="post_item post_item_excerpt post has-post-thumbnail">
							
							<div class="post_content clearfix">
								<h3 class="post_title">
								<a href="#" title="Ten Facts You Might Not Know About Stamp Duty">
									<span class="post_icon icon-book-2"> </span>
							<?=$news[$i]['name'];?>
								</h3>
								<div class="post_info">
									<span class="post_info_item post_info_posted">
										<a href="#" class="post_info_date" title="May 21, 2015">May 21, 2015</a>
									</span>
								</div>
								<div class="post_descr">
                               <div class="columns_wrap custom_columns">
									
                                    <div class="column-1_2">
									<div class="post_featured">
													<div class="post_thumb" data-image="<?=PRODUCT_BIG_IMAGE.$news[$i]['image'];?>" data-title="Find The Perfect Accountant For You">
														<a class="hover_icon_link" href="#" title="">
															<img alt="Find The Perfect Accountant For You" src="<?=PRODUCT_BIG_IMAGE.$news[$i]['image'];?>">
															<div class="img-hover">
																<span class="hover_icon"> </span>
															</div>
														</a>
													</div>
												</div>
                                                
                                    </div>
                                    <div class="column-1_2">
									<p>
									<?=$news[$i]['description'];?></p>
                                    
                                    </div>
                                    </div>
                                    
									
								</div>
							</div>
						</article>
						<? } ?>
						
						
						
						
						
						

					</div>
					<div class="sidebar widget_area bg_tint_light sidebar_style_light" role="complementary">
                    <aside class="widget widget_categories">
							<h5 class="widget_title">Categories dropdown</h5>
							<label class="screen-reader-text" for="cat">Categories dropdown</label>
							<select name="cat" id="cat" class="postform">
								<option value="-1">Select Category</option>
								<option class="level-0" value="13">Accounting</option>
								<option class="level-0" value="12">Corporate Finances</option>
								<option class="level-0" value="10">Finances</option>
								<option class="level-0" value="48">Gallery</option>
								<option class="level-0" value="15">Images</option>
								<option class="level-0" value="14">Investments</option>
								<option class="level-0" value="8">Most Popular</option>
								<option class="level-0" value="11">Our Blog</option>
								<option class="level-0" value="7">Page</option>
								<option class="level-0" value="70">Post Formats</option>
								<option class="level-0" value="71">Post Formats with Sidebar</option>
								<option class="level-0" value="69">Sample Post</option>
								<option class="level-0" value="1">Uncategorized</option>
							</select>
						</aside>
						<aside class="widget widget_categories">
							<h5 class="widget_title">Categories</h5>
							<ul>
								<li class="cat-item">
									<a href="#" title="Accounting">Accounting</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Corporate Finances">Corporate Finances</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Finances">Finances</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Gallery">Gallery</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Images">Images</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Investments">Investments</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Most Popular">Most Popular</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Our Blog">Our Blog</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Page">Page</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Post Formats">Post Formats</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Post Formats with Sidebar">Post Formats with Sidebar</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Sample Post">Sample Post</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Uncategorized">Uncategorized</a>
								</li>
							</ul>
						</aside>
						
						<aside class="widget widget_meta">
							<h5 class="widget_title">Meta</h5>
							<ul>
								<li>
									<a href="#" title="Log in">Log in</a>
								</li>
								<li>
									<a href="#" title="Entries RSS">Entries RSS
									</a>
								</li>
								<li>
									<a href="#" title="Comments RSS">Comments RSS
									</a>
								</li>
							</ul>
						</aside>
						<aside class="widget widget_archive">
							<h5 class="widget_title">Archives</h5>
							<ul>
								<li>
									<a href="#" title="June 2015">June
										<span>2015</span>
									</a>
								</li>
								<li>
									<a href="#" title="May 2015">May
										<span>2015</span>
									</a>
								</li>
								<li>
									<a href="#" title="April 2015">April
										<span>2015</span>
									</a>
								</li>
								<li>
									<a href="#" title="March 2015">March
										<span>2015</span>
									</a>
								</li>
							</ul>
						</aside>
						
						
						
						
						
						<aside class="widget widget_tag_cloud">
							<h5 class="widget_title">Tags</h5>
							<div class="tagcloud">
								<a href="#" title="account">account</a>
								<a href="#" title="accounting">accounting</a>
								<a href="#" title="advising">advising</a>
								<a href="#" title="advisory">advisory</a>
								<a href="#" title="business">business</a>
								<a href="#" title="calculations">calculations</a>
								<a href="#" title="family">family</a>
								<a href="#" title="finance">finance</a>
								<a href="#" title="investments">investments</a>

								<a href="#" title="money">money</a>
								<a href="#" title="pension">pension</a>
								<a href="#" title="reports">reports</a>
								<a href="#" title="sample tag">sample tag</a>
							</div>
						</aside>
					</div>
				</div>
			</div>
            
            
    
<? } ?>