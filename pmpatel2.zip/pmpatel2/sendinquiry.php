<?php
session_start();

//echo $_POST['Code']." ".$_SESSION['cap_code'];exit;
include("sitecontrol/inc/fileInclude.php");
include("sitecontrol/inc/clsObj.php");
$cap = 'notEq';
if($_POST['feedback_submit']!='') {
$checked_arr = $_POST['services'];
$count = count($checked_arr);
if($count==0){
			$_SESSION['enquiry'] = $_POST;
	$cap  = '<script type="text/javascript">';
	$cap .= 'alert("Please Select Atleast One Service");';
	$cap .= 'document.location="content.php?id=22";';
	$cap .= '</script>';
	echo $cap; 
	}
if($_POST['Code']==$_SESSION['cap_code']) {
	// Captcha verification is Correct. Do something here!
	$cap = 'Eq';
}else{
	// Captcha verification is wrong. Take other action
	$_SESSION['enquiry'] = $_POST;
	$cap  = '<script type="text/javascript">';
	$cap .= 'alert("You have enter invalid security code.");';
	$cap .= 'document.location="feedback.php";';
	$cap .= '</script>';
	echo $cap; 
}

extract($_REQUEST);
$obj_admin->id=1;
$recAdmin=$obj_admin->selectRecById();
$msg='
<TABLE cellpadding=5 cellspacing="7" width=700 align=left border=1  bordercolor="#CCCCCC" style="border-collapse:collapse;">
		<TBODY>
        	<TR>
            	<TD>Name : </TD>
				<TD colspan=3>'.$_POST['name'].'</td> 
			</TR>
			<TR>
            	<TD>Email : </TD>
				<TD colspan=3>'.$_POST['email'].'</td> 
			</TR>

			<TR>
            	<TD>Contact Number: </TD>
				<TD colspan=3>'.$_POST['num'].'</td> 
			</TR>
		
			<TR>
            	<TD>Message : </TD>
				<TD colspan=3>'.$_POST['message'].'</td> 
			</TR>
			<TR>
            	<TD>Post : </TD>
				<TD colspan=3>'.implode(",",$_POST['services']).'</td> 
			</TR>
      </TBODY>
      </TABLE>
';


$to = $recAdmin[0]['adminEmail'];
$from = "info@imagewebsolution.com";



if($cap=="Eq"){
	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	//$headers .= "To:$to\r\n";
	$headers .= "From:".$from." \r\n";
	
	unset($_SESSION['enquiry']);
	
	mail($to,"Online Inquiry from : ".$form,$msg,$headers);
	
	//echo $msg;
}
}
elseif($_POST['career_submit']!='') {
if($_POST['Code']==$_SESSION['cap_code']) {
	// Captcha verification is Correct. Do something here!
	$cap = 'Eq';
}else{
	// Captcha verification is wrong. Take other action
	$_SESSION['enquiry'] = $_POST;
	$cap  = '<script type="text/javascript">';
	$cap .= 'alert("You have enter invalid security code.");';
	$cap .= 'document.location="career.php";';
	$cap .= '</script>';
	echo $cap; 
}

extract($_REQUEST);
$obj_admin->id=1;
$recAdmin=$obj_admin->selectRecById();
$msg='
<TABLE cellpadding=5 cellspacing="7" width=700 align=left border=1  bordercolor="#CCCCCC" style="border-collapse:collapse;">
		<TBODY>
        	<TR>
            	<TD>Name : </TD>
				<TD colspan=3>'.$_POST['name'].'</td> 
			</TR>
			<TR>
            	<TD>Email : </TD>
				<TD colspan=3>'.$_POST['email'].'</td> 
			</TR>

			<TR>
            	<TD>Contact Number: </TD>
				<TD colspan=3>'.$_POST['num'].'</td> 
			</TR>
		
			<TR>
            	<TD>Message : </TD>
				<TD colspan=3>'.$_POST['message'].'</td> 
			</TR>
			<TR>
            	<TD>Post : </TD>
				<TD colspan=3>'.$_POST['post'].'</td> 
			</TR>
			<TR>
            	<TD>Qualification : </TD>
				<TD colspan=3>'.$_POST['qualification'].'</td> 
			</TR>
      </TBODY>
      </TABLE>
';


$to = $recAdmin[0]['adminEmail'];
$from = "info@imagewebsolution.com";



if($cap=="Eq"){
	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	//$headers .= "To:$to\r\n";
	$headers .= "From:".$from." \r\n";
	
	unset($_SESSION['enquiry']);
	
	mail($to,"Online Career from : ".$form,$msg,$headers);
	
	echo $msg;
}
}
else {
	$checked_arr = $_POST['services'];
$count = count($checked_arr);
if($count==0){
			$_SESSION['enquiry'] = $_POST;
	$cap  = '<script type="text/javascript">';
	$cap .= 'alert("Please Select Atleast One Service");';
	$cap .= 'document.location="contact.php";';
	$cap .= '</script>';
	echo $cap; 
	}
if($_POST['Code']==$_SESSION['cap_code']) {
	// Captcha verification is Correct. Do something here!
	$cap = 'Eq';
}else{
	// Captcha verification is wrong. Take other action
	$_SESSION['enquiry'] = $_POST;
	$cap  = '<script type="text/javascript">';
	$cap .= 'alert("You have enter invalid security code.");';
	$cap .= 'document.location="contact.php";';
	$cap .= '</script>';
	echo $cap; 
}

extract($_REQUEST);
$obj_admin->id=1;
$recAdmin=$obj_admin->selectRecById();
$msg='
<TABLE cellpadding=5 cellspacing="7" width=700 align=left border=1  bordercolor="#CCCCCC" style="border-collapse:collapse;">
		<TBODY>
        	<TR>
            	<TD>Name : </TD>
				<TD colspan=3>'.$_POST['name'].'</td> 
			</TR>
			<TR>
            	<TD>Email : </TD>
				<TD colspan=3>'.$_POST['email'].'</td> 
			</TR>

			<TR>
            	<TD>Contact Number: </TD>
				<TD colspan=3>'.$_POST['num'].'</td> 
			</TR>
		
			<TR>
            	<TD>Message : </TD>
				<TD colspan=3>'.$_POST['message'].'</td> 
			</TR>
			<TR>
            	<TD>Services : </TD>
				<TD colspan=3>'.implode(",",$_POST['services']).'</td> 
			</TR>
      </TBODY>
      </TABLE>
';


$to = $recAdmin[0]['adminEmail'];
$from = "info@imagewebsolution.com";



if($cap=="Eq"){
	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	//$headers .= "To:$to\r\n";
	$headers .= "From:".$from." \r\n";
	
	unset($_SESSION['enquiry']);
	
	mail($to,"Online Inquiry from : ".$form,$msg,$headers);
	
	//echo $msg;
}
}
?>

<script type="text/javascript">   

   alert("Thank you for sending your inquiry")

   document.location="index1.php";

</script>