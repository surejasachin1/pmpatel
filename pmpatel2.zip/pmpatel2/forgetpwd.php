<link rel="stylesheet" type="text/css" href="css/style.css">
<span class="frgtpwd">Forget Password</span>
<div class="frgtpwd">
	Enter Your Email ID:
	<form method="post">
		
	<input type="text" name="frgtpwd"/>
	<input type="submit" name="submit" value="submit">
	</form>
</div>
<?php
$conn = new mysqli("localhost","root","","imagein_pmp");
$sql = "SELECT email,password FROM event ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
	 $result->num_rows;
    // output data of each row
while($row = $result->fetch_assoc()) {
		$allemail[] = $row['email'];
	}
}
if (isset($_POST['frgtpwd'])) {
	$Email = $_POST['frgtpwd'];
	if(in_array($Email, $allemail)){
		$randomstr = substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', mt_rand(1,10))),1,10);

		$sql1 = "UPDATE event SET password ='".$randomstr."' where email = '".$Email."'";
		$success = $conn->query($sql1);	
		if($success){
			$to = $Email;
			$subject = "Password Reset From PMPATEL";
			$txt = "Thank you for being with us. Your new Password is ".$randomstr;
			$headers = "From: webmaster@example.com" . "\r\n";

			mail($to,$subject,$txt,$headers);
			echo "<script>alert('New Password sent to ".$Email."')</script>";
		}
	}else{
		echo "<script>alert('This is not a valid email ID')</script>";
	}
}
?>