<? session_start();
include('config.php');
if($_SESSION['username']!=''){
// echo $_SESSION['username'];  exit; 
	if(isset($_POST['send_comment'])){
		$pid=$_POST['id'];
		$name=$_POST['author'];
		$email=$_POST['email'];
		$comment=$_POST['comment'];
		$sql=mysqli_query($con,"insert into blog_comment(img_id,product_id,name,comment,email) VALUE('','$pid','$name','$comment','$email')");
		echo "<script type='text/javascript'>window.location='index1.php';</script>";
	}
}
else {
echo "<script type='text/javascript'> alert('For Add Comment Please Login');
				window.location='knwclientlogin.php';</script>";
}