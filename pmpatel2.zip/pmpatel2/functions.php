<?

// Menu Products

 function menuSubProducts($cid){
 
 include("sitecontrol/inc/clsObj.php"); 

$objProduct->catid=$cid;
$Products=$objProduct->selectRecByCategoryId();


		if(count($Products)>0){
	 ?>
											<ul >
    <?
                            for($j=0; $j<count($Products); $j++)
                            {
                                if($Products[$j]['alias_name']!="")
                                    $link =  $Products[$j]['alias_name'].".html";
                                else
                                    $link = "content.php?pid=".$Products[$j]['id'];
                            
                                ?>
    <li><a href="<?php echo $link; ?>" ><?php echo $Products[$j]['product_name']; ?></a> </li>
    <? 
			  
			  		
			  } ?>
  </ul>
  <?
		}
 }
 
 function menuFirstLevel($cid){
 
 include("sitecontrol/inc/clsObj.php"); 
 
$objProduct->catid=$cid;
$Products=$objProduct->selectRecByCategoryId();

		if(count($Products)>0){
	 ?>
  <?
                            for($j=0; $j<count($Products); $j++)
                            {
                                if($Products[$j]['alias_name']!="")
                                    $link =  $Products[$j]['alias_name'].".html";
                                else
                                    $link = "content.php?pid=".$Products[$j]['id'];
                            
                                ?>
  <li><a href="<?php echo $link; ?>" ><?php echo $Products[$j]['product_name']; ?></a> </li>
  <? 
			  
			  		
			  } ?>
  <?
		}
 }
 
 function menuSubCat($cid){
 
// echo "tushar".$cid; exit;
 include("sitecontrol/inc/clsObj.php"); 
 
 $objProCat->id=$cid;
 $SubCats=$objProCat->menuSubCategoryListFront();
		
		if(count($SubCats)>0){
	 ?>
  <ul id="productMenu">
    <?
                            for($k=0; $k<count($SubCats); $k++)
                            {
                                if($SubCats[$k]['alias_name']!="")
                                    $link =  $SubCats[$k]['alias_name'].".html";
                                else
                                    $link = "content.php?ctid=".$SubCats[$k]['id'];
                            
                                ?>
    <li><a href="<?php echo $link; ?>" ><?php echo $SubCats[$k]['category_name']; ?></a>
      <? 
			  		menuSubCat($SubCats[$k]['id']);
					if(PRODUCT_MODE<5){
					menuSubProducts($SubCats[$k]['id']);
					}
			  ?>
    </li>
    <? 		
					
			  		
			  }
			  if(PRODUCT_MODE<5){
			  			menuFirstLevel($cid);
					}
			   ?>
  </ul>
  <?
		}
 }
 
 



// Code for pages

function subProducts($cid){
 
 include("sitecontrol/inc/clsObj.php"); 
 
$cidd = explode("?",$cid);

$cid = $cidd[0];

$objProduct->catid=$cid;
$Products=$objProduct->selectRecByCategoryId();



		if(count($Products)>0){
		
		 if((basename($_SERVER['PHP_SELF'])=='products.php' && (PRODUCT_MODE<5 || PRODUCT_MODE==8 || PRODUCT_MODE==9) ) || basename($_SERVER['PHP_SELF'])=='sitemap.php'){
		 
		 	?>
            <table style="padding-left:50px;">
  <?
                            for($j=0; $j<count($Products); $j++)
                            {
                                if($Products[$j]['alias_name']!="")
                                    $link =  $Products[$j]['alias_name'].".html";
                                else
                                    $link = "content.php?pid=".$Products[$j]['id'];
                            
                               include("general.php");
							    } ?>
</table>
            <?
		 }else{
		$objProduct->limit = PRODUCT_LIMIT;
		$sql = "select * from products where status=1 and catid='".$cid."'";
		$Products = $objProduct->pagingFrontQuery($sql);
	 ?>

<table  width="100%">
<tr>
	<td>
  <?
                            for($j=0; $j<count($Products); $j++)
                            {
                                if($Products[$j]['alias_name']!="")
                                    $link =  $Products[$j]['alias_name'].".html";
                                else
                                    $link = "content.php?pid=".$Products[$j]['id'];
									
									
									$imglist = $objProduct->getImages($Products[$j]['id']);
                            
							if(PRODUCT_MODE<5){
								include("general.php");
								
							}elseif(PRODUCT_MODE==5){
								include("mode5.php");
							}
							elseif(PRODUCT_MODE==6){
								include("mode6.php");
							}
							elseif(PRODUCT_MODE==7){
								include("mode7.php");
							}
							elseif(PRODUCT_MODE==8){
								include("mode8.php");
							}
							elseif(PRODUCT_MODE==9){
								include("mode9.php");
							}
							
                                ?>
  
  <? }
  
  if(count($cidd)>1 ){

  }else{
  $pagination = 'yes';
  
   ?>
  </td>
</tr>
   <tr>
      <td style="text-align:center;" ><?php echo $objProduct->pagination; ?></td>
    </tr>
    
    <? } ?>
</table>
<?
			}
		}
 }
 

 function subCat($cid){
 
// echo "tushar".$cid; exit;
 include("sitecontrol/inc/clsObj.php"); 
 
 $objProCat->id=$cid;
 $SubCats=$objProCat->menuSubCategoryList();
		
		if(count($SubCats)>0){
	 ?>
<table style="margin-left:45px;" width="95%">
  <?
                            for($k=0; $k<count($SubCats); $k++)
                            {
                                if($SubCats[$k]['alias_name']!="")
                                    $link =  $SubCats[$k]['alias_name'].".html";
                                else
                                    $link = "content.php?ctid=".$SubCats[$k]['id'];
                            
                                ?>
<tr>
    <td style="margin-left:25px!important;"><img src="images/contactus/sitearrow.png" /><a href="<?php echo $link; ?>" >
      <?=$SubCats[$k]['category_name'];?>
      </a>
      <? subCat($SubCats[$k]['id']);
						//	subProducts($SubCats[$k]['id']."?subcat=1");
			 			 ?>
    </td>
  </tr>
  <? //level11($cid);
			    } 
				
				?>
</table>
<?
		}
		firstLevel($cid);
 }
 
 
 
 function firstLevel($cid){
// echo PRODUCT_MODE; exit;
 
 include("sitecontrol/inc/clsObj.php"); 
 
$objProduct->catid=$cid;
$Products=$objProduct->selectRecByCategoryId();

	


		if(count($Products)>0){
		
		 if((basename($_SERVER['PHP_SELF'])=='products.php' && (PRODUCT_MODE<5 || PRODUCT_MODE==8 || PRODUCT_MODE==9) ) || basename($_SERVER['PHP_SELF'])=='sitemap.php'){
		 
		 	?>
            <table style="padding-left:20px;">
  <?
                            for($j=0; $j<count($Products); $j++)
                            {
                                if($Products[$j]['alias_name']!="")
                                    $link =  $Products[$j]['alias_name'].".html";
                                else
                                    $link = "content.php?pid=".$Products[$j]['id'];
                            
                               include("general.php");
							    } ?>
</table>
            <?
		 }else{
		$objProduct->limit = PRODUCT_LIMIT;
		$sql = "select * from products where status=1 and catid='".$cid."'";
		$Products = $objProduct->pagingFrontQuery($sql);
	 ?>

<table style="padding-left:50px;"  width="100%">
<tr>
	<td>
  <?
                            for($j=0; $j<count($Products); $j++)
                            {
                                if($Products[$j]['alias_name']!="")
                                    $link =  $Products[$j]['alias_name'].".html";
                                else
                                    $link = "content.php?pid=".$Products[$j]['id'];
									
									
									$imglist = $objProduct->getImages($Products[$j]['id']);
                            
                                ?>
  
  <? }
  
  if(count($cidd)>1 ){

  }else{
  $pagination = 'yes';
  
   ?>
  </td>
</tr>
   <tr>
      <td style="text-align:center;" ><?php echo $objProduct->pagination; ?></td>
    </tr>
    
    <? } ?>
</table>
<?
			}
		}
 
		
 }
 
 // Code for Submenu
 
	function menuSubMenu($id)
	{
 		include("sitecontrol/inc/clsObj.php");  	
 	?>
  	<ul class="sub-menu">
    <?
					$objFrontMenu->id=$id;
					$submenu=$objFrontMenu->menuSubCategoryList(); 					
					
					for($k=0; $k<count($submenu); $k++)
					{
						
						if($submenu[$k]['menuType']==3)
							$link = $submenu[$k]['menuUrl'];
						elseif($submenu[$k]['menuType']==2)
						{				
							$link = "content.php?id=".$submenu[$k]['id'];
						}
	?>
    <li class="menu-item"><a href="<?=$link;?>">
      <?=$submenu[$k]['menuName'];?>
      </a>
      <?
						$objFrontMenu->id=$submenu[$k]['id'];
						$menucount = $objFrontMenu->menuSubCategoryList();
						
						if(count($menucount)>0)
						{
							menuSubMenu($submenu[$k]['id']); echo $submenu[$k]['id'];
						}
						?>
    </li>
    <?
					}	?>
  </ul>
  <?	} 
  
  // Code for Submenu
 
  function rootLevelProduct(){
 
 include("sitecontrol/inc/clsObj.php"); 
 
$Products = $objProduct->selectRootProduct(); 

		if(count($Products)>0){
		
		 if((basename($_SERVER['PHP_SELF'])=='products.php' && (PRODUCT_MODE<5 || PRODUCT_MODE==8 || PRODUCT_MODE==9) ) || basename($_SERVER['PHP_SELF'])=='sitemap.php'){
		 
		 	?>
            <table style="margin-left:50px;">
  <?
                            for($j=0; $j<count($Products); $j++)
                            {
                                if($Products[$j]['alias_name']!="")
                                    $link =  $Products[$j]['alias_name'].".html";
                                else
                                    $link = "content.php?pid=".$Products[$j]['id'];
                            
                               include("general.php");
							    } ?>
</table>
            <?
		 }else{
		$objProduct->limit = PRODUCT_LIMIT;
		$sql = "select * from products where status=1 and catid='".$cid."'";
		$Products = $objProduct->pagingFrontQuery($sql);
	 ?>

<table  width="100%">
<tr>
	<td>
  <?
                            for($j=0; $j<count($Products); $j++)
                            {
                                if($Products[$j]['alias_name']!="")
                                    $link =  $Products[$j]['alias_name'].".html";
                                else
                                    $link = "content.php?pid=".$Products[$j]['id'];
									
									
									$imglist = $objProduct->getImages($Products[$j]['id']);
                            
							if(PRODUCT_MODE<5){
								include("general.php");
								
							}elseif(PRODUCT_MODE==5){
								include("mode5.php");
							}
							elseif(PRODUCT_MODE==6){
								include("mode6.php");
							}
							elseif(PRODUCT_MODE==7){
								include("mode7.php");
							}
							elseif(PRODUCT_MODE==8){
								include("mode8.php");
							}
							elseif(PRODUCT_MODE==9){
								include("mode9.php");
							}
							
                                ?>
  
  <? }
  
  if(count($cidd)>1 ){

  }else{
  $pagination = 'yes';
  
   ?>
  </td>
</tr>
   <tr>
      <td style="text-align:center;" ><?php echo $objProduct->pagination; ?></td>
    </tr>
    
    <? } ?>
</table>
<?
			}
		}
 
		
 }
				?>
				