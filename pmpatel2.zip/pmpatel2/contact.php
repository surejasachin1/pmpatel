<? include("template.php");
function main()
{ 
	include("sitecontrol/inc/clsObj.php"); 
	$objFrontMenu->id=1;
	$recDet = $objFrontMenu->selectRecById(); 
?>
  <script type="text/javascript">

<!--

function MM_validateForm() { //v4.0

  if (document.getElementById){

    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;

    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);

      if (val) { nm=val.name; if ((val=val.value)!="") {

        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');

          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';

        } else if (test!='R') { num = parseFloat(val);

          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';

          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');

            min=test.substring(8,p); max=test.substring(p+1);

            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';

      } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }

    } if (errors) alert('The following error(s) occurred:\n'+errors);

    document.MM_returnValue = (errors == '');

} }

//-->

</script>


<div class="page_content_wrap">

				<section class="">
					<div class="container">
						<div class="row">
							<div class="content_wrap" data-animation="animated fadeInUp normal">
								<div class="columns_wrap sc_columns aligncenter">
									<div class="column-1_3 sc_column_item">
										<span class="sc_icon style_2 icon-email2 sc_icon_shape_none sc_icon_bg_custom link_color"></span>
										<div class="margin_top_mini">
											<p>
												<a href="mailto:rahul@pmpatel.com">rahul@pmpatel.com</a>
												<br/>
												<a href="http://www.yoursite.com">www.pmpatel.com</a>
											</p>
										</div>
									</div><div class="column-1_3 sc_column_item">
										<span class="sc_icon style_2 icon-telephone sc_icon_shape_none sc_icon_bg_custom link_color"> </span>
										<div class="margin_top_mini">
											<p>+91-79-26420068<br/>
											079 26426466</p>
										</div>
									</div><div class="column-1_3 sc_column_item">
										<span class="sc_icon style_2 icon-location-1 sc_icon_shape_none sc_icon_bg_custom link_color"> </span>
										<div class="margin_top_mini">
											<p>First Floor,Sutaria Complex,Maharashtra Society, <br/>
											Mithakhali, Ahmedabad - 380009.</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

				<section class="grey_section">
					<div class="container">
						<div class="row">
							<div class="sc_contact_form sc_contact_form_standard">
								<h2 class="sc_contact_form_title">Inquiry</h2>
								<div class="sc_contact_form contact_form_1">
								   <form action="sendinquiry.php" id="contact-form" method="post" enctype="multipart/form-data" name="inquiryFrm" onsubmit="MM_validateForm('name','','R','email','','RisEmail','num','','R','Code','','R');return document.MM_returnValue">
								        <div class="sc_contact_form_info">
											<div class="sc_contact_form_item sc_contact_form_field label_over">
								                <input type="text" name="name" id="name" placeholder="Name *">
								            </div>
								            <div class="sc_contact_form_item sc_contact_form_field label_over">
								                <input type="text" name="email" id="email" placeholder="Email *">
								            </div>
								            <div class="sc_contact_form_item sc_contact_form_field label_over">
								                <input type="text" name="num" id="num" placeholder="Phone Number">
								            </div>
								        </div>
								       
                                        
                                        <div class="sc_contact_form_info">
											
                                           <strong>Services</strong>
                                      <div class="row">
                                     
                                       <div class="column-1_3">
      <label> <input type="checkbox" name="services[]" id="services[]" value="Direct Taxes"  > Direct Taxes</label><br />
      <label> <input type="checkbox" name="services[]" id="services[]" value="Auditing and Assurance"  > Auditing and Assurance</label><br />
      <label> <input type="checkbox" name="services[]" id="services[]" value="Management Consultancy"  > Management Consultancy</label><br />
  <label> <input type="checkbox" name="services[]" id="services[]" value="Financial Consultancy"  > Financial Consultancy</label>                                      </div>
                                       <div class="column-1_3">
                                       
      <label> <input type="checkbox" name="services[]" id="services[]" value="International Transactions Advisory"  > International Transactions Advisory</label><br />
      <label> <input type="checkbox" name="services[]" id="services[]" value="Indirect Taxes"  > Indirect Taxes</label><br />
      <label> <input type="checkbox" name="services[]" id="services[]" value="Risk Assessment and Advisory"  > Risk Assessment and Advisory</label>                              
                                         </div>
                                          <div class="column-1_3">
        <label> <input type="checkbox" name="services[]" id="services[]" value="Legal Consultancy"  >Legal Consultancy</label><br />
      <label> <input type="checkbox" name="services[]" id="services[]" value="Support and Training"  > Support and Training</label><br />
      <label> <input type="checkbox" name="services[]" id="services[]" value="Cyber Security Advisory"  > Cyber Security Advisory</label>                                     
                                           </div>
            </div><br/>
											
                                             <div class="message sc_contact_form_item sc_contact_form_message label_over">
								            <textarea  id="message" class="textAreaSize" name="message" placeholder="Message "></textarea>
								        </div>
                                            <div class="sc_contact_form_item sc_contact_form_field label_over">
								                <input type="text" name="Code" id="Code" placeholder="Code *">
								            </div>
                                            <div class="sc_contact_form_item sc_contact_form_field label_over">
                                            <img src="captcha.php" style="margin: 8px;">
                                            </div>
                                            </div>
										<div class="sc_contact_form_item sc_contact_form_button">
											<div class="squareButton sc_button_size sc_button_style_global global">
												<button type="submit" name="contact_submit" class="sc_button button-hover sc_button_square sc_button_style_red sc_button_size_mini contact_form_submit" data-text="Send Message">Send Message</button>
											</div>
										</div>

								        <div class="result sc_infobox"></div>
								    </form>
								</div> 
							</div>
						</div>
				
            
        	
	</div>
				</section>
			</div>
            
            
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3671.878265803065!2d72.56308351433434!3d23.028241521896298!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e84f7837cd239%3A0x5878b4256f0a9afd!2sP+M+Patel+%26+Co!5e0!3m2!1sen!2sin!4v1476867140735" width="1450" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
           
<? } ?>