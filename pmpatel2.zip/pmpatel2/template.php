<?php
	session_start();
	error_reporting(0);
 	include("sitecontrol/inc/fileInclude.php"); 
	include("sitecontrol/inc/clsObj.php"); 
	include("sitecontrol/config.php"); 
	
	if(stristr($_SERVER['PHP_SELF'],"index.php")!=""){
		$objFrontMenu->id=1;
		$metaRec=$objFrontMenu->selectRecById(); 
	}elseif(stristr($_SERVER['PHP_SELF'],"knowus.php")!=""){
		$objFrontMenu->id=2;
		$metaRec=$objFrontMenu->selectRecById(); 
	}elseif(stristr($_SERVER['PHP_SELF'],"industries.php")!=""){
		$objFrontMenu->id=13;
		$metaRec=$objFrontMenu->selectRecById(); 
	}elseif(stristr($_SERVER['PHP_SELF'],"contactus.php")!=""){
		$objFrontMenu->id=7;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"products.php")!=""){
		$objFrontMenu->id=3;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"video_gallery.php")!=""){
		$objFrontMenu->id=11;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif((isset($_GET['ctid']) && $_GET['ctid']!="") || (isset($_GET['cpname']) && $_GET['cpname']!="") || (isset($_GET['pid']) && $_GET['pid']!="") || (isset($_GET['tid']) && $_GET['tid']!="")){
		if(isset($_GET['ctid'])){
				$objProCat->id=$_GET['ctid'];
				$metaRec = $objProCat->selectRecById();
				
				if($metaRec[0]['metaTitle']==''){
					$metaRec[0]['metaTitle'] = $metaRec[0]['category_name'].' | '.META_TITLE;
				}
				if($metaRec[0]['metaDescription']==''){
					$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['category_name'].' , '.META_DESC;
				}
				if($metaRec[0]['metaKeywords']==''){
					$metaRec[0]['metaKeywords'] = $metaRec[0]['category_name'].' , '.META_KEYWORD;
				}
				
			}
			elseif(isset($_GET['pid'])){
				$objProduct->id=$_GET['pid'];
				$metaRec = $objProduct->selectRecById();
				
				if($metaRec[0]['metaTitle']==''){
					$metaRec[0]['metaTitle'] = $metaRec[0]['product_name'].' | '.META_TITLE;
				}
				if($metaRec[0]['metaDescription']==''){
					$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['product_name'].' , '.META_DESC;
				}
				if($metaRec[0]['metaKeywords']==''){
					$metaRec[0]['metaKeywords'] = $metaRec[0]['product_name'].' , '.META_KEYWORD;
				}
			}
			elseif(isset($_GET['tid'])){
				$objEvent->id=$_GET['tid'];
				$metaRec = $objEvent->selectRecById();
				
				if($metaRec[0]['metaTitle']==''){
					$metaRec[0]['metaTitle'] = $metaRec[0]['product_name'].' | '.META_TITLE;
				}
				if($metaRec[0]['metaDescription']==''){
					$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['product_name'].' , '.META_DESC;
				}
				if($metaRec[0]['metaKeywords']==''){
					$metaRec[0]['metaKeywords'] = $metaRec[0]['product_name'].' , '.META_KEYWORD;
				}
			}
			elseif(isset($_GET['cpname'])){
				$objProduct->alias_name=$_GET['cpname'];
				$metaRec = $objProduct->selectRecByAlias();	
				
				//echo "<pre>"; print_r($metaRec); exit;
				
				if(count($metaRec)>0)
				{
					if($metaRec[0]['metaTitle']==''){
						$metaRec[0]['metaTitle'] = $metaRec[0]['product_name'].' | '.META_TITLE;
					}
					if($metaRec[0]['metaDescription']==''){
						$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['product_name'].' , '.META_DESC;
					}
					if($metaRec[0]['metaKeywords']==''){
						$metaRec[0]['metaKeywords'] = $metaRec[0]['product_name'].' , '.META_KEYWORD;
					}
				}else{
				
					$objProCat->alias_name=$_GET['cpname'];
					$metaRec = $objProCat->selectRecByAlias();	
									
					if($metaRec[0]['metaTitle']==''){
						$metaRec[0]['metaTitle'] = $metaRec[0]['category_name'].' | '.META_TITLE;
					}
					if($metaRec[0]['metaDescription']==''){
						$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['category_name'].' , '.META_DESC;
					}
					if($metaRec[0]['metaKeywords']==''){
						$metaRec[0]['metaKeywords'] = $metaRec[0]['category_name'].' , '.META_KEYWORD;
					}
					
				}
				
				
			}
			
			
	}else{
		$objFrontMenu->id=$_GET['id'];
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	
?>

<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="format-detection" content="telephone=no">
	<link rel="icon" type="image/x-icon" href="images/favicon.png" />
	<title>Welcome To PM Patel & Company</title>
	<meta name='robots' content='noindex,follow' />
	<link rel='stylesheet' id='rs-plugin-settings-css'  href='js/vendor/revslider/rs-plugin/css/settings.css' type='text/css' media='all' />
	<link rel='stylesheet' href='css/fontello/css/fontello.css' type='text/css' media='all' />
	<link rel="stylesheet" href="js/vendor/calculated-fields-form/css/stylepublic.css" type="text/css" />
	<link rel="stylesheet" href="js/vendor/calculated-fields-form/css/cupertino/jquery-ui-1.8.20.custom.css" type="text/css" />
	<link rel='stylesheet' href='css/style.css' type='text/css' media='all' />
	<link rel='stylesheet' href='css/core.animation.css' type='text/css' media='all' />
	<link rel='stylesheet' href='css/responsive.css' type='text/css' media='all' />
</head>

<body class="page body_style_boxed body_filled article_style_stretch top_panel_style_light top_panel_opacity_solid top_panel_show top_panel_above menu_center user_menu_hide sidebar_show sidebar_right body_bg1">
	
	<div class="body_wrap">
		<div class="page_wrap">
			<div class="top_panel_fixed_wrap"></div>
			<header class="top_panel_wrap bg_tint_light" >
				
				
			   
				<div class="menu_main_wrap with_text">
				       
					<div class="content_wrap clearfix display_none">
					           
						<div class="logo">
							<div class="logo_img">
								<a href="index.html">
									<img src="images/logoca.png" class="logo_main" alt="">
									<img src="images/logoca.png" class="logo_fixed" alt="">
								</a>
							</div>
							<div class="contein_logo_text">
								<a href="index.html">
									<span class="logo_text">P M Patel & Co</span>
									<span class="logo_slogan">Chartered Accountants</span>
								</a>
							</div>
						</div>
						<div class="inline image side-right top-panel_blocks">
							<div class="inline">
								<div class="inline-wrapper">
									<div class="side-right marg_null marg_top top-panel_left">
										<div class="icon_user-top">
											<i class="user_top_icon icon-mobile-1"></i>
										</div>
										<h4>+91-9825232461</h4>
										<span class="font_086em">
											<a href="mailto:rahul@pmpatel.com">rahul@pmpatel.com</a>
										</span>
									</div>
								</div>
							</div>
							<div class="inline pad_left_2em">
								<div class="inline-wrapper">
									<div class="side-right marg_null marg_top top-panel_right_s">
										<a href="#"><input type="button" value="Subscribe" /></a>
									<?php	if(isset($_SESSION['username']) && $_SESSION['username'] != "" ){ ?>
									<div class='logout_new'>
									<a href="logout.php">Logout</a>
									</div>
									<?php	} ?>

										<br />
									<input type="text" placeholder="Search"><i class="user_top_icon icon-search" style="color:#666;"></i>
									</div>
								</div>
							</div>
						</div>
						<a href="#" class="menu_main_responsive_button icon-menu">Menu</a>
					           
					</div>
				           
					<div class="main-menu_wrap_bg">
						<div class="main-menu_wrap_content">
							<nav role="navigation" class="menu_main_nav_area">
								<? include("top_menu.php"); ?>
							</nav>
						</div>
					</div>
				</div>

			</header>
          <? main(); ?>  
            <footer class="footer_wrap bg_tint_dark footer_style_dark widget_area">
				<div class="content_wrap">
					<div class="columns_wrap with_padding">
						<aside class="column-1_4 widget widget_socials">
							<div class="widget_inner">
								<h5 class="widget_title">About Us</h5>
								 <? $objFrontMenu->id=10;
	$recDet = $objFrontMenu->selectRecById(); 
	echo $recDet[0]['menuDesc']; ?>
								
							</div>
						</aside>
						<aside class="column-1_4 widget widget_text">
							<h5 class="widget_title">Services</h5>
							<ul class="sc_list  sc_list_style_iconed">
<? $Categories = $objProCat->menuCategoryList(); 	 // Main Category List
						
			for($t=0; $t<count($Categories); $t++)
			{									
										
					if(count($Categories)>0)
					{	
						if($Categories[$t]['alias_name']!="")
								$link = $Categories[$t]['alias_name'].".html";
							else
								$link = "content.php?ctid=".$Categories[$t]['id'];					
					
						?>
                       <li class="sc_list_item">
<span class="sc_list_icon icon-arrow1"> </span>
<a class="footer_email" href="<?=$link;?>"><?php echo $Categories[$t]['category_name']; ?></a>
                        </li>
                        <? } } ?>
</ul>
						</aside>
						<aside class="column-1_4 widget widget_text">
							<h5 class="widget_title">Legal</h5>
							<div class="textwidget">
								 <? $objFrontMenu->id=15;
	$recDet = $objFrontMenu->selectRecById(); 
	echo $recDet[0]['menuDesc']; ?>
							</div>
						</aside>
						
						<aside class="column-1_4 widget widget_flickr">
							<h5 class="widget_title">Get Connected</h5> 
							<? $objFrontMenu->id=6;
	$recDet = $objFrontMenu->selectRecById(); 
	echo $recDet[0]['menuDesc']; ?>
							
								</div>
						</aside> 
					</div>  
				</div>  
			</footer>		
				 
			<div class="copyright_wrap bottom_cont">
				<div class="content_wrap">
					<p><a href="#">PM Patel & Company</a> © 2016 All Rights Reserved. | Design By <a href="http://resolutewebmarketing.com/">Resolute Web Marketing.</a></p>					
				</div>
			</div>
		
		</div>						
	</div>

	<div id="preloader" class="preloader">
	    <div class="preloader_image"></div>
	</div>

	<a href="#" class="scroll_to_top icon-up-2" title="Scroll to top"></a>

	<div class="custom_html_section"></div>

	<script type='text/javascript' src='js/vendor/jquery-1.11.3.min.js'></script>
	<script type='text/javascript' src='js/vendor/jquery-migrate.min.js'></script>
	<script type='text/javascript' src='js/vendor/revslider/rs-plugin/js/jquery.themepunch.tools.min.js'></script>
	<script type='text/javascript' src='js/vendor/revslider/rs-plugin/js/jquery.themepunch.revolution.min.js'></script>

	<script type='text/javascript' src='js/vendor/__packed.js'></script>
	<script type='text/javascript' src='js/custom/_main.js'></script>
	<script type='text/javascript' src='js/custom/core.utils.min.js'></script>
	<script type='text/javascript' src='js/custom/core.init.min.js'></script>
	<script type='text/javascript' src='js/custom/shortcodes.min.js'></script>

	<script type='text/javascript' src='js/vendor/datepicker.min.js'></script>
	<script type='text/javascript' src='js/vendor/calculated-fields-form/js/jQuery.stringify.js'></script>
	<script type='text/javascript' src='js/vendor/calculated-fields-form/js/jquery.validate.js'></script>
	<script type='text/javascript' src='js/vendor/calculated-fields-form/js/fbuilder.js'></script>

</body>
</html>