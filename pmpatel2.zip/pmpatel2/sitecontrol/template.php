<?php
error_reporting(0);
	include("inc/fileInclude.php");
	include("config.php");
	include("inc/clsObj.php");	
	checkLogin();
	$adminListRec=$objAdminMenu->menuCategoryList();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Adminstrator Control Panel for <?=SITE_NAME;?></title>
<link href="css/template.css" rel="stylesheet" type="text/css" />
<link href="css/forms.css" rel="stylesheet" type="text/css" />
<link href="menu/menu.css" rel="stylesheet" type="text/css" />
<link href="css/pagingstyle.css" rel="stylesheet" type="text/css" />
<style type="text/css">
.qmfv{visibility:visible !important;}.qmfh{visibility:hidden !important;}
</style>
<script type="text/javascript" src="menu/menucode.js"></script>
<link href="menu/menu.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/validator.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script language="javascript" src="js/ajax.js"></script>
<script language="javascript" src="js/getdetails.js"></script>
<script type="text/javascript">
function Logout()
{
	if(confirm("Are you sure want to logout now?\n\nClick [ OK ] to logout now.\nClick [ Cancel ] to continue with current login."))
	{
		document.location="codeAdminLogout.php";
	}
}

function confdelimg(imgId,imgName){
	var conf = confirm("Are you sure want to delete this image ?");
	
	if(conf){
		MakeRequest(imgId,imgName);
	}else{
		return false;
	}
}
</script>

<script type="text/javascript" src="js/runtime.js"></script>
<link href="css/runtime.css" rel="stylesheet" type="text/css" />


</head>
<body>
<div id="main_wrapper">
<div id="top_div">
<strong class="logo"><a href="frmMain.php"></a></strong>
<div id="right_links">Welcome, you are logged in as : <?=$_SESSION['membername'];?> !<br />
<a href="Javascript:history.go(-1)">Back</a>&nbsp;&nbsp;<span style="color:#FF9900;">|</span>&nbsp;&nbsp;<a href="../index.php" target="_blank">Visit Site</a><br />
<a href="Javascript:Logout();">Logout</a></div>
<div style="clear: both;"></div>
</div>

<div class="admin_menu">
	<?php   include("menu/menu.php"); ?>
</div>

<div class="admin_main_div" >
	<?php main(); ?>
</div>

<div id="footer">
	Control Panel : <a href="<?=POWER_BY_WEBSITE;?>"><?=POWER_BY;?></a></strong></div>
</div>

</body>
</html>