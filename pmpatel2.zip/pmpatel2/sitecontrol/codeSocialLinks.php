<?php
include("template.php");
function main()
{
	include("inc/clsObj.php");
	$heading="Social Links";	
	$object=$objSocialLinks;
	$pageName="codeSocialLinks.php";
	$object->limit=TOTAL_RECORDS;
	
	extract($_POST);
    $rnd=createRandomCode();	
	$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid )) ;
	   	
		if($_FILES['imageOriginal']['name']!="")
		{
			if(isset($hiddenImage))
			{
				unlink(SOCIAL_IMAGE.$hiddenImage);				
			}
		}	

		$object->title=$title;
		$object->s_link=$txtLinks;
		$object->seqNo=$txtSeqNo;
		
		$wh = getimagesize($_FILES['imageOriginal']['tmp_name']);
		$w=$wh[0];
		$h=$wh[1];
		
		if($_FILES['imageOriginal']['name']!="")
			{
					$object->image=uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],SOCIAL_IMAGE,SOCIAL_IMAGE_WIDTH);				
		    } else {
				
				if(isset($hiddenImage))
					{
						  $object->image=$hiddenImage;	
     				}
				else
					{
					
						 $object->image=NULL;
					}			 	  
			}	
		$object->status=isset($_GET['status']) ? $_GET['status'] : 1;
	if(isset($_POST['btnAdd']))
			{											
				$object->insert();
				redirect($pageName."?msg=add");
			}
	if(isset($_POST['btnUpdate']))
			{							
				$object->update();
				redirect($pageName."?msg=edit");
			}			
	if(isset($_POST['btnAction']))
		{
		 extract($_POST);
		 switch($optAction)
		  {
		  	case 0:
					$object->deleteSelect($chkAction);
    				redirect($pageName."?msg=del");
					break;
			case 1:
			 		$object->statusUpdatePublish($chkAction);
         			redirect($pageName."?msg=Publish");
			        break;
			case 2:
			        $object->statusUpdateUnPublish($chkAction);
					redirect($pageName."?msg=UnPublish");
					break;
			case 3:
					extract($_POST);
					for($i=0;count($categoryId)>$i;$i++)
					{
						$object->id=$categoryId[$i];
						$object->seqno=$txtSeqNo[$i];
						$object->sequenceUpdate();				
					}	
					redirect($pageName."?msg=seq");					
		   } 
	     }						
	if(isset($_GET['id']))
			{					
					$editRec=$object->selectRecById();									
			}	
	if(isset($_GET['delete']))
			{								 
				  $object->delete();
				  redirect($pageName."?msg=del");
			}	
	if(isset($_GET['status']))
			{			
			     $object->status();
				 redirect($pageName."?msg=status");		
			}
			
	$listRec=$object->paging();	
    include("html/frmSocialLinks.php");
 } 
?>
