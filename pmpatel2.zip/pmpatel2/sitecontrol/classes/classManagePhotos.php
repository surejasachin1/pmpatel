<?php
global $db;

class Photos
	{
	   var $tablename='photos';
	   var $id;
	   var $catgid;
	   var $name;
	   var $seqno;
	   var $image;	  
	   var $status;
	   var $limit;
	   var $start;
       function Photos()
			{
						$this->db = new dbclass();
			}
	  /* function insert()
			{	
				$sql = "insert into `$this->tablename` values('',
								'$this->catgid',
								'$this->seqno',
								'$this->name',								
								'$this->image',																
								 $this->status)";
								//echo $sql;die();		
					$this->db->insert($sql);
					$id=mysql_insert_id();
					Photos::insert_img($this->catgid);
					return($id);
			}*/
		function insert() //Multiple Images to be add
		{
			//echo $catgid;die;
			$totalimg=count($_FILES['photoimages']['name']);
			for($i=0; $i<count($_FILES['photoimages']['name']); $i++)
			{
				if(!empty($_FILES['photoimages']['name'][$i])){
					$upload['name'][$i]=$_FILES['photoimages']['name'][$i];
					$upload['tmp_name'][$i]=$_FILES['photoimages']['tmp_name'][$i];
					$upload['type'][$i]=$_FILES['photoimages']['type'][$i];
					$upload['error'][$i]=$_FILES['photoimages']['error'][$i];
					$upload['size'][$i]=$_FILES['photoimages']['size'][$i];
					
					// Added for width and height
					$wh = getimagesize($_FILES['photoimages']['tmp_name'][$i]);
					$upload['width'][$i]=$wh[0];
					$upload['height'][$i]=$wh[1];
				}
			 }
			 
			 for($j=0; $j<$totalimg; $j++)
			 {
		 		$uploaded_titles[$j] = ($_POST['phototitle'][$j]!= "Enter Title") ? $_POST['phototitle'][$j] : "";
				$uploaded_sequence[$j] = ($_POST['photoseq'][$j]!="Enter Sequence") ? $_POST['photoseq'][$j] : "";
				$rnd=createRandomCode();
				if(!empty($upload['name'][$j]))
				{
					$_FILES['photoimages']['name']=$upload['name'][$j];
					$_FILES['photoimages']['tmp_name']=$upload['tmp_name'][$j];
					$_FILES['photoimages']['type']=$upload['type'][$j];
					$_FILES['photoimages']['error']=$upload['error'][$j];
					$_FILES['photoimages']['size']=$upload['size'][$j];	
					
					// Added for width and height
					
 				 	if($upload['width'][$j]>=PRODUCT_BIG_WIDTH)
					{
						$objectBigImage=uploadImage("photoimages", $rnd.$_FILES['photoimages']['name'], PHOTO_GALLERY_BIG, PHOTO_GALLERY_BIG_WIDTH,'');
					}else{
						$objectBigImage=uploadImage("photoimages", $rnd.$_FILES['photoimages']['name'], PHOTO_GALLERY_BIG, '','');
					}
					
					if($upload['width'][$j]>=PRODUCT_SMALL_WIDTH)
					{
						$objectSmallImage=uploadImage("photoimages", $rnd.$_FILES['photoimages']['name'], PHOTO_GALLERY_SMALL, PHOTO_GALLERY_SMALL_WIDTH,'');

					}else{
						$objectSmallImage=uploadImage("photoimages", $rnd.$_FILES['photoimages']['name'], PHOTO_GALLERY_SMALL, '','');

					}
					$sql = "insert into `$this->tablename` values('',																											
								   '$this->catgid','$uploaded_sequence[$j]','$uploaded_titles[$j]',
								   '".$objectSmallImage."',1)";
									//echo $sql; exit;
					$this->db->insert($sql);
					
				}//If over
		    }//for over
			return true; 
		}
		/*Use for updating & deleteing title & seqnum of images start*/
		function updateRecById($id,$title,$seq)
		{
			$sql="update `$this->tablename` set `name`='".$title."', seqno=".$seq." where id=".$id."";
			//echo $sql;die;
			$this->db->edit($sql);		
			return true;
		}
		function selectDelRecById($img){
		$sql="delete from `$this->tablename` 
				  where `id`=$this->id";//echo $sql;die();
			mysql_query($sql);	
			unlink(PHOTO_GALLERY_BIG.$img);
			unlink(PHOTO_GALLERY_SMALL.$img);
	   }
	/*Use for updating & deleteing title & seqnum of images End*/
	   function getPhotoByCategory($id)
	   {
	   		$sql="select * from `$this->tablename` where id=".$id." order by seqno";
			$result=$this->db->select($sql);
			return($result);
	   }
	   function update()
	   {/*
				$sql = "update `$this->tablename` set	  							
								`catgid`='$this->catgid',
								`name`='$this->name',
								`seqno`='$this->seqno',								
								`image`='$this->image'																
						    	 where `id`=$this->id";
								  //echo $sql;die();	
						$this->db->edit($sql);		
						return true;*/
				$totalimg=count($_FILES['photoimages']['name']);
			for($i=0; $i<count($_FILES['photoimages']['name']); $i++)
			{
				if(!empty($_FILES['photoimages']['name'][$i])){
					$upload['name'][$i]=$_FILES['photoimages']['name'][$i];
					$upload['tmp_name'][$i]=$_FILES['photoimages']['tmp_name'][$i];
					$upload['type'][$i]=$_FILES['photoimages']['type'][$i];
					$upload['error'][$i]=$_FILES['photoimages']['error'][$i];
					$upload['size'][$i]=$_FILES['photoimages']['size'][$i];
					
					// Added for width and height
					$wh = getimagesize($_FILES['photoimages']['tmp_name'][$i]);
					$upload['width'][$i]=$wh[0];
					$upload['height'][$i]=$wh[1];
				}
			 }
			 
			 for($j=0; $j<$totalimg; $j++)
			 {
				$uploaded_titles[$j] = ($_POST['phototitle'][$j]!= "Enter Title") ? $_POST['phototitle'][$j] : "";
				$uploaded_sequence[$j] = ($_POST['photoseq'][$j]!="Enter Sequence") ? $_POST['photoseq'][$j] : "";
				$rnd=createRandomCode();
				if(!empty($upload['name'][$j]))
				{
					$_FILES['photoimages']['name']=$upload['name'][$j];
					$_FILES['photoimages']['tmp_name']=$upload['tmp_name'][$j];
					$_FILES['photoimages']['type']=$upload['type'][$j];
					$_FILES['photoimages']['error']=$upload['error'][$j];
					$_FILES['photoimages']['size']=$upload['size'][$j];	
					
					// Added for width and height
					
 				 	if($upload['width'][$j]>=PRODUCT_BIG_WIDTH)
					{
						$objectBigImage=uploadImage("photoimages", $rnd.$_FILES['photoimages']['name'], PHOTO_GALLERY_BIG, PHOTO_GALLERY_BIG_WIDTH,'');
					}else{
						$objectBigImage=uploadImage("photoimages", $rnd.$_FILES['photoimages']['name'], PHOTO_GALLERY_BIG, '','');
					}
					
					if($upload['width'][$j]>=PRODUCT_SMALL_WIDTH)
					{
						$objectSmallImage=uploadImage("photoimages", $rnd.$_FILES['photoimages']['name'], PHOTO_GALLERY_SMALL, PHOTO_GALLERY_SMALL_WIDTH,'');

					}else{
						$objectSmallImage=uploadImage("photoimages", $rnd.$_FILES['photoimages']['name'], PHOTO_GALLERY_SMALL, '','');

					}
					$sql = "insert into `$this->tablename` values('',																											
								   '$this->catgid','$uploaded_sequence[$j]','$uploaded_titles[$j]',
								   '".$objectSmallImage."',1)";
									//echo $sql; exit;
					$this->db->insert($sql);
					
				}//If over
		    }//for over
			return true;
		}		
		function select()//order by adminMenuId
			{
				 $sql ="select * from `$this->tablename` order by seqno desc";//echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}	
		function selectStatus()//order by adminMenuId
			{
				 $sql ="select * from `$this->tablename` where status=1 order by seqno asc";//echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}	
		function selectRecById()
			{
				$sql ="select * from `$this->tablename` 
					   where id='$this->id' ";//echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}
		function menuSubPhotoList()
		{
			 $sql ="select * from `$this->tablename` 
						 where catgid=$this->id order by seqno asc"; //echo $sql;die();
			   $result=$this->db->select($sql);
			   return($result);
		}						
		function status()
			{
				$sql = "update `$this->tablename` set
							   `status`='$this->status'
								where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}	
		function delete()
			{				 
					$sql="delete from `$this->tablename` 
						  where `id`=$this->id";//echo $sql;die();
					mysql_query($sql);	  
			}		
		/*update selected status publish*/	
		function statusUpdatePublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
									`status`=1
									 where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}	
		/*update selected status unpublish*/	
		function statusUpdateUnPublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
										   `status`=0
											where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}							
		/*delete the selected record*/	
		function deleteSelect($chk) 
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql="delete from `$this->tablename` where `id` = '$id'";
	     					$res = mysql_query($sql);
						}
				return true;
			}
			
			function sequenceUpdate()
	{
		$sql = "update `$this->tablename` set
					   `seqno`='$this->seqno'
						where `id`=$this->id";//echo $sql;die();	
				$this->db->edit($sql);		
				return true;
	}	
				
		/*...paging...*/
		function paging()
			{
				$pages = new Paging();
								
				extract($_POST);
				
				if($sortClName!=''){
					if($sortClName=='category_name'){
						$query = "SELECT * FROM  photo_category AS pc  JOIN `photos` AS pt ON pt.catgid = pc.id ORDER BY pc.name ";
					}else{
						$query = 'select * from `photos` order by '.$sortClName;											
					}
					
				}else{
					$query = 'select * from `photos` order by seqno';					
				}
				
				switch ($ascdsc)
				{
				  case 0:
				  $query = $query." asc";
					break;
				  case 1:
				  $query = $query." desc";
					break;
				}
		
			 // echo "<pre>"; print_r($_POST); exit;
			// echo $query; exit;
				
				$pages->sql = $query;
		
				
				$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page']:1;
				$pages->limit = 10;
				$pages->GeneratePaging();
                $this->pagination=$pages->pagination; 
				$result=$this->db->select($pages->sql);
	 		    return($result);
			}   			
}		
?>   