<?php
global $db;
class search
	{
	   var $tableContent='menumgr';
	   var $tableService ='service_category'; 
	   var $search_text;
	   var $search_result=array('title'=>array(),'link'=>array(),'target'=>array());
	   var $arrayIndex=0;
	   var $limit;
	   var $start;
       function search()
		   {
					$this->db = new dbclass();
		   }	
	   
	   function searchInContent()
		   {
					$sql ="select * from `$this->tableContent` 
						   where menuDesc LIKE '%$this->search_text%' and status=1";
						   //echo $sql;die();
					$result=$this->db->select($sql);
					for($i=0;$i<count($result); $i++){
						$this->search_result['title'][$this->arrayIndex]=$result[$i]['menuName'];
						$this->search_result['intro'][$this->arrayIndex]=$result[$i]['menuDesc'];
						$this->search_result['link'][$this->arrayIndex]="content.php?id=".$result[$i]['id']."&Search_Text=".$this->search_text;
						$this->search_result['target'][$this->arrayIndex]="self";
						$this->arrayIndex++;
					}
					
					$prosql ="select * from `products` 
						   where description LIKE '%$this->search_text%' and status=1";
						   //echo $prosql;die();
					$proresult=$this->db->select($prosql);
					for($k=count($result);$k<count($proresult); $k++){
						$this->search_result['title'][$this->arrayIndex]=$proresult[$k]['product_name'];
						$this->search_result['intro'][$this->arrayIndex]=$proresult[$k]['description'];
						$this->search_result['link'][$this->arrayIndex]="content.php?pid=".$proresult[$k]['id']."&Search_Text=".$this->search_text;
						$this->search_result['target'][$this->arrayIndex]="self";
						$this->arrayIndex++;
					}
					
			}		
	   function searchInService()
			{
					$sql ="select * from `$this->tableService` 
						   where ( title LIKE '%$this->search_text%' or `desc` LIKE '%$this->search_text%' ) and status=1";
					// echo $sql;die();
					$result=$this->db->select($sql);
					for($i=0;$i<count($result); $i++){
						$this->search_result['title'][$this->arrayIndex]=$result[$i]['title'];
						$this->search_result['link'][$this->arrayIndex]="service.php?id=".$result[$i]['id']."&Search_Text=".$this->search_text;
						$this->search_result['target'][$this->arrayIndex]="self";
						$this->arrayIndex++;
					}
			}		
	   
	  function getSearchResult()
	    {
			$this->searchInContent();
			//$this->searchInService();	
			return($this->search_result);
		}			
}		
?>   