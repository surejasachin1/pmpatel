<?php
global $db;
class gst_categories
	{
	   var $tablename='gst_categories';
	   var $id;
	   var $subcatid;
	   var $seq_no;
	   var $category_name;
	   var $alias_name;
	   var $description;
	   var $image;	  
	   var $new_arrival;
	   var $metaTitle;
	   var $metaKeywords;
	   var $metaDescription;
	   var $status;
	   var $limit;
	   var $start;
	   
        function gst_categories()
			{
				
						$this->db = new dbclass();
			}
		function insert()
			{
			  	$sql = "insert into `$this->tablename`(
								`subcatid`,
								`category_name`,
								`alias_name`,
								`description`,
								`image`,
								`new_arrival`,
								`metaTitle`,
								`metaKeywords`,
								`metaDescription`,
								`status`,
								`seq_no`)values(
								'$this->subcatid',
								'$this->category_name',
								'$this->alias_name',
								'$this->description',
	  						    '$this->image',
							    '$this->new_arrival',
								'$this->metaTitle',
								'$this->metaKeywords',
								'$this->metaDescription',
								'$this->status',
								$this->seq_no)";
					//echo $sql;die();										
					$this->db->insert($sql);
					$id=mysql_insert_id();
					return($id);
			}
			function update_images($id){
		$number_of_file_fields = 0;
		$number_of_uploaded_files = 0;
		$number_of_moved_files = 0;
		$uploaded_files = array();
		$upload_directory = 'test_upload/'; //set upload directory
		/**
		 * we get a $_FILES['images'] array ,
		 * we procee this array while iterating with simple for loop 
		 * you can check this array by print_r($_FILES['images']); 
		 */
		$temp_count = count($_FILES['images']['name']);
		for($i=0; $i<count($_FILES['images']['name']); $i++){
			if(!empty($_FILES['images']['name'][$i])){
				$upload['name'][$i]=$_FILES['images']['name'][$i];
				$upload['tmp_name'][$i]=$_FILES['images']['tmp_name'][$i];
				$upload['type'][$i]=$_FILES['images']['type'][$i];
				$upload['error'][$i]=$_FILES['images']['error'][$i];
				$upload['size'][$i]=$_FILES['images']['size'][$i];
				
				// Added for width and height
				$wh = getimagesize($_FILES['images']['tmp_name'][$i]);
				$upload['width'][$i]=$wh[0];
				$upload['height'][$i]=$wh[1];
			}
			
		}
		
		for($j=0; $j<$temp_count; $j++){
				$uploaded_titles[] = ($_POST['img_title'][$j]!="Enter Title") ? $_POST['img_title'][$j] : "";
				$uploaded_sequence[] = $_POST['img_sequence'][$j];
				$uploaded_price[] = $_POST['price'][$j];
				$rnd=createRandomCode();
				if(!empty($upload['name'][$j])){
					$_FILES['images']['name']=$upload['name'][$j];
					$_FILES['images']['tmp_name']=$upload['tmp_name'][$j];
					$_FILES['images']['type']=$upload['type'][$j];
					$_FILES['images']['error']=$upload['error'][$j];
					$_FILES['images']['size']=$upload['size'][$j];	
					
					// Added for width and height
														
					if($upload['width'][$j]>=PRODUCT_BIG_WIDTH)
					{
						$objectBigImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_BIG_IMAGE,770,504);
					}else{
						$objectBigImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_BIG_IMAGE,770,504);
					}
					
					if($upload['width'][$j]>=PRODUCT_SMALL_WIDTH)
					{
						$objectSmallImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_SMALL_IMAGE,370,245);

					}else{
						$objectSmallImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_SMALL_IMAGE,370,245);

					}
					
					$sql = "insert into `product_img` values('',																											
							   '$id',
							   '".$objectSmallImage."',
							   '$uploaded_sequence[$j]',
							   '$uploaded_titles[$j]',
							   '$uploaded_price[$j]'
								)";
									// echo $sql; exit;
					$this->db->insert($sql);
				}
		}
		return true;
	   }
		function update()
			{
				$sql = "update `$this->tablename` set
						`subcatid`='$this->subcatid',
						`category_name`='$this->category_name',
						`alias_name`='$this->alias_name',
						`description`='$this->description',
						`image`='$this->image',
						`new_arrival`='$this->new_arrival',
						`metaTitle`='$this->metaTitle',
						`metaKeywords`='$this->metaKeywords',
						`metaDescription`='$this->metaDescription',
						`seq_no`='$this->seq_no'										
						 where `id`=$this->id";
						// echo $sql;die();	
				$this->db->edit($sql);		
				return true;
			}							
		function menuCategoryList()//order by id
			{
				 $sql ="select * from `$this->tablename` 
				   		 		 where subcatid=0  and  status=1 order by seq_no asc";//echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}
		function menuCategoryListRec()//order by adminMenuSeqNo
			{
				 $sql ="select * from `$this->tablename` 
							  where subcatid=0  order by seq_no ";//echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}
			
		function selectRecByAlias()
			{
				//$sql ="select * from `$this->tablename` where alias_name='$this->alias_name'";
				
				$sql =  "select * from ".$this->tablename." where alias_name=\"".$this->alias_name."\";"; 
					   //echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}
		
		function selectRecords($pvar,$ntid)
			{
			//	$sql ="select distinct count(p.alias_name),count(pc.alias_name),count(mm.alias_name) from products as p, pro_categories as pc, menumgr as mm where (p.alias_name = '".$pvar."') or (pc.alias_name = '".$pvar."') or (mm.alias_name = '".$pvar."')  ";
			
			
			if(isset($ntid) && $ntid!=''){
			
				$sql = "SELECT alias_name,id, COUNT(*) AS tes FROM menumgr WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM products WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM pro_categories WHERE alias_name='".$pvar."' and id!=".$ntid."  GROUP BY alias_name HAVING COUNT(*) >= 1";
			}else{
			
				$sql = "SELECT alias_name,id, COUNT(*) AS tes FROM menumgr WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM products WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM pro_categories WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1";
			}
			
				// echo $sql;die();
    			$result=$this->db->select($sql);
		   return($result);
			}	
			
			
		function menuSubCategoryList()//order by id
			{
				 $sql ="select * from `$this->tablename` 
				   		 	 where subcatid=$this->id order by seq_no"; //echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}	
		function status()
			{
				$sql = "update `$this->tablename` set
	  						   `status`='$this->status'
							    where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}
		function delete()
			{
				$sql="delete from `$this->tablename` 
					  where `subcatid`=$this->id";
				mysql_query($sql);		  
				$sql="delete from `$this->tablename` 
					  where `id`=$this->id";//echo $sql;die();
				mysql_query($sql);	  
			}	
		function selectRecById()
			{
				$sql ="select * from `$this->tablename` 
					   where id='$this->id'";
					   
				//	  echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}
		function sequenceUpdate()
			{
				$sql = "update `$this->tablename` set
	  						   `seq_no`='$this->seq_no'
							    where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}
		/*update selected status publish*/	
		function statusUpdatePublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
										   `status`=1
											where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}	
		/*update selected status unpublish*/	
		function statusUpdateUnPublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
										   `status`=0
											where `id`='$id'";//echo $sql;die();	
								   	$this->db->edit($sql);		
	  				    }
			    return true;
			}	
		/*delete the selected record*/	
		function deleteSelect($chk) 
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql="delete from `$this->tablename` where `id` = '$id'";
	     					$res = mysql_query($sql);
						}
				return true;
			}	
		/*...paging...*/
		function paging()
			{				
				$pages = new Paging();
				
				
		if(isset($_POST['search']) && $_POST['search']=='Search' && $_POST['search_txt']!=''){
			$query = "select * from `$this->tablename` where (category_name LIKE '%".$_POST['search_txt']."%') order by id asc";			
		}else{
		
			// $query = "select * from `$this->tablename` where subcatid =0 order by seq_no asc";
			
			extract($_POST);
		
			if($sortClName!=''){
				
				$query = 'select * from `gst_categories` where subcatid = 0 order by '.$sortClName;							
				
			}else{
				$query = 'select * from `gst_categories` where subcatid = 0 order by seq_no';				
			}
			
			
			switch ($ascdsc)
			{
			  case 0:
			  $query = $query." asc";
				break;
			  case 1:
			  $query = $query." desc";
				break;
			}
			
				 // echo "<pre>"; print_r($_POST); exit;
				// echo $query; exit;
		
		
		}
		
				$pages->sql = $query;
				$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
				$pages->limit = 10;
				$pages->GeneratePaging();
                $this->pagination=$pages->pagination; 
				$result=$this->db->select($pages->sql);
	 		    return($result);
			}   				
		/*---category listing-----*/
		function selectPublishedCategories()
		{
			$sql ="select * from `$this->tablename` 
			where status='1' and subcatid=0 order by seq_no ";
			//echo $sql;die();
			$result=$this->db->select($sql);
			return($result);
		}

		/*---sub category listing-----*/
		function selectPublishedSubCategories()
		{
			$sql ="select * from `$this->tablename` 
			where status='1' and subcatid=$this->subcatid order by seq_no asc ";
			//echo $sql;
			//die();
			$result=$this->db->select($sql);
			return($result);
		}
		/*---category path for product listing in backend-----*/
		function getCategoriesPath_backend()
		{
			$arrow="<span class='arrow'> &raquo; </span>";
			$sql ="select * from `$this->tablename` where id=$this->id order by seq_no asc";
			$result=$this->db->select($sql);
			$path=$result[0]['category_name'];
			if($result[0]['subcatid']!=0){
				$this->subcatid=$result[0]['subcatid'];
				$sql ="select * from `$this->tablename` where id=$this->subcatid order by seq_no asc";
				$result=$this->db->select($sql);
				$path=$result[0]['category_name'].$arrow.$path;
			}
			$path="<div class=\"bradecrumb\">".$path."</div>";
			//echo $sql;
			//die();
			return($path);
		}

		/*---category bradecrum listing-----*/
		function getCategoriesPath()
		{
			$arrow="<span class='arrow'> &raquo; </span>";
			$sql ="select * from `$this->tablename` where id=$this->id order by seq_no asc";
			$result=$this->db->select($sql);
			$path=$result[0]['category_name'];
			$this->subcatid=$result[0]['subcatid'];
			$sql ="select * from `$this->tablename` where id=$this->subcatid order by seq_no asc";
			$result=$this->db->select($sql);
			$path="Products".$arrow.$result[0]['category_name'].$arrow.$path;
			$path="<div class=\"bradecrumb\">".$path."</div>";
			//echo $sql;
			//die();
			return($path);
		}
		
		/*---product page bradecrum listing-----*/
		function getProductPath($productname)
		{
			$arrow="<span class='arrow'> &raquo; </span>";
			$sql ="select * from `$this->tablename` where id=$this->id order by seq_no asc";
			$result=$this->db->select($sql);
			$path=$result[0]['category_name'];
			$this->subcatid=$result[0]['subcatid'];
			$sql ="select * from `$this->tablename` where id=$this->subcatid";
			$result=$this->db->select($sql);
			$path="Products".$arrow.$result[0]['category_name'].$arrow.$path;
			$path.=$arrow.$productname;
			$path="<div class=\"bradecrumb\">".$path."</div>";
			//echo $sql;
			//die();
			return($path);
		}
		
													
}		
?>   