<?php
global $db;
class user
	{
	   var $tablename='user';
	   var $id;	 
	   var $name;	     	    
	   var $email;	     	    
	   var $status;	  
	   var $limit;
	   var $start;
       function user()
		{
			$this->db = new dbclass();
		}

	   function insert()
		{	
			$sql = "insert into `$this->tablename` values('','$this->name','$this->email','',0)";
				// echo $sql;die();		
				$this->db->insert($sql);
				$id=mysql_insert_id();
				return($id);
		}

		/* Check the login  for the user*/	
		function emailCheck()
		{
			$sql ="select * from `$this->tablename` 
				  where email='$this->email'";
				 // echo $sql;die();
			$result=$this->db->select($sql);
			return($result);
		}
			
	   function update()
		{
			$sql = "update `$this->tablename` set								
							`email`='$this->email'														
							 where `id`=$this->id";
							  //echo $sql;die();	
					$this->db->edit($sql);		
					return true;
		}					

		function select()
		{
			 $sql ="select * from `$this->tablename` where status='1'";
			 //echo $sql;die();
			 $result=$this->db->select($sql);
			 return($result);
		}	

	    function selectStatus()
		{
			 $sql ="select * from `$this->tablename` where status=1";//echo $sql;die();
			   $result=$this->db->select($sql);
			   return($result);
		}	
			
       function selectRecById()
		{
			$sql ="select *  from `$this->tablename` 
				   where id='$this->id'";//echo $sql;die();
			   $result=$this->db->select($sql);
			   return($result);
		}	

		function selectRecByIdStatus()
		{
			$sql ="select * from `$this->tablename` 
				   where id='$this->id' and status=1";//echo $sql;die();
			   $result=$this->db->select($sql);
			   return($result);
		}	

		function selectRecByIdNewsLetter()
		{
			$sql ="select * from `$this->tablename` 
				   where id='$this->id' and status=1"; //echo $sql;die();
			   $result=$this->db->select($sql);
			   return($result);
		}
								
		function status()
		{
			$sql = "update `$this->tablename` set
						   `status`='$this->status'
							where `id`=$this->id";
					//echo $sql;die();	
					$this->db->edit($sql);		
					return true;
		}	

		function delete()
		{
				$sql="delete from `$this->tablename` 
					  where `id`=$this->id";
				//echo $sql;die();
				mysql_query($sql);	  
		}	

		function sequenceUpdate()
		{
			$sql = "update `$this->tablename` set
						   `seqno`='$this->seqno'
							where `id`=$this->id";//echo $sql;die();	
					$this->db->edit($sql);		
					return true;
		}			

		/*update selected status publish*/	
		function statusUpdatePublish($chk)
		{
			for($i=0;$i<count($chk);$i++)
			{
				$id = $chk[$i];
				$sql = "update `$this->tablename` set
						`status`=1
						 where `id`='$id'";//echo $sql;die();	
						$this->db->edit($sql);		
			}
			return true;
		}	

		/*update selected status unpublish*/	
		function statusUpdateUnPublish($chk)
		{
			for($i=0;$i<count($chk);$i++)
			{
				$id = $chk[$i];
				$sql = "update `$this->tablename` set
							   `status`=0
								where `id`='$id'";//echo $sql;die();	
						$this->db->edit($sql);		
			}
			return true;
		}							

		/*delete the selected record*/	
		function deleteSelect($chk) 
		{
			for($i=0;$i<count($chk);$i++)
			{
				$id = $chk[$i];
				$sql="delete from `$this->tablename` where `id` = '$id'";
				$res = mysql_query($sql);
			}
			return true;
		}	

		/*...paging...*/
		function paging()
		{
			$pages = new Paging();			
			
			if(isset($_POST['search']) && $_POST['search']=='Search' && $_POST['search_txt']!=''){
					$query = "select * from `$this->tablename` where (name LIKE '%".$_POST['search_txt']."%') order by id asc";			
				}else{
					$query = "select * from `$this->tablename` order by id asc";
				}
				
				$pages->sql = $query;
			
			$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
			$pages->limit = $this->limit;
			$pages->GeneratePaging();
			$this->pagination=$pages->pagination; 
			$result=$this->db->select($pages->sql);
			return($result);
		}		 
		
		function addToGroup($chk,$groupid)
		{
					for($i=0;$i<count($chk);$i++)
			{
			
			
			
				$id = $chk[$i];
				$sql = "update `$this->tablename` set
						`group_id`='$groupid'
						 where `id`='$id'";
						 
						// echo $sql;die();	
						$this->db->edit($sql);		
			}
			return true;
		}	
}		
?>   