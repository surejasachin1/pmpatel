<?php
global $db;
class photo_gallery
	{
	   var $tablename='photo_gallery';
	   var $id;	 
	   var $title;
	   var $seqNo;
	   var $image;	    
	   var $status;
	   var $limit;
	   var $start;

       function photo_gallery()
		{
					$this->db = new dbclass();
		}

	   function insert()
			{	
				$sql = "insert into `$this->tablename` values('',
							   '$this->title',
							   '$this->image',	
							   '$this->seqNo',
							   $this->status)";
								//echo $sql;die();		
					$this->db->insert($sql);
					$id=mysql_insert_id();
					return($id);
			}
	   function update()
			{
				$sql = "update `$this->tablename` set								
								`title`='$this->title',
								`seqNo`=$this->seqNo,
								`image`='$this->image'								
						    	 where `id`=$this->id";
								  //echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}					
		function select()
			{
				 $sql ="select * from `$this->tablename` order by seqNo desc";//echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}	
	    function selectStatus()
			{
				 $sql ="select * from `$this->tablename` where status=1 order by seqNo asc";
				 // echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}	
		 function selectStatusRand()
			{
				 $sql ="select * from `$this->tablename` where status=1 order by rand() limit 0,3";
				 //echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}		
	
		function selectRecById()
			{
				$sql ="select * from `$this->tablename` 
					   where id='$this->id'";//echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}	
		function selectRecByIdStatus()
			{
				$sql ="select * from `$this->tablename` 
					   where projectid='$this->projectid' and status=1";//echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}	
		function getImage()
			{
				$sql ="select * from `$this->tablename` 
					   where projectid='$this->projectid' and id='$this->id' and status=1";//echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}							
		function status()
			{
				$sql = "update `$this->tablename` set
							   `status`='$this->status'
								where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}	
		function delete()
			{							 
					$sql="delete from `$this->tablename` 
						  where `id`=$this->id";//echo $sql;die();
					mysql_query($sql);	  
			}	
		function sequenceUpdate()
			{
				$sql = "update `$this->tablename` set
	  						   `seqno`='$this->seqno'
							    where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}			
		/*update selected status publish*/	
		function statusUpdatePublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
									`status`=1
									 where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}	
		/*update selected status unpublish*/	
		function statusUpdateUnPublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
										   `status`=0
											where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}							
		/*delete the selected record*/	
		function deleteSelect($chk) 
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql="delete from `$this->tablename` where `id` = '$id'";
	     					$res = mysql_query($sql);
						}
				return true;
			}	
		/*...paging...*/
	function paging()
	{
		$pages = new Paging();
		$pages->sql ="select * from `$this->tablename` order by seqNo asc";
		$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
		$pages->limit = $this->limit;
		$pages->GeneratePaging();
		$this->pagination=$pages->pagination; 
		$result=$this->db->select($pages->sql);
		return($result);
	}		 
}		
?>   