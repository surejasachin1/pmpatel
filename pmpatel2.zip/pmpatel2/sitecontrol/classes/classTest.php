<?php
global $db;
class test1
	{
	   var $tablename='test1';
	   var $id;
	   var $seqNo;
	   var $name;
	   var $image;
	   var $description;
	   var $status;
	   var $limit;
	   var $start;
       function test1(){$this->db = new dbclass();}
	   function insert(){	
	   			$sql = "insert into `$this->tablename` values('',
							   '$this->seqNo',
							   '$this->name',
							   '$this->image',
							   '$this->description',
							   '$this->status',
							   '$this->ndate'
							    )";
								echo $sql;die();		
					$this->db->insert($sql);
					$id=mysql_insert_id();
					
			}
			
	 
	   
	   function update(){
				$sql = "update `$this->tablename` set
								`seqNo`='$this->seqNo',
								`name`='$this->name',
								`image`='$this->image',
								`description`= '$this->description',
								`ndate`= '$this->ndate',
								`status`='$this->status'
								 where `id`=$this->id";
								  //echo $sql;die();	
						$this->db->edit($sql);
						
		}
							
		function select(){
				 $sql ="select * from `$this->tablename` order by seqNo asc";//echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
		}	

		function selectStatus()
			{
				$sql ="select * from `$this->tablename` where status=1 order by seqNo asc";
				// echo $sql;die();
    			return($this->pagingQuery($sql));
			}

		function selectStatusAll()
			{
				$sql ="select * from `$this->tablename` where status=1 order by seqNo asc";
				 //echo $sql;die();
    			$result=$this->db->select($sql);
				return($result);
			}
			
	function selectCountStatus()
			{
				 $sql ="select count(*) as total from `$this->tablename` where category_id='$this->category_id' and status=1 order by seqNo asc";
				 //echo $sql;die();
    			 $result=$this->db->select($sql);
				 return($result);
			}	
		function selectNewArrivalStatus($all="")
			{
				if($all==1)
					{
				 			$sql ="select * from `$this->tablename` where status=1 and new_arrival=1 order by seqNo asc";
							 return($this->pagingQuery($sql));
				    }
				else
					{
						$sql ="select * from `$this->tablename` where status=1 and new_arrival=1 order by rand() limit 0,4";
						 $result=$this->db->select($sql);
						  return($result);
					}
			}
		function selectNewArrivalCountStatus()
			{
				$sql ="select count(*) as total from `$this->tablename` where status=1 and new_arrival=1 order by seqNo asc";
				$result=$this->db->select($sql);
				return($result);
			}	
		function selectNewArrivalBrandStatus()
			{
				$sql ="select * from `$this->tablename` where status=1 and new_arrival=1 and brand_id='$this->brand_id' order by seqNo asc";//echo $sql;die();
				return($this->pagingQuery($sql));
			}	
		function selectNewArrivalBrandCountStatus()
			{
				$sql ="select count(*) as total from `$this->tablename` where status=1 and new_arrival=1 and brand_id='$this->brand_id'";//echo $sql;die();
				$result=$this->db->select($sql);
				return($result);
			}		
		function selectBestDealStatus($all="")
			{
				if($all==1)
					{
				 			$sql ="select * from `$this->tablename` where status=1 and best_deal=1";
							return($this->pagingQuery($sql));
				    }
				else
					{
						    $sql ="select * from `$this->tablename` where status=1 and best_deal=1 order by rand() limit 0,4";
							$result=$this->db->select($sql);
	 		                return($result);
					}	
			}			
		function selectBestDealCountStatus()
			{	
				$sql ="select count(*) as total from `$this->tablename` where status=1 and best_deal=1";
				$result=$this->db->select($sql);
				return($result);
			}	
		function selectBestDealBrandStatus()
			{
				$sql ="select * from `$this->tablename` where status=1 and best_deal=1 and brand_id='$this->brand_id'";
				//echo $sql;die();
				return($this->pagingQuery($sql));
			}		
		function selectBestDealBrandCountStatus()
			{
				$sql ="select count(*) as total from `$this->tablename` where status=1 and best_deal=1 and brand_id='$this->brand_id'";//echo $sql;die();
				$result=$this->db->select($sql);
				return($result);
			}						
		function searchStatus($query)
			{
				if($query==1)
				 {	
				 $sql ="select * from `$this->tablename` where category_id='$this->category_id' and status=1 and brand_id='$this->brand_id'";
				 }				
				else
					{
						$sql ="select * from `$this->tablename` where category_id='$this->category_id' and status=1";
					}	
				 //echo $sql;die();
    			   return($this->pagingQuery($sql));
			}
		function searchCountStatus($query)		
			{
				if($query==1)
				 {	
				 $sql ="select count(*) as total from `$this->tablename` where category_id='$this->category_id' and status=1 and brand_id='$this->brand_id'";
				 }				
				else
					{
						$sql ="select count(*) as total from `$this->tablename` where category_id='$this->category_id' and status=1";
					}	
				$result=$this->db->select($sql);
	 		       return($result);	
			}
		function mainSearchStatus($query)
			{
				if($query==1)
				 {	
				 $sql ="select * from `$this->tablename` where name like '%$this->name%' and status=1 and brand_id='$this->brand_id'";
				 }				
				else
					{
						$sql ="select * from `$this->tablename` where name like '%$this->name%' and status=1 order by seqNo asc";
					}	
				 //echo $sql;die();
    			   return($this->pagingQuery($sql));
			}	
			
			function selectRecById()
			{
				$sql ="select * from `$this->tablename` 
					   where id='$this->id'";//echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}
		
		/*
		function selectDelRecById($img)
			{
				$sql="delete from `product_img` 
						  where `img_id`=$this->id";//echo $sql;die();
					mysql_query($sql);
					unlink(PRODUCT_BIG_IMAGE.$img);
			}
		*/	
		
		function selectRecByIdStatus()
			{
				$sql ="select * from `$this->tablename` 
					   where id='$this->id' and status=1 order by seqNo asc";//echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}						
		function status()
			{
				$sql = "update `$this->tablename` set
							   `status`='$this->status'
								where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}
			
			function delete()
			{							 
					$sql="delete from `$this->tablename` 
						  where `id`=$this->id";//echo $sql;die();
					mysql_query($sql);	  
			}	
		function sequenceUpdate()
			{
				$sql = "update `$this->tablename` set
	  						   `seqno`='$this->seqno'
							    where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}			
		/*update selected status publish*/	
		function statusUpdatePublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
									`status`=1
									 where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}	
		/*update selected status unpublish*/	
		function statusUpdateUnPublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
										   `status`=0
											where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}
			
			/*delete the selected record*/	
		function deleteSelect($chk) 
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql="delete from `$this->tablename` where `id` = '$id'";
	     					$res = mysql_query($sql);
						}
				return true;
			}	
					
			
									
		
		/*...paging...*/
	function paging()
	{
		$pages = new Paging();
		
		
		
		if(isset($_POST['search']) && $_POST['search']=='Search' && $_POST['search_txt']!=''){
			$query = "select * from `products` where (product_name LIKE '%".$_POST['search_txt']."%') order by catid asc";			
		}else{
			extract($_POST);
		
		if($sortClName!=''){
			if($sortClName=='category_name'){
				$query = "SELECT * FROM `products` AS pd JOIN pro_categories AS pc ON pd.catid = pc.id ORDER BY pc.category_name ";
			}else{
				$query = 'select * from `products`';
			
				$query = $query." order by ".$sortClName;	
			}
			
		}else{
		$query = 'select * from `test1`';
			$query = $query." order by seqNo";
		}
		
		
		switch ($ascdsc)
		{
		  case 0:
		  $query = $query." asc";
			break;
		  case 1:
		  $query = $query." desc";
			break;
		}
		
			 // echo "<pre>"; print_r($_POST); exit;
			 //echo $query; exit;
		
		}
		
		$pages->sql = $query;
		
		$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
		$pages->limit = $this->limit;
		$pages->GeneratePaging();
		$this->pagination=$pages->pagination; 
		$result=$this->db->select($pages->sql);
		return($result);
	}
	
		function pagingFrontQuery($sql)
	{
		$pages = new Paging();
		$pages->sql =$sql;
		$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
		$pages->limit = $this->limit;
		$pages->parameters = $this->parameters;
		$pages->GenerateFrontPaging();		
		$this->pagination=$pages->pagination; 
		$result=$this->db->select($pages->sql);
		return($result);
	}
	
   function addToCart($pid,$qty)
	{	
		unset($cart);
		$cart = array("id"=>array(), 
					  "name"=>array(), 	
					  "qty"=>array(),
					  "unit"=>array(),
					  "price"=>array());		
		$cart=$_SESSION['cart'];	
		  		
	    $sql="SELECT * FROM `$this->tablename` WHERE id=".$pid." and status=1";
		$rs=$this->db->select($sql);			
		$found=false;	
		for($col=0;$col<count($cart['id']);$col++){
			if($cart['id'][$col]==$pid){
				$cart['qty'][$col] = $cart['qty'][$col]+$qty;
				$qty = $cart['qty'][$col];			
				$cart['price'][$col] = ($rs[0]['price'] * $cart['qty'][$col]);
				$found=true;
				break;
			}
		}
		if(!$found){
			$i=count($cart['id']);	
			$cart['id'][$i] = $pid; 								
			$cart['name'][$i] = $rs[0]['name'];
			$cart['qty'][$i] = $qty;
			$cart['unit'][$i] = $rs[0]['price'];
		    $cart['price'][$i] = ($rs[0]['price'] * ($qty)); 			
		}
		
		$_SESSION['cart']=$cart;		
		return $_SESSION['cart'];
	}		
 function updateCart($qty, $index)
	{
		$cart=$_SESSION['cart'];
		$cart['qty'][$index] = $qty;
		$sql="SELECT * FROM `$this->tablename` WHERE id=".$cart['id'][$index]." and status=1";
		$rs=$this->db->select($sql);
		$cart['price'][$index] = floatval($cart['qty'][$index] * $rs[0]['price']);	
		$_SESSION['cart']=$cart;		
		return $cart;
	}
 
 function remove($index)
 	{
		$cart=$_SESSION['cart'];	
		$tempcart = array("id"=>array(),"name"=>array(),"qty"=>array(),"unit"=>array(),"price"=>array());		  
		for($col=0,$tempcol=0;$col<count($cart['id']);$col++,$tempcol++){
				if($col != $index){
					$tempcart['id'][$tempcol]=$cart['id'][$col];
					$tempcart['name'][$tempcol]=$cart['name'][$col];
					$tempcart['qty'][$tempcol]=$cart['qty'][$col];	
					$tempcart['unit'][$tempcol]=$cart['unit'][$col];			
					$tempcart['price'][$tempcol]=$cart['price'][$col];								
				}
			} 
		$_SESSION['cart']=$tempcart;		
		unset($cart,$tempcart);
		return $_SESSION['cart'];			
	}
	
	
	
	function selectRootProduct()
			{
				$sql ="select * from `$this->tablename` where catid='0' and status=1 order by seqNo asc";
				 //echo $sql;die();
    			$result=$this->db->select($sql);
				return($result);
			}
			
			// Alias
			
			
							
			function selectRecords($pvar,$ntid)
			{
			//	$sql ="select distinct count(p.alias_name),count(pc.alias_name),count(mm.alias_name) from products as p, pro_categories as pc, menumgr as mm where (p.alias_name = '".$pvar."') or (pc.alias_name = '".$pvar."') or (mm.alias_name = '".$pvar."')  ";
			
			//echo $nid; exit;
			
			if(isset($ntid) && $ntid!=''){
			
				$sql = "SELECT alias_name,id, COUNT(*) AS tes FROM menumgr WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM products WHERE alias_name='".$pvar."' and id!=".$ntid." GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM pro_categories WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1";
			}else{
			
				$sql = "SELECT alias_name,id, COUNT(*) AS tes FROM menumgr WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM products WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM pro_categories WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1";
			}
			
				// echo $sql;die();
				
    			$result=$this->db->select($sql);
		   		return($result);
			}
			
			function selectHotProductStatus($all="")
			{

				if($all==1)
					{
						$sql ="select * from `$this->tablename` where status=1 and hot_product=1";
						 return($this->pagingQuery($sql));
				    }

				else

					{

						$sql ="select * from `$this->tablename` where status=1 and hot_product=1 order by rand()";

						 $result=$this->db->select($sql);

						  return($result);

					}

			}	

}		

?>
