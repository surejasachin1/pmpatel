<?  session_start();  	
	
	include("sitecontrol/inc/fileInclude.php"); 
	include("sitecontrol/inc/clsObj.php");

	$objAgent->email=$_GET['email'];

	if(isset($objAgent->email))
		$agentEmail=$objAgent->selectEmailLogin();	
	echo count($agentEmail);
?>