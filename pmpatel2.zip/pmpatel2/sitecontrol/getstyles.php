<?
    session_start();  	
	include("inc/fileInclude.php"); 
	include("inc/clsObj.php"); 

	$objTemp->id=$_GET['tempid'];
	if(isset($objTemp->id))
		$styleRec=$objTemp->tempStylesList();		
if(count($styleRec)>0)
{
	//========select cities by state id==========
	if(isset($_GET['tempid']) && $_GET['tempid']!="")
	{ ?>obj.options[obj.options.length] = new Option('--Select Style--','');
	<?	for($i=0;$i<count($styleRec);$i++) { ?>
			obj.options[obj.options.length] = new Option('<?php echo $styleRec[$i]['temp_name'];?>','<?php echo $styleRec[$i]['id'];?>');
	<?	}
	} 
	//===========end of select records by state=====
}
else
{ ?>
obj.options[obj.options.length] = new Option('--Select Style--','');
<? }
?>

