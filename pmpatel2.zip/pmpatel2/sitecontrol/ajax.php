<?php 
	include("inc/fileInclude.php"); 
	include("inc/clsObj.php");
	if(isset($_GET['product_id']) && !empty($_GET['product_id'])){
		//echo $_GET['property_id'];
		$objProduct->id=$_GET['product_id'];
		$contentDet = $objProduct->selectDelRecById($_GET['img']);
		echo "Image deleted successfully...";
	}
?>