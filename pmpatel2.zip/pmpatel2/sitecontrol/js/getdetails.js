var ajax = new sack();	

function getstyles(sel)
{		
	if(sel.options[sel.selectedIndex].value!="")
		var tempid = sel.options[sel.selectedIndex].value;
	else
		var tempid = 0;
	document.getElementById('styleId').options.length = 0;
	ajax.requestFile = 'getstyles.php?tempid='+tempid;	
	ajax.onCompletion = creatstyles;
	ajax.runAJAX();
}	

function creatstyles()
{
	var obj = document.getElementById('styleId');
	if(!obj.disabled)
		eval(ajax.response);
}

function whenLoading()
{
	document.getElementById('loading').innerHTML = '<img src="images/loader.gif" border="0" />';
}

function whenCompleted()
{
	var e = document.getElementById('replaceme'); 
	var return_value = ajax.response;
	if(return_value.indexOf("Email Already Exits")!=-1)
		document.getElementById('email').focus();
	else
		e.innerHTML = ajax.response;	
}




