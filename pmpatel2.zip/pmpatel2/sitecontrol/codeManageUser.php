<?php
include("template.php");
function main()
{
	include("inc/clsObj.php");
	$heading="User";	
	$object=$objUser;
	
	$pageName="codeManageUser.php";
	$object->limit=TOTAL_RECORDS;
	extract($_POST);
   
	$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid )) ;
	   	$txtAreaDesc=$_POST['FCKeditor1'];					
			$txtAreaDesc=str_replace("\&quot;","", $txtAreaDesc);		
			$txtAreaDesc=str_replace('\\', '', $txtAreaDesc);				
			$txtAreaDesc=str_replace("\'","'", $txtAreaDesc);		
			$txtAreaDesc=str_replace("'","\'", $txtAreaDesc);
		
		$object->name=$name;	
		
		$object->longdesc=$txtAreaDesc;
		
		$object->status=isset($_GET['status']) ? $_GET['status'] : 1;
	if(isset($_POST['btnAdd']))
			{											
				$object->insert();
				redirect($pageName."?msg=add");
			}
	if(isset($_POST['btnUpdate']))
			{							
				$object->update();
				redirect($pageName."?msg=edit");
			}			
	if(isset($_POST['btnAction']))
		{
				
		 extract($_POST);
		 
		 
		 switch($optAction)
		  {
		  	case 0:
					$object->deleteSelect($chkAction);
    				redirect($pageName."?msg=del");
					break;
			case 1:
			 		$object->statusUpdatePublish($chkAction);
         			redirect($pageName."?msg=Publish");
			        break;
			case 2:
			        $object->statusUpdateUnPublish($chkAction);
					redirect($pageName."?msg=UnPublish");
					break;
			case 3:
					extract($_POST);
					for($i=0;count($categoryId)>$i;$i++)
					{
						$object->id=$categoryId[$i];
						$object->seqno=$txtSeqNo[$i];
						$object->sequenceUpdate();				
					}	
					redirect($pageName."?msg=seq");					
		   } 
	     }			
		 
	if(isset($_POST['btnGroup']))
	{
		 extract($_POST);
		 		 
		$object->addToGroup($chkAction,$_POST['optGroup']);
		redirect($pageName);
		break;
	}
		 			
	if(isset($_GET['id']))
			{					
					$editRec=$object->selectRecById();									
			}	
	if(isset($_GET['delete']))
			{								 
				  $object->delete();
				  redirect($pageName."?msg=del");
			}	
	if(isset($_GET['status']))
			{			
			     $object->status();
				 redirect($pageName."?msg=status");		
			}
			
	$listRec=$object->paging();	
    include("html/frmManageUser.php");
 } 
?>