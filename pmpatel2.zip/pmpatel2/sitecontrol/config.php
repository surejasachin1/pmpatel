<?
include("inc/clsObj.php");

$globalconfig = $objGlobalConfig->selectStatus();


for($i=0; $i<count($globalconfig); $i++){

	if($globalconfig[$i]['id']==44){
		$_SESSION['userfile_path'] = $globalconfig[$i]['constantValue'];
	}else{
		define($globalconfig[$i]['constantName'],$globalconfig[$i]['constantValue']);	
	}
 
}
	
	
	
?>