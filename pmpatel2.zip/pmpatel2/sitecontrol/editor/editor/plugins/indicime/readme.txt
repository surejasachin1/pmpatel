Indic IME 2.0 (http://www.vishalon.net/IndicResources/IndicIME/tabid/244/Default.aspx)
Copyright (copy) Vishal Monpara
This plugin is developed using PramukhLib 2.0 (http://www.vishalon.net/tabid/243/Default.aspx)
FCKEditor supported version: 2.6

Easily write in Bengali, Devnagari, Gujarati, Gurmukhi, Kannada, Malayalam, Oriya, Tamil and Telugu with easy-to-use transliterate keyboard. There is no need to download any special software.

--------------------------------------------------------------

Features:

    * Easily write in 9 Indian languages
    * Click on Indic IME Help button for typing help.
    * No need to learn Indic language typing.
    * Switch to normal english keyboard by pressing F12.
    * Extremely fast Indic typing.
    * It's all magic of Javascript.

Plugin Installation:
   1. Unzip the file on your local hard disk.
   2. Upload "indicime" folder to FCKEditor_ROOT/plugins/
   3. In the fckconfig.js file write "FCKConfig.Plugins.Add( 'indicime' );"  and in ToolbarSets initialization add "indicime" and "indicimehelp" button for language dropdown list and help button

Need help in typing?
	
    Visit page http://www.vishalon.net/IndicResources/TypingTips/tabid/166/Default.aspx ONLY ONCE in your lifetime and I bet you will never need to visit this page again. Typing is so easy.

Feedback/Suggestions:

    Drop me few lines at http://www.vishalon.net/ContactMe/tabid/189/Default.aspx