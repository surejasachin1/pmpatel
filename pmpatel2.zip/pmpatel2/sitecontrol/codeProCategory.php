<?php 
include("template.php");
function main()	
	{
		include("inc/clsObj.php");			
		$heading="Category";		
		$pageName="codeProCategory.php";
		$object=$objProCat;
	    $object->limit=TOTAL_RECORDS;	
		extract($_POST);
		$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id']:$hid)) ;
			$rnd=createRandomCode();
		
				$object->subcatid=$optMenuPosition;
				$object->category_name=$txtMenuName;	
				
				//$object->alias_name=$Alias_Name;						
				// Added //
				$Alias_Name = preg_replace("![^a-z0-9]+!i", "-", $Alias_Name);
				$Alias_Name = strtolower($Alias_Name);
				$object->alias_name=$Alias_Name;
				// End //
				
				$object->description=$_POST['FCKeditor1'];
				$object->new_arrival=isset($New_Arrival) ? 1 : 0;		   
				if($_FILES['imageOriginal']['name']!="")
							$object->image=uploadImage("imageOriginal",$txtMenuName.'-'.$rnd,CATEGORY_SMALL_IMAGE,CATEGORY_SMALL_WIDTH,'');
			
				if($_FILES['imageOriginal']['name']!="")
					$object->image=uploadImage("imageOriginal",$txtMenuName.'-'.$rnd,CATEGORY_BIG_IMAGE,CATEGORY_BIG_WIDTH,'');  
			
				if($_FILES['imageOriginal']['name']==""){
					if(isset($hiddenImage)){
							  $object->image=$hiddenImage;	
					}else{
							 $object->image=NULL;
					}			 	  
				}
				
				$object->metaTitle=$txtMetaTitle;
				$object->metaKeywords=$txtMetaKeywords;
				$object->metaDescription=$txtMetaDesc;
				
				
				$object->status=isset($_GET['status']) ? $_GET['status'] : 1;
				
				if($txtSeqNo=="")
				 	  $object->seq_no=0;		
				else	  
					   $object->seq_no=intval($txtSeqNo);		
		if(isset($_POST['btnAdd']))
			{		
				$object->insert();
				redirect($pageName."?msg=add");
			}
		if(isset($_POST['btnUpdate']))			
			{		  
				$object->update();
				redirect($pageName."?msg=edit");
			}
		if(isset($_POST['btnApply'])){		
				$object->update();
				redirect($pageName."?id=".$_POST['hid']."&page=");
			}
		if(isset($_POST['btnAction']))
		{
		 extract($_POST);
		 switch($optAction)
		  {
		  	case 0:
					$object->deleteSelect($chkAction);
    				redirect($pageName."?msg=del");
					break;
			case 1:
			 		$object->statusUpdatePublish($chkAction);
         			redirect($pageName."?msg=Publish");
			        break;
			case 2:
			        $object->statusUpdateUnPublish($chkAction);
					redirect($pageName."?msg=UnPublish");
					break;
			case 3:					
					for($i=0;count($categoryId)>$i;$i++)
					{
						$object->id=$categoryId[$i];
						$object->seq_no=$txtSeqNo[$i];
						$object->sequenceUpdate();
					}						
				 redirect($pageName."?msg=seq");	
		  } 		  
		}				
		if(isset($_GET['status']))
			{					
				$object->status();
				redirect($pageName."?msg=status");
			 } 
		if(isset($_GET['delete']))
			{
				$delRec=$object->selectRecById();	
				if($delRec[0]['image']!=""){	
					unlink(CATEGORY_BIG_IMAGE.$delRec[0]['image']);						
					unlink(CATEGORY_SMALL_IMAGE.$delRec[0]['image']);
				}	
				$object->delete();
				redirect($pageName."?msg=del");
			}
		if(isset($_GET['id']))
			{					
					$editRec=$object->selectRecById();
					$object->id=$menuCatListEdit[0]['subcatid'];	
					$menuCatListEditId=$object->selectRecById();					
			}		
			
			
			// Sorting Start 
	
			if (isset($_REQUEST['editTblBool']))
			   $editTblBool = $_REQUEST['editTblBool'];
			else
			   $editTblBool=0;
			
			if (isset($_REQUEST['ascdsc']))
			   $ascdsc = $_REQUEST['ascdsc'];
			else
			   $ascdsc=0;
			
			if (isset($_REQUEST['sortClName']))
			   $sortClName = $_REQUEST['sortClName'];
			else
			   $sortClName="";
			
			if (isset($_REQUEST['offset']))
			   $offset=$_REQUEST['offset'];
			else
			   $offset=0;
			
			
			if ($editTblBool!=1)
			{
				if ($ascdsc==0)
					$ascdsc = 1;
				else
					$ascdsc = 0;
			}
			
			// Sorting End

		$listRec=$object->paging();
		include("html/frmProCategory.php");	
	}
	
	function display($cid,$n,$selid,$ntdisplay) 
	{
//		echo "tush".$cid; exit;
		include("inc/clsObj.php");	
		$objProCat->id=$cid;
		$menuSubCatList=$objProCat->menuSubCategoryList();
		
		$n+=2;
		for($i=0;$i<count($menuSubCatList);$i++)
		{
			if($menuSubCatList[$i]['id']==$ntdisplay){}else{
		
		 ?>
		<option value="<?=$menuSubCatList[$i]['id'];?>" <?php if($menuSubCatList[$i]['id']==$selid){?> selected <?php }?> ><?php  echo str_repeat("&nbsp;",$n).'--'.$menuSubCatList[$i]['category_name'];?></option>
		<?
			}
		 display($menuSubCatList[$i]['id'],$n+5,$selid,$ntdisplay); 
		}
	}
	
	function frntRow($cid,$n) 
	{
		include("inc/clsObj.php");	
		$objProCat->id=$cid;
		$menuSubCatList=$objProCat->menuSubCategoryList();
		
		$n+=2;
		for($i=0;$i<count($menuSubCatList);$i++)
		{ ?>
            <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
                <td><?=$menuSubCatList[$i]['id'];?></td>
                    <td style="padding-left:25px;">
                    <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$menuSubCatList[$i]['seq_no'];?>"/> <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$menuSubCatList[$i]['id'];?>" size="3"/>
                    </td>
                    <td style="padding-left:<?=$n;?>px;">--<?=$menuSubCatList[$i]['category_name'];?></td>                
                    <td>
                    <?
                        frmActionButton($menuSubCatList[$i]['id'],$menuSubCatList[$i]['status'],$pageName,$menuSubCatList[$i]['category_name'],$heading);
                    ?>		               
                    </td>
             </tr>
		<? frntRow($menuSubCatList[$i]['id'],$n+20); 
		}
	}

?>