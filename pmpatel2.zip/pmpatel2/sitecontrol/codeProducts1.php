<?php

include("template.php");


function main()
{

	include("inc/clsObj.php");
	$heading="Products";	
	$object=$objProduct1;
	$pageName="codeProducts1.php";
	$object->limit=TOTAL_RECORDS;
	extract($_POST);
	
	/*
	echo "<pre>";
	print_r($_FILES);
	echo "</pre>";
	exit;
	*/
	
    $rnd=createRandomCode();
	$txtAreaDesc=$_POST['FCKeditor1'];					
	$txtAreaDesc=str_replace("\&quot;","", $txtAreaDesc);		
	$txtAreaDesc=str_replace('\\', '', $txtAreaDesc);				
	$txtAreaDesc=str_replace("\'","'", $txtAreaDesc);		
	$txtAreaDesc=str_replace("'","\'", $txtAreaDesc);		  				
	$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid )) ;
	
	if($_FILES['imageOriginal']['name']!=""){
		if(isset($hiddenImage)){
			unlink(PRODUCT_BIG_IMAGE.$hiddenImage);								
			unlink(PRODUCT_SMALL_IMAGE.$hiddenImage);
		}
	}			
	$object->catid=$Category;
	$object->sqno=$Sequence_No;
	$object->product_name=$product_name;
	
	// Added //
	$Alias_Name = preg_replace("![^a-z0-9]+!i", "-", $Alias_Name);
	$Alias_Name = strtolower($Alias_Name);
	$object->alias_name=$Alias_Name;
	// End //
	
	$object->seqNo=$txtSeqNo;
	
	$object->size=$Size;
	$object->description=$txtAreaDesc;
	$object->price=$Price;

	$object->metaTitle=$txtMetaTitle;
	$object->metaDescription=$txtMetaDescription;
	$object->metaKeywords=$txtMetaKeywords;

	$object->new_arrival=isset($New_Arrival) ? 1 : 0;
	$object->hot_product=isset($Hot_Product) ? 1 : 0;
	
	
	if($_FILES['imageOriginal']['name']!="")
				$object->image=uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],PRODUCT_SMALL_IMAGE,PRODUCT_SMALL_WIDTH,'');

	if($_FILES['imageOriginal']['name']!="")
		$object->image=uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],PRODUCT_BIG_IMAGE,PRODUCT_BIG_WIDTH,'');  

	if($_FILES['imageOriginal']['name']==""){
		if(isset($hiddenImage)){
				  $object->image=$hiddenImage;	
		}else{
				 $object->image=NULL;
		}			 	  
	}
	$object->status=isset($_GET['status']) ? $_GET['status'] : 1;
	if(isset($_POST['btnAdd'])){
		$object->insert();
		redirect($pageName."?msg=add");
	}
	if(isset($_POST['btnUpdate'])){
		$object->update();
		redirect($pageName."?msg=edit");
	}	
	if(isset($_POST['btnApply'])){		
		$object->update();
		redirect($pageName."?id=".$_POST['hid']."&page=");
	}		
	if(isset($_POST['btnAction']))	{
		switch($optAction){
			case 0:
					$object->deleteSelect($chkAction);
					redirect($pageName."?msg=del");
					break;
			case 1:
					$object->statusUpdatePublish($chkAction);
					redirect($pageName."?msg=Publish");
					break;
			case 2:
					$object->statusUpdateUnPublish($chkAction);
					redirect($pageName."?msg=UnPublish");
					break;
			case 3:
					for($i=0;count($categoryId)>$i;$i++){
						$object->id=$categoryId[$i];
						$object->seqno=$txtSeqNo[$i];
						$object->sequenceUpdate();				
					}	
					redirect($pageName."?msg=seq");					
			} 
		}						
	if(isset($_GET['id']))
		$editRec=$object->selectRecById();									
	if(isset($_GET['delete'])){				  	
		$delRec=$object->selectRecById();	
		if($delRec[0]['image']!=""){	
			unlink(PROPERTIES_BIG_IMAGE.$delRec[0]['image']);						
			unlink(PROPERTIES_SMALL_IMAGE.$delRec[0]['image']);
		}	
		$object->delete();
		redirect($pageName."?msg=del");
	}	
	if(isset($_GET['status'])){			
		$object->status();
		redirect($pageName."?msg=status");		
	}
	$listRec=$object->paging();	

	
    include("html/frmProducts1.php");
} 

function displaySubCat($cid,$n,$selid,$ntdisplay) 
	{
		include("inc/clsObj.php");	

		$objProduct1->catid=$cid;
		$menuSubCatList=$objProduct1->selectRecByCategoryId();
		
		
		
		$n+=2;
		for($i=0;$i<count($menuSubCatList);$i++)
		{ 
			if($menuSubCatList[$i]['id']==$ntdisplay){}else{
				?>
                <option value="<?=$menuSubCatList[$i]['id'];?>" <?php if($menuSubCatList[$i]['id']==$selid){?> selected <?php }?> ><?php  echo str_repeat("&nbsp;",$n).'--'.$menuSubCatList[$i]['product_name'];?></option>
                <?
			}
		?>
		
		<? displaySubCat($menuSubCatList[$i]['id'],$n+5,$selid,$ntdisplay); 
		}
	}
?>
