<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$menuCatListEdit=""){
include("inc/clsObj.php");
?>

<!-- Alias JS AND CSS ADDED -->
<script src="jquery.js" type="text/javascript" language="javascript"></script>
<script language="javascript">
	$(document).ready(function()
	{
		$("#Alias_Name").blur(function()
		{
			//remove all the class add the messagebox classes and start fading
			$("#msgbox").removeClass().addClass('messagebox').text('Checking...').fadeIn("slow");
			//check the username exists or not from ajax
			$.post("alias_availability.php?par=frontmenu",{ Alias_Name:$(this).val() } ,function(data)
			{	data = data.trim();
			
				//alert(data)
			
			  if(data=="no") //if username not avaiable
			  {
				$("#msgbox").fadeTo(200,0.1,function() //start fading the messagebox
				{ 
				  //add message and change the class of the box and start fading
				  $(this).html('This Alias name Already exists').addClass('messageboxerror').fadeTo(900,1);
				  document.getElementById("Alias_Name").focus();
				});		
			  }else{
				$("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
				{ 
				  //add message and change the class of the box and start fading
				  $(this).html('Alias available to create').addClass('messageboxok').fadeTo(900,1);	
				});
			  }
					
			});
	 
		});
	});
</script>
<style>
	.messagebox{
		position:absolute;
		width:100px;
		margin-left:30px;
		border:1px solid #c93;
		background:#ffc;
		padding:3px;
	}
	.messageboxok{
		position:absolute;
		width:auto;
		margin-left:30px;
		border:1px solid #349534;
		background:#C9FFCA;
		padding:3px;
		font-weight:bold;
		color:#008000;
		
	}
	.messageboxerror{
		position:absolute;
		width:auto;
		margin-left:30px;
		border:1px solid #CC0000;
		background:#F7CBCA;
		padding:3px;
		font-weight:bold;
		color:#CC0000;
	}
</style>
<!-- END -->

<form action="<?=$pageName;?>" method="post" name="frmManage" id="frmManage" enctype="multipart/form-data" onsubmit="validateFormMenu('Menu_name','','R','Menu_Position','','R','Menu_Type','','R');return document.MM_returnValue"> 
	<fieldset>
    	<legend>Menu Details</legend>
        <ul>
        	<li>
            	<label>Menu Name <span class="requiredt"> * </span> :</label>
            </li>
            <li>
            <input name="Menu_name" type="text" id="Menu_name" <?=(MENU_EDIT==0) ? "readonly" : "";?> value="<?=$menuCatListEdit[0]['menuName']; ?>" size="20">
            </li>
        </ul>
        

        <ul style="display:none;">
        	<li>
            	<label>Alias Name :</label>
            </li>
            <li><input type="text" name="Alias_Name" id="Alias_Name" value="<?=$menuCatListEdit[0]['alias_name'];?>" size="30"><span id="msgbox" style="display:none"></span>
            </li>
        </ul> 
        
        <ul>
        	<li>
        	  <label>Sequence No :</label>
        	</li>
            <li>
              <input name="txtSeqNo" type="text" id="txtSeqNo" value="<?=$menuCatListEdit[0]['seqNo']; ?>">
            </li>
        </ul>
        <ul>
        	<li>
        	  <label>Menu Level :</label>
        	</li>
            <li>
            <select name="optMenuLevel"  size="5" >
              <option value="0" selected="selected">--Select Level--</option>
             <?php 
			 	$menuMainCatList=$object->menuCategoryList();
			 for($i=0;$i<count($menuMainCatList);$i++){?>
             <option value="<?=$menuMainCatList[$i]['id'];?>"  <?php if($menuMainCatList[$i]['id']==$menuCatListEdit[0]['menuSubId']){?> selected <?php }?>><?=$menuMainCatList[$i]['menuName'];?></option>
                <?php 
                $object->id=$menuMainCatList[$i]['id'];
                $menuSubCatList=$object->menuSubCategoryList();
                if(count($menuSubCatList)>0)
                {
              	  display($menuMainCatList[$i]['id'],3);
                }	
                }	
                ?>            
            </select>
            </li>
        </ul>
<? 	if(MENU_EDIT==1)
	{ ?>
         <ul>
        	<li>
        	  <label>Menu Position <span class="requiredt"> * </span> :</label>
        	</li>
            <li>
            <select name="Menu_Position" id="Menu_Position">
                <option value="">-Select Menu Type--</option>                <option value="main" <?php if($menuCatListEdit[0]['menuPosition']=='main'){?> selected <?php }?>>main</option>
                <option value="top" <?php if($menuCatListEdit[0]['menuPosition']=='top'){?> selected <?php }?>>top</option>
                <option value="bottom" <?php if($menuCatListEdit[0]['menuPosition']=='bottom'){?> selected <?php }?>>bottom</option>
                <option value="left" <?php if($menuCatListEdit[0]['menuPosition']=='left'){?> selected <?php }?>>left</option>
                <option value="right" <?php if($menuCatListEdit[0]['menuPosition']=='right'){?> selected <?php }?>>right</option>
                <option value="article" <?php if($menuCatListEdit[0]['menuPosition']=='article'){?> selected <?php }?>>article</option>
            </select>           
            </li>
        </ul>
<? } ?>
        <ul>
        	<li>
        	  <label>Menu Type <span class="requiredt"> * </span> :</label>
        	</li>
            <li>
            <select name="Menu_Type" id="Menu_Type" onclick="show(this)" onkeyup="show(this)" >
                <option value="">-Select Menu Type--</option>        	
                <option value="1" <?php if($menuCatListEdit[0]['menuType']==1){?> selected <?php }?>>Upload File</option>
                <option value="2" <?php if($menuCatListEdit[0]['menuType']==2){?> selected <?php }?>>Detail</option>
                <option value="3" <?php if($menuCatListEdit[0]['menuType']==3){?> selected <?php }?>>Link</option>
            </select>           
            </li>
        </ul>
        
         <ul id="url" <?=($menuCatListEdit[0]['menuType']==3) ? "" : 'style="display:none;"'?>>
        	<li>
        	  <label>Url * :</label>
        	</li>
            <li>
	           	<input type="text" name="txtMenuLink" id="txtMenuLink"  value="<?=$menuCatListEdit[0]['menuUrl']; ?>"/>        
            </li>
        </ul>
         <ul>
        	<li>
        	  <label>Target Window :</label>
        	</li>
            <li>
            <select name="optTargetWindow">
                <option value="_self" <?php if($menuCatListEdit[0]['menuTargetWindow']=="_self"){?> selected <?php }?>>
                    Same Window
                </option>        
                <option value="_blank"<?php if($menuCatListEdit[0]['menuTargetWindow']=="_blank"){?> selected <?php }?>>
                    New Window
                </option>           
            </select>           
            </li>
        </ul>
   
         <ul id="uploadFile" <?=($menuCatListEdit[0]['menuType']==1) ? "" : 'style="display:none;"'?>>
        	<li>
        	  <label>File *:</label>
        	</li>
            <li><input type="file" name="fileUpload" id="fileUpload"/></li>
        </ul>
         <ul id="description" <?=($menuCatListEdit[0]['menuType']==2 || $menuCatListEdit[0]['menuType']==3) ? "" : 'style="display:none;"'?>>
        	<li>
        	  <label>Description :</label>
        	</li>
            <li>
			 <?
                $path = pathinfo($_SERVER['SCRIPT_NAME']);
                $sBasePath = $path['dirname']."/editor/";
                $oFCKeditor = new FCKeditor('FCKeditor1') ;
                $oFCKeditor->ToolbarSet = 'MyToolbar' ;
                $oFCKeditor->Height ='450';
                $oFCKeditor->BasePath	= $sBasePath ;
                $oFCKeditor->Config['SkinPath'] = $sBasePath . 'editor/skins/silver/' ;
                $oFCKeditor->Value	= $menuCatListEdit[0]['menuDesc'];
                $oFCKeditor->Create() ;
            ?>                
            </li>
        </ul>
        <ul>
        	<li>
        	  <label >Meta Title : </label>
        	</li>
            <li>
            <input type="text" name="txtMetaTitle" id="txtMetaTitle" value="<?=$menuCatListEdit[0]['metaTitle'];?>" /></li>
        </ul>
        <ul>
        	<li>
        	  <label>Meta Description : </label>
        	</li>
            <li>
            <textarea  name="txtMetaTag" id="txtMetaTag" ><?=$menuCatListEdit[0]['metaDescription']; ?></textarea>           
            </li>
        </ul>
		<ul>
        	<li>
        	  <label>Meta Keywords :</label>
        	</li>
            <li>
            <textarea  name="txtMetaKeywords" id="txtMetaKeywords"><?=$menuCatListEdit[0]['metaKeywords']; ?></textarea>           
            </li>
        </ul>
        <!--
        <ul>
        	<li>
        	  <label>Robots : </label>
        	</li>
            <li>
            <input type="text" name="txtRobots" id="txtRobots"  value="<?php //echo $menuCatListEdit[0]['menuRobots']; ?>"/>           
            </li>
        </ul>
         <ul>
        	<li>
        	  <label>Author :</label>
        	</li>
            <li>
            <input type="text" name="txtAuthor" id="txtAuthor"  value="<?php //echo $menuCatListEdit[0]['menuAuthor']; ?>"/>           
            </li>
        </ul>
        -->
         <ul>
        	<li>
        	   <label>&nbsp;</label>
        	</li>
            <li>
            	<? frmButtons($heading); if(isset($_GET['id']) && $_GET['id']!=''){
						frmApplyButtons($heading);
					}
					
					?>
           </li>
        </ul>        
    </fieldset>     
</form>
<? }function rowDisplay($pageName,$object,$heading,$menuMainCatList=""){?>

<? 
extract($_POST);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="7%" onclick="sortColumn('id');">Id. <div <? if($sortClName=='id' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='id' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>
    <th width="16%" onclick="sortColumn('seqNo');" >Seq. No. <div <? if($sortClName=='seqNo' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='seqNo' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>
    <th width="48%" onclick="sortColumn('menuName');" >Menu <div <? if($sortClName=='menuName' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='menuName' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>
    <th width="14%" onclick="sortColumn('menuPosition');" >Position <div <? if($sortClName=='menuPosition' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='menuPosition' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>    
    <th width="15%">Actions&nbsp;
    <input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>
  
   <?  
    if(count($menuMainCatList)>0)
	 {
	 	$colorflg=0;
         for($e=0;$e<count($menuMainCatList);$e++){
	     if ($colorflg==1){		$colorflg=0;?>
  		 <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
  		 <? }	else {	$colorflg=1;?>
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">
  		 <? } ?>		        
                <td><?=$menuMainCatList[$e]['id'];?></td>
                <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$menuMainCatList[$e]['seqNo'];?>"/>
                <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$menuMainCatList[$e]['id'];?>" size="3"/>
                </td>
                <td><?=$menuMainCatList[$e]['menuName'];?></td>  
                 <td><?=$menuMainCatList[$e]['menuPosition'];?></td>                
                <td>
                <?
				   	frmActionButton($menuMainCatList[$e]['id'],$menuMainCatList[$e]['status'],$pageName,$menuMainCatList[$e]['menuName'],$heading);
				?>
                </td>
	     </tr>	
           <?php 
			$object->id=$menuMainCatList[$e]['id'];
			$menuSubCatList=$object->menuSubCategoryList();
				if(count($menuSubCatList)>0)
				{
					displayRow($menuMainCatList[$e]['id'],3,$heading);
				}	
        	} 
		} 
		else 
		{
		?>
  		<tr>
        	<td colspan="5" align="center">
            	No Records Found...
            </td>
        </tr>
    <?php }?>    
  </table>
<?php }?>