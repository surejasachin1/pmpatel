<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$menuCatListEdit=""){
//echo "<pre>"; print_r($listEdit); exit;

?>



<!-- ALIAS JS AND CSS ADDED -->
<script src="jquery.js" type="text/javascript" language="javascript"></script>
<script language="javascript">
	$(document).ready(function()
	{
		$("#Alias_Name").blur(function()
		{
			//remove all the class add the messagebox classes and start fading
			$("#msgbox").removeClass().addClass('messagebox').text('Checking...').fadeIn("slow");
			//check the username exists or not from ajax
			
			<? 
				if(isset($_GET['id']) && $_GET['id']!=''){
					$param1 = "&ntid=".$_GET['id'];
				}else{
					$param1 = "";
				}
			?>
			
			$.post("alias_availability.php?par=category<?=$param1;?>",{ Alias_Name:$(this).val() } ,function(data)
			{	data = data.trim();
			
				//alert(data)
			
			  if(data=="no") //if username not avaiable
			  {
				$("#msgbox").fadeTo(200,0.1,function() //start fading the messagebox
				{ 
				  //add message and change the class of the box and start fading
				  $(this).html('This Alias name Already exists').addClass('messageboxerror').fadeTo(900,1);
				  document.getElementById("Alias_Name").focus();
				});		
			  }else{
				$("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
				{ 
				  //add message and change the class of the box and start fading
				  $(this).html('Alias available to create').addClass('messageboxok').fadeTo(900,1);	
				});
			  }
					
			});
	 
		});
	});
</script>
<style>
	.messagebox{
		position:absolute;
		width:100px;
		margin-left:30px;
		border:1px solid #c93;
		background:#ffc;
		padding:3px;
	}
	.messageboxok{
		position:absolute;
		width:auto;
		margin-left:30px;
		border:1px solid #349534;
		background:#C9FFCA;
		padding:3px;
		font-weight:bold;
		color:#008000;
		
	}
	.messageboxerror{
		position:absolute;
		width:auto;
		margin-left:30px;
		border:1px solid #CC0000;
		background:#F7CBCA;
		padding:3px;
		font-weight:bold;
		color:#CC0000;
	}
</style>
<!-- ALIAS END -->

<form action="<?=$pageName;?>" enctype="multipart/form-data" method="post" name="frmManage" onsubmit="return ValidateForm(this)">
	<fieldset>
    	<legend>Category Details</legend>
        <ul>
        	<li>

            	<label >Category Position (Main/Sub) :<? // echo $menuCatListEdit[0]['id']; ?></label>
            </li>
            <li>
            	<select name="optMenuPosition" id="optMenuPosition" size="10" style="width:220px;">
                    <option selected="selected" value="0">--Main Position--</option>
                    <? 
						$menuMainCatList=$object->menuCategoryList();
					for($i=0;$i<count($menuMainCatList);$i++) { 
						
						
						if($menuCatListEdit[0]['id']==$menuMainCatList[$i]['id']){
							
						}else{
					
					?>
                        <option value="<?=$menuMainCatList[$i]['id'];?>" <?php if($menuMainCatList[$i]['id']==$menuCatListEdit[0]['subcatid']){?> selected <?php }?>>
                            <?=$menuMainCatList[$i]['category_name'];?>
                        </option>
                    <?
						}
				
					
					display($menuMainCatList[$i]['id'],5,$menuCatListEdit[0]['subcatid'],$menuCatListEdit[0]['id']);
					
					 } ?>
                </select>
            </li>
        </ul>
        <ul>
        	<li>
        	  <label>Cagetory Name <span class="requiredt"> * </span> :</label>
        	</li>
            <li>
              <input name="txtMenuName" type="text" id="txtMenuName" value="<?=$menuCatListEdit[0]['category_name'];?>" />
            </li>
        </ul>
        
        <ul>
        	<li>
            	<label>Alias Name :</label>
            </li>
            <li>
<input type="text" name="Alias_Name" id="Alias_Name" value="<?=$menuCatListEdit[0]['alias_name'];?>" size="30">
			   <!--
               <input name="username" type="text" id="username" value="" maxlength="15" />
               -->
			   <span id="msgbox" style="display:none"></span>
            </li>
        </ul>
        
        <ul>
        	<li>
        	  <label >Sequence No :</label>
        	</li>
            <li><input name="txtSeqNo" type="text" id="txtSeqNo" value="<?=$menuCatListEdit[0]['seq_no'];?>"/></li>
        </ul>
        
        <ul>
        	<li>
            	<label >Image :</label>
            </li>
            <li>
           	  <input type="file" name="imageOriginal" id="imageOriginal"/>
            </li>
        </ul>
        
        <?php if(isset($_REQUEST['id'])){
		
//		echo "<pre>"; print_r($menuCatListEdit);
		?>
         <ul>
        	<li>
        	  <label>&nbsp;</label>
        	</li>
            <li>
            	<img src="<?php echo CATEGORY_SMALL_IMAGE.$menuCatListEdit[0]['image'];?>" alt="" width="100" height="100" />
                <input type="hidden" name="hiddenImage" id="hiddenImage" value="<?=$menuCatListEdit[0]['image'];?>"/>
            </li>
        </ul>
       <?php }?>
       <ul>
        	<li>
            	<label >New Arrival :</label>
            </li>
           <li>
           	  	<input type="checkbox" name="New_Arrival" id="New_Arrival" <?=$menuCatListEdit[0]['new_arrival']==1?'checked':'';?>/>
            </li>
        </ul>     
         
                     
     	<ul>
        	<li>
        	   <label >Description :</label>
        	</li>
            <li>
            	 	 <?
					
					 
                $path = pathinfo($_SERVER['SCRIPT_NAME']);
                $sBasePath = $path['dirname']."/editor/";
                $oFCKeditor = new FCKeditor('FCKeditor1') ;
                $oFCKeditor->ToolbarSet = 'MyToolbar' ;
                $oFCKeditor->Height ='450';
                $oFCKeditor->BasePath	= $sBasePath ;
                $oFCKeditor->Config['SkinPath'] = $sBasePath . 'editor/skins/silver/' ;
                $oFCKeditor->Value	= $menuCatListEdit[0]['description'];
                $oFCKeditor->Create() ;
            ?>                
      
           </li>
    </ul>    
    
     <ul>
        	<li>
        	  <label >Meta Title : </label>
        	</li>
            <li>
            <input type="text" name="txtMetaTitle" id="txtMetaTitle" value="<?=$menuCatListEdit[0]['metaTitle'];?>" /></li>
        </ul>
		
<ul>
        	<li>
        	  <label>Meta Description :</label>
        	</li>
            <li>
            <textarea  name="txtMetaDesc" id="txtMetaDesc"><?=$menuCatListEdit[0]['metaDescription']; ?></textarea>           
            </li>
        </ul>	
        
        <ul>
        	<li>
        	  <label>Meta Keywords :</label>
        	</li>
            <li>
            <textarea  name="txtMetaKeywords" id="txtMetaKeywords"><?=$menuCatListEdit[0]['metaKeywords']; ?></textarea>           
            </li>
        </ul>
	
         <ul>
        	<li>
        	   <label >&nbsp;</label>
        	</li>
            <li>
            	  <? frmButtons($heading); if(isset($_GET['id']) && $_GET['id']!=''){
						frmApplyButtons($heading);
					}
					?>
           </li>
        </ul>        
    </fieldset> 
     <input type=hidden name=Validation 
        value="Field=txtMenuName|Alias=Category Name|Validate=Blank"/>        
</form>
<? } 

function rowDisplay($pageName,$object,$heading,$menuMainCatListRec=""){
extract($_POST);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="7%" onclick="sortColumn('id');">Id.<div <? if($sortClName=='id' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='id' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>
    <th width="15%" onclick="sortColumn('seq_no');" >Sequence. No.<div <? if($sortClName=='seq_no' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='seq_no' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>
    <th width="59%" onclick="sortColumn('category_name');" >Cagetory / Sub Category Name<div <? if($sortClName=='category_name' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='category_name' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>    
    <th width="19%">Actions&nbsp;
    <input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>
  
   <?  
    if(count($menuMainCatListRec)>0)
	 {
       for($e=0;$e<count($menuMainCatListRec);$e++){
	   ?>		 
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">         
                <td><?=$menuMainCatListRec[$e]['id'];?></td>
                <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$menuMainCatListRec[$e]['seq_no'];?>"/>
                <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$menuMainCatListRec[$e]['id'];?>" size="3"/>
                </td>
                <td><?=$menuMainCatListRec[$e]['category_name'];?></td>                
                <td>
                 <?
				   	frmActionButton($menuMainCatListRec[$e]['id'],$menuMainCatListRec[$e]['status'],$pageName,$menuMainCatListRec[$e]['category_name'],$heading);
				?>	              
                </td>
	     </tr>
			<?  
				frntRow($menuMainCatListRec[$e]['id'],20);
			 ?>
  <? } } else {?>
  		<tr>
        	<td colspan="5" align="center">
            	No Records Found...
            </td>
        </tr>
    <?php }?>    
  </table>
<?php } ?>