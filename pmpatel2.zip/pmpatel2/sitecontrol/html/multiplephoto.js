// JavaScript Document
function addphotofields()
{
	alert("WIP");
}