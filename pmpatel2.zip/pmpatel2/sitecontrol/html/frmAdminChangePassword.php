<div style="padding:10px;background:url(images/header-back.gif);border:#999999 1px solid">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="83%" class="title">
    	Change Password  
    </td>
  </tr>
</table>
</div>
<div id="form_container">
<form name="frmAdminChangePassword" action="codeAdminChangePassword.php" method="post" onsubmit="return ValidateForm(this)" >
 	<fieldset>
    	<legend>Enter Password Detail</legend>
         <ul>
        	<li>
            	<label >User Name :</label>
            </li>
            <li>
            	<?=$_SESSION['membername'];?>
            </li>
        </ul>
        <ul>
        	<li>
            	<label >Old Password <span class="requiredt"> * </span> :</label>
            </li>
            <li>
            	<input type="password" name="txtOldPassword" id="txtOldPassword">
            </li>
        </ul>
        <ul>
        	<li>
        	  <label>New Password <span class="requiredt"> * </span> :</label>
        	</li>
            <li>
               <input type='password' name="txtNewPassword" id="txtNewPassword">
            </li>
        </ul>
        <ul>
        	<li>
        	  <label >Confirm Password <span class="requiredt"> * </span> :</label>
        	</li>
            <li>
            	<input type='password' name="txtConfirmPassword" id="txtConfirmPassword" >
            </li>
        </ul>
        
         <ul>
        	<li>
        	   <label >&nbsp;</label>
        	</li>
            <li>
            	  <input type='submit' value='Change Password' name="btnAdminChangePassword" class="button" id="btnAdminChangePassword">
                  <a href="frmMain.php"><input type='button' value='Cancel' name="btnCancel" class="button" id="btnCancel"></a>
            </li>
        </ul>        
    </fieldset> 
    <input type=hidden name=Validation
                    value="Field=txtOldPassword|Alias=Old Password|Validate=Blank^
                    Field=txtNewPassword|Alias=New Password|Validate=Blank^
                    Field=txtConfirmPassword|Alias=Password|Validate=Blank^                    
                    Field=txtNewPassword|Alias=Confirm Password|Validate=CONFIRMPASSWORD|CompareTo=txtConfirmPassword"
                    />        
</form>
</div>