<?php
	
	
	frmHeader($heading,$pageName);	
	

	
  if(isset($_REQUEST['btnAddCategory']) or isset($_REQUEST['id'])) { 
  
  ?>
<div id="form_container">
<? details($pageName,$object,$heading,$editRec);?>
</div>
<?php 
	} else {
		frmMessage();
		frmPaging($object);
		
		if(basename($_SERVER['PHP_SELF'])=='codeManageUser.php')
		{
		  group(); 
		}

?>
<form action="" id="tmpFrm" name="tmpFrm" method="post">

    <input type="hidden" name="editTbl" value="<? echo $editTbl?>">
	<input type="hidden" name="editTblBool" value="<? echo $editTblBool?>">
	<input type="hidden" name="newTbl" value="<? echo $newTbl?>">
	<input type="hidden" name="rowNo" value="<? echo $rowNo?>">
	<input type="hidden" name="ascdsc" value="<? echo $ascdsc?>">
	<input type="hidden" id="sortClName" name="sortClName" value="<? echo $sortClName?>">
	<input type="hidden" name="offset" value="<? echo $offset?>">
    
</form>

<form action="<?=$pageName;?>" method="post" name="frmManageDetails" onSubmit="return ValidateForm(this)">
<?php 	frmAction(); ?>
<div class="table_border">	
	<?	rowDisplay($pageName,$object,$heading,$listRec);?>
</div>
<input type=hidden name=Validation value="Field=optAction|Alias=Action|Validate=Combo"/>

</form>



<?php } ?>