<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$listEdit=""){
include("inc/clsObj.php");
?>
<form action="<?=$pageName;?>" method="post" name="frmManage" enctype="multipart/form-data" onsubmit="return ValidateForm(this)"> 
   <fieldset>
    	<legend>Product Details</legend>          	
        <ul>
        	<li>
            	<label >Product Name :</label>
            </li>
            <li>
           	  	<input type="text" name="Product_Name" id="Product_Name" value="<?=$listEdit[0]['product_name'];?>" size="30">
            </li>
        </ul>   
       
         <ul>
        	<li>
        	  <label>Category :</label>
        	</li>
            <li>
            <select name="Category"  id="Category" size="5" >
              <option value="0" selected="selected">--Select Category--</option>
             <?php
			 $listCategory=$objProCat->selectPublishedCategories();	
			  for($i=0;$i<count($listCategory);$i++){?>
             <option style="font-weight:bold;" value="<?=$listCategory[$i]['id'];?>"  <?php if($listCategory[$i]['id']==$listEdit[0]['catid']){?> selected <?php }?>><?=$listCategory[$i]['category_name'];?></option>
                <?php 
                $objProCat->subcatid=$listCategory[$i]['id'];
                $subListCategory=$objProCat->selectPublishedSubCategories();
                if(count($subListCategory)>0)
                {
              	  for($subcat=0;$subcat<count($subListCategory);$subcat++){?>
                  <option value="<?=$subListCategory[$subcat]['id'];?>"  <?php if($subListCategory[$subcat]['id']==$listEdit[0]['catid']){?> selected <?php }?>>|----<?=$subListCategory[$subcat]['category_name'];?></option>
				  <?
				  }
                }	
                }	
                ?>            
            </select>
            </li>
        </ul>
		<ul>
        	<li>
            	<label >Size :</label>
            </li>
            <li>
           	  	<input type="text" name="Size" id="Size" value="<?=$listEdit[0]['size'];?>">
            </li>
        </ul>  
          
        <ul>
        	<li>
            	<label >Price :</label>
            </li>
            <li>
           	  	<input type="text" name="Price" id="Price" value="<?=$listEdit[0]['price'];?>">
            </li>
        </ul> 
        <ul>
        	<li>
            	<label >Sequence No. :</label>
            </li>
            <li>
           	  	<input type="text" name="Sequence_No" id="Sequence_No" value="<?=$listEdit[0]['sqno'];?>">
            </li>
        </ul> 
          
         <ul>
        	<li>
            	<label >Image :</label>
            </li>
            <li>
           	  <input type="file" name="imageOriginal" id="imageOriginal"/>
            </li>
        </ul>
        
        <?php if(isset($_REQUEST['id'])){?>
         <ul>
        	<li>
        	  <label>&nbsp;</label>
        	</li>
            <li>
            	<img src="<?php echo PRODUCT_SMALL_IMAGE.$listEdit[0]['image'];?>" alt="" width="100" height="100" />
                <input type="hidden" name="hiddenImage" id="hiddenImage" value="<?=$listEdit[0]['image'];?>"/>
            </li>
        </ul>
       <?php }?>
       <ul>
        	<li>
            	<label >New Arrival :</label>
            </li>
           <li>
           	  	<input type="checkbox" name="New_Arrival" id="New_Arrival" <?=$listEdit[0]['new_arrival']==1?'checked':'';?>/>
            </li>
        </ul>     
         
                     
     	<ul>
        	<li>
        	   <label >Description :</label>
        	</li>
            <li>
            	 	 <?
                $path = pathinfo($_SERVER['SCRIPT_NAME']);
                $sBasePath = $path['dirname']."/editor/";
                $oFCKeditor = new FCKeditor('FCKeditor1') ;
                $oFCKeditor->ToolbarSet = 'MyToolbar' ;
                $oFCKeditor->Height ='450';
                $oFCKeditor->BasePath	= $sBasePath ;
                $oFCKeditor->Config['SkinPath'] = $sBasePath . 'editor/skins/silver/' ;
                $oFCKeditor->Value	= $listEdit[0]['description'];
                $oFCKeditor->Create() ;
            ?>                
      
           </li>
    </ul>
    	<ul>
        	<li>
        	  <label >Meta Title : </label>
        	</li>
            <li>
            <input type="text" name="txtMetaTitle" id="txtMetaTitle" value="<?=$listEdit[0]['metaTitle'];?>" /></li>
        </ul>
        <ul>
        	<li>
        	  <label>Meta Description : </label>
        	</li>
            <li>
            <textarea  name="txtMetaDescription" id="txtMetaDescription" ><?=$listEdit[0]['metaDescription']; ?></textarea>           
            </li>
        </ul>
		<ul>
        	<li>
        	  <label>Meta Keywords :</label>
        	</li>
            <li>
            <textarea  name="txtMetaKeywords" id="txtMetaKeywords"><?=$listEdit[0]['metaKeywords']; ?></textarea>           
            </li>
        </ul>
            
    <ul>
        	<li>
        	   <label >&nbsp;</label>
        	</li>
            <li>
            	  <? frmButtons($heading);?>
            </li>
        </ul></fieldset>      
</form>
<? }

function rowDisplay($pageName,$object,$heading,$listRec=""){
include("inc/clsObj.php");
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="11%">Id.</th>     
    <th width="24%">Product Name</th>  
    <th width="46%">Category</th>
    <th width="19%">Actions&nbsp;
    <input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>  
   <?  
    if(count($listRec)>0)
	 {
	 	$colorflg=0;
         for($e=0;$e<count($listRec);$e++){
	     if ($colorflg==1){	$colorflg=0;?>
  		 <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
  		 <? }	else {	$colorflg=1;?>
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">
  		 <? } ?>		        
                <td><?=$listRec[$e]['id'];?></td>  
				<td><?=$listRec[$e]['product_name'];?></td>
                <td>
				<? if($listRec[$e]['catid']!=0)
				{
					$objProCat->id = $listRec[$e]['catid']; 
					echo $objProCat->getCategoriesPath_backend(); 
				}
				else
					echo "-";
					?>
				</td>
                <td>
				<? frmActionButton($listRec[$e]['id'],$listRec[$e]['status'],$pageName,$listRec[$e]['name'],$heading); ?>
                </td>
	     </tr>
           <?php }}else {?>
  		<tr>
        	<td colspan="7" align="center">
            	No Records Found...
			</td>
        </tr>
    <?php }?>    
  </table>
<? } ?>