<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$listEdit=""){
include("inc/clsObj.php");
?>
<form action="<?=$pageName;?>" method="post" name="frmManage" enctype="multipart/form-data"  onsubmit="return ValidateForm(this)"> 
   <fieldset>
    	<legend><?=$heading;?> Details</legend>  
		<ul>
        	<li>
        	  <label>Name :</label>
        	</li>
            <li>
			 <?=$listEdit[0]['name'];?>    
            </li>
        </ul>              

		<ul>
        	<li>
        	  <label >Email :</label>
        	</li>
            <li>
			 <?=$listEdit[0]['email'];?>    
            </li>
        </ul>              
     	<ul>
        	<li>
        	   <label >&nbsp;</label>
        	</li>
            <li>
            	  <? frmButtons($heading);?>
           </li>
    </ul>        
    </fieldset>                                           
</form>
<? }function rowDisplay($pageName,$object,$heading,$listRec=""){
include("inc/clsObj.php");
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="17%">Id.</th>     
    <th width="22%">Name</th>
  <th width="22%">Email</th>
    <th width="11%">Actions&nbsp;<input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>  
   <?  
    if(count($listRec)>0)
	 {
	 	$colorflg=0;
         for($e=0;$e<count($listRec);$e++){
	     if ($colorflg==1){		$colorflg=0;?>
  		 <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
  		 <? }	else {	$colorflg=1;?>
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">
  		 <? } ?>		        
         
                <td><?=$listRec[$e]['id'];?></td> 
                <td><?=$listRec[$e]['name'];?></td>
                <td><?=$listRec[$e]['email'];?></td>
                <td>
                <? frmActionButton($listRec[$e]['id'],$listRec[$e]['status'],$pageName,$listRec[$e]['name'],$heading); ?>
                </td>
	     </tr>	
         
    
           <?php }
		   ?>
           	     <tr>
         	<td colspan="4" valign="middle" align="right"><a style="display:block;text-decoration:none;background-color:#333333;color:#FFFFFF;font-weight:bold;width:110px;height:20px;text-align:center;vertical-align:middle;padding-top:2px;" href="subscriber.php">Export to excel</a></td>
         </tr>
           <?
		   
		   }else {?>
  		<tr>
        	<td colspan="5" align="center">
            	No Records Found...
            </td>
        </tr>
    <?php }?>    
  </table>
<? } ?>