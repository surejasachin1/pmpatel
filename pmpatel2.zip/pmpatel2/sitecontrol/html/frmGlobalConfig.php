<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$listEdit=""){
include("inc/clsObj.php");
?>
<form action="<?=$pageName;?>" method="post" name="frmManage" onsubmit="return ValidateForm(this)" enctype="multipart/form-data">
	<fieldset>
    	<legend><?=$heading;?> Details</legend>                
        <ul>
        	<li>
        	  <label>Name<span class="requiredt"> * </span> :</label>
        	</li>
            <li>
             	<input type="text" name="name" id="name" value="<?=$listEdit[0]['name'];?>"/>
            </li>
        </ul> 
        
         <ul>
        	<li>
        	  <label>Sequence No :</label>
        	</li>
            <li>
              <input name="txtSeqNo" type="text" id="txtSeqNo" value="<?=$listEdit[0]['seqNo']; ?>">
            </li>
        </ul>
        
         <ul>
        	<li>
        	  <label>Constant Name :</label>
        	</li>
            <li>
             	<input type="text" name="constantName" id="constantName" <? if($_GET['id']!=''){echo "disabled";} ?> value="<?=$listEdit[0]['constantName'];?>"/>
            </li>
        </ul> 
        
         <ul>
        	<li>
        	  <label>Constant Value :</label>
        	</li>
            <li>
             	<input type="text" name="constantValue" id="constantValue" value="<?=$listEdit[0]['constantValue'];?>"/>
            </li>
        </ul>  
         
               
        <ul>
        	<li>
        	   <label >&nbsp;</label>
        	</li>
            <li>
            	  <? frmButtons($heading);?> 
           </li>
        </ul>        
    </fieldset> 
   
    	<input type=hidden name=Validation 
        value="Field=title|Alias=Testimonial Title|Validate=Blank"/>        	
   
     
</form>
<? } function rowDisplay($pageName,$object,$heading,$listRec=""){
	include("inc/clsObj.php");
?>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="10%">Id.</th>    
    <th width="10%">Seq. No.</th>
     <th width="10%">Name</th>  
     <th width="20%">Constant Name</th>   
     <th width="20%">Constant Value</th>    
	
    <th width="11%">Actions&nbsp;<input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>
  
   <? if(count($listRec)>0)	 {
      for($e=0;$e<count($listRec);$e++){
	   ?>		 
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">                
         		<td><?=$listRec[$e]['id'];?></td>   
				<td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$listRec[$e]['seqNo'];?>"/>
                <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$listRec[$e]['id'];?>" size="3"/>
                </td>
                <td><?=$listRec[$e]['name'];?></td>  
                <td><?=$listRec[$e]['constantName'];?></td>  
                <td><?=$listRec[$e]['constantValue'];?></td>  
                <td>
                 <?
				   	frmActionButton($listRec[$e]['id'],$listRec[$e]['status'],$pageName,$listRec[$e]['title'],$heading);
				?>	              
                </td>
	     </tr>            		 
         <?php } } else {?>
  		<tr>
        	<td colspan="5" align="center">
            	No Records Found...
            </td>
        </tr>
    <?php }?>    
  </table>
<?php } ?>