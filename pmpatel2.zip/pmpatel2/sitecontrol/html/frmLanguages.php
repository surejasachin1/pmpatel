<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$listEdit=""){
include("inc/clsObj.php");
?>
<form action="<?=$pageName;?>" method="post" name="frmManage" enctype="multipart/form-data"  onsubmit="return ValidateForm(this)"> 
   <fieldset>
    	<legend><?=$heading;?> Details</legend>        
		<ul>
        	<li>
            	<label >Title * :</label>
            </li>
            <li>
            	<input type="text" name="title" id="title" value="<?=$listEdit[0]['title'];?>"/>
            </li>
        </ul> 
       
        
        <ul>
        	<li>
        	  <label>Sequence No :</label>
        	</li>
            <li>
              <input name="txtSeqNo" type="text" id="txtSeqNo" value="<?=$listEdit[0]['seqNo']; ?>">
            </li>
        </ul>
        
       
     	<ul>
        	<li>
        	   <label >&nbsp;</label>
        	</li>
            <li>
            	  <? frmButtons($heading);?>
           </li>
    </ul>        
    </fieldset>  
     <?php if(isset($_REQUEST['id'])){?>
      <input type=hidden name=Validation value="Field=title|Alias=Photo Name|Validate=Blank"/>
     <? } else {?> 
    <input type=hidden name=Validation value="Field=title|Alias=Photo Name|Validate=Blank^
                                              Field=imageOriginal|Alias=Project Image|Validate=Blank"/>      
     <? }?>                                         
</form>
<? }function rowDisplay($pageName,$object,$heading,$listRec=""){
include("inc/clsObj.php");
?>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="17%">Id.</th>   
    <th width="22%">Seq. No</th>    
    <th width="22%">Language Name</th>  
    <th width="11%">Actions&nbsp;<input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>  
   <?  
    if(count($listRec)>0)
	 {
	 	$colorflg=0;
         for($e=0;$e<count($listRec);$e++){
	     if ($colorflg==1){		$colorflg=0;?>
  		 <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
  		 <? }	else {	$colorflg=1;?>
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">
  		 <? } ?>		        
                <td><?=$listRec[$e]['id'];?></td>          
                <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$listRec[$e]['seqNo'];?>"/>
                                <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$listRec[$e]['id'];?>" size="3"/>

                </td>                 
                <td><?=$listRec[$e]['title'];?></td>                                
                <td>
                <? frmActionButton($listRec[$e]['id'],$listRec[$e]['status'],$pageName,$listRec[$e]['name'],$heading);	 ?>
                </td>
	     </tr>	
           <?php }}else {?>
  		<tr>
        	<td colspan="5" align="center">
            	No Records Found...
            </td>
        </tr>
    <?php }?>    
  </table>
<? } ?>