<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$listEdit=""){
include("inc/clsObj.php");
?>

<form action="<?=$pageName;?>" method="post"  enctype="multipart/form-data" onsubmit="return ValidateForm(this)" name="mutiple_file_upload_form" id="mutiple_file_upload_form"> 
   <fieldset>
    	<legend>Upload Files</legend>          	
		 <ul>
        	<li><label>Upload File :</label></li>
            <li><input type="file" name="uploads" id="uploads" value="<?php echo $listEdit[0]['file_path']; ?>" /></li>
        </ul>
		<? if($listEdit[0]['file_path']!=""){ ?>
		<ul>
        	<li><label>File :</label></li>
            <li><?php $filetype=explode("/",$listEdit[0]['file_type']);
						if($filetype[0]=="image"){ ?>
						<img src="../<? echo $listEdit[0]['file_path'];?>" width="200" />
						<? }else{ ?>
						<a href="../<? echo $listEdit[0]['file_path'];?>" target="_blank">Download Here</a>
				 <? } ?>
			 </li>
        </ul>
		<? } ?>
     	</fieldset>
		
        <ul>
        	<li>
        	   <label>&nbsp;</label>
        	</li>
            <li>
            	  <? frmButtons($heading); if(isset($_GET['id']) && $_GET['id']!=''){
						frmApplyButtons($heading);
					}
					?>
                    
            </li>
        </ul>
		<input type=hidden name=Validation value="Field=uploads|Alias=Upload File|Validate=Blank"/> 
</form>
<? }

function rowDisplay($pageName,$object,$heading,$listRec=""){
include("inc/clsObj.php");
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="5%">Id.</th>    
    <th width="20%">File Name</th>   
	<th width="20%">File Type</th>
    <th width="20%">File Path</th>
	 <th width="20%">Image / Document</th>
    <th width="15%">Actions&nbsp;
    <input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>  
   <?  
    if(count($listRec)>0)
	 {
	 	$colorflg=0;
         for($e=0;$e<count($listRec);$e++){
	     if ($colorflg==1){	$colorflg=0;?>
  		 <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
  		 <? }	else {	$colorflg=1;?>
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">
  		 <? } ?>		        
                <td><?=$listRec[$e]['id'];?></td> 
                <td><?=$listRec[$e]['file_name'];?></td> 
				<td><?=$listRec[$e]['file_type'];?></td>
                <td><?=$listRec[$e]['file_path'];?></td>
				 <td><?php $filetype=explode("/",$listRec[$e]['file_type']);
						if($filetype[0]=="image"){ ?>
						<img src="../<? echo $listRec[$e]['file_path'];?>" width="180" height="150" />
						<? }else{ ?>
						<a href="../<? echo $listRec[$e]['file_path'];?>" target="_blank">Download</a>
				 <? } ?></td>
                <td>
				<? frmActionButton($listRec[$e]['id'],$listRec[$e]['status'],$pageName,$listRec[$e]['file_name'],$heading); ?>
                </td>
	     </tr>
           <?php }}else {?>
  		<tr>
        	<td colspan="7" align="center">
            	No Records Found...
			</td>
        </tr>
    <?php }?>    
  </table>
<? } ?>