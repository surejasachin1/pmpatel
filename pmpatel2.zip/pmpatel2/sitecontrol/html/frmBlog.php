<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$listEdit=""){
include("inc/clsObj.php");
?>
<!-- Added New Code For Multiple Image -->
<!-- Added New Code For Multiple Image -->
<script type="text/javascript">
	function add_file_field(){
		var container=document.getElementById('file_container');
		var file_field=document.createElement('input');
		file_field.name='images[]';
		file_field.type='file';
		// Added
		var file_field1=document.createElement('input');
		file_field1.name='img_title[]';
		file_field1.type='text';
		file_field1.value='Enter Title';
		
		var file_field2=document.createElement('input');
		file_field2.name='img_sequence[]';
		file_field2.type='text';
		file_field2.value='Enter Sequence';
		
		var file_field21=document.createElement('input');
		file_field21.name='price[]';
		file_field21.type='text';
		file_field21.value='Enter Price';
		
		var file_field3=document.createElement('br');
		// End
		container.appendChild(file_field);
		// Added
		container.appendChild(file_field1);
		container.appendChild(file_field2);
		container.appendChild(file_field21);
		container.appendChild(file_field3);
		// End
		var br_field=document.createElement('br');
		container.appendChild(br_field);
	}
	
	function getXMLHttp(){
	  var xmlHttp
	  try{
		//Firefox, Opera 8.0+, Safari
		xmlHttp = new XMLHttpRequest();
	  }
	  catch(e){
		//Internet Explorer
		try{
		  xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
		}
		catch(e){
		  try{
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		  }
		  catch(e){
			alert("Your browser does not support AJAX!")
			return false;
		  }
		}
	  }
	  return xmlHttp;
	}
	
	function MakeRequest(getId, getImg){
	  var xmlHttp = getXMLHttp();
	  xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4){
		  HandleResponse(xmlHttp.responseText);
		}
	  }
	  xmlHttp.open("GET", "multiple_ajax.php?property_id="+getId+"&img="+getImg, true); 
	  xmlHttp.send(null);
	}
	
	function HandleResponse(response){
	  	alert(response);
		window.location.reload();
	}
	
	function MakeUpdateRequest(getId, getTitle, getSeq){
	  var xmlHttp = getXMLHttp();
	  xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4){
		  HandleUpdateResponse(xmlHttp.responseText);
		}
	  }
	  xmlHttp.open("GET", "multiple_ajax.php?img_id="+getId+"&title="+getTitle+"&seq="+getSeq, true); 
	  xmlHttp.send(null);
	}
	
	function HandleUpdateResponse(response){
	  	alert(response);
		//window.location.reload();
	}

</script>
<!-- End  name="frmManage"-->


<!-- ALIAS JS AND CSS ADDED -->
<script src="jquery.js" type="text/javascript" language="javascript"></script>
<script language="javascript">
	$(document).ready(function()
	{
		$("#Alias_Name").blur(function()
		{
			//remove all the class add the messagebox classes and start fading
			$("#msgbox").removeClass().addClass('messagebox').text('Checking...').fadeIn("slow");
			//check the username exists or not from ajax
			
			<? 
				if(isset($_GET['id']) && $_GET['id']!=''){
					$param1 = "&ntid=".$_GET['id'];
				}else{
					$param1 = "";
				}
			?>
			
			$.post("alias_availability.php?par=product<?=$param1;?>",{ Alias_Name:$(this).val() } ,function(data)
			{	data = data.trim();
			
				//alert(data)
			
			  if(data=="no") //if username not avaiable
			  {
				$("#msgbox").fadeTo(200,0.1,function() //start fading the messagebox
				{ 
				  //add message and change the class of the box and start fading
				  $(this).html('This Alias name Already exists').addClass('messageboxerror').fadeTo(900,1);
				  document.getElementById("Alias_Name").focus();
				});		
			  }else{
				$("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
				{ 
				  //add message and change the class of the box and start fading
				  $(this).html('Alias available to create').addClass('messageboxok').fadeTo(900,1);	
				});
			  }
					
			});
	 
		});
	});
</script>
<style>
	.messagebox{
		position:absolute;
		width:100px;
		margin-left:30px;
		border:1px solid #c93;
		background:#ffc;
		padding:3px;
	}
	.messageboxok{
		position:absolute;
		width:auto;
		margin-left:30px;
		border:1px solid #349534;
		background:#C9FFCA;
		padding:3px;
		font-weight:bold;
		color:#008000;
		
	}
	.messageboxerror{
		position:absolute;
		width:auto;
		margin-left:30px;
		border:1px solid #CC0000;
		background:#F7CBCA;
		padding:3px;
		font-weight:bold;
		color:#CC0000;
	}
</style>
<!-- ALIAS END -->


<form action="<?=$pageName;?>" method="post"  enctype="multipart/form-data" onSubmit="return ValidateForm(this)" name="mutiple_file_upload_form" id="mutiple_file_upload_form"> 
   <fieldset>
    	<legend>Testimonials Details</legend>          	
        <ul>
        	<li>
            	<label >Name <span class="requiredt"> * </span> :</label>
            </li>
            <li>
           	  	<input type="text" name="product_name" id="product_name" value="<?=$listEdit[0]['product_name'];?>" size="30">
            </li>
        </ul>   
        
        <ul>
            <li>
                <label>Alias Name :</label>
            </li>
            <li>
<input type="text" name="Alias_Name" id="Alias_Name" value="<?=$listEdit[0]['alias_name'];?>" size="30">
               <!--
               <input name="username" type="text" id="username" value="" maxlength="15" />
               -->
               <span id="msgbox" style="display:none"></span>
            </li>
        </ul>
        <ul>
        	<li>
            	<label>Posted By :</label>
            </li>
            <li>
<input type="text" name="posted_by" id="posted_by" value="<?=$listEdit[0]['posted_by'];?>" size="30">
			   <!--
               <input name="username" type="text" id="username" value="" maxlength="15" />
               -->
			   <span id="msgbox" style="display:none"></span>
            </li>
        </ul>
        
        <ul>
        	<li>
        	  <label>Sequence No :</label>
        	</li>
            <li>
              <input name="txtSeqNo" type="text" id="txtSeqNo" value="<?=$listEdit[0]['seqNo']; ?>">
            </li>
        </ul>
        
        <ul>
        	<li>
        	  <label>Category :</label>
        	</li>
            <li>
            <? $listCategory=$objGstCat->menuCategoryList(); ?>
            <select name="Category"  id="Category" style="width:220px;" >
              <option value="0" selected="selected">--Select Category--</option>
		<?php for($i=0;$i<count($listCategory);$i++){?>
             <option value="<?=$listCategory[$i]['id'];?>"  <?php if($listCategory[$i]['id']==$listEdit[0]['catid']){?> selected <?php }?>><?=$listCategory[$i]['category_name'];?></option>
                <?
					displaySubCat($listCategory[$i]['id'],5,$listEdit[0]['catid']);
                }	
                ?>            
            </select>
            </li>
        </ul>
		<ul style="display:none">
        	<li>
            	<label >Size :</label>
            </li>
            <li>
           	  	<input type="text" name="Size" id="Size" value="<?=$listEdit[0]['size'];?>">
            </li>
        </ul>  
        <ul style="display:none">
        	<li>
            	<label >Price :</label>
            </li>
            <li>
           	  	<input type="text" name="Price" id="Price" value="<?=$listEdit[0]['price'];?>">
            </li>
        </ul> 
        <ul style="display:none">
        	<li>
            	<label >Sequence No. :</label>
            </li>
            <li>
           	  	<input type="text" name="Sequence_No" id="Sequence_No" value="<?=$listEdit[0]['sqno'];?>">
            </li>
        </ul> 
        <ul style="display:none">
        	<li>
            	<label >Image :</label>
            </li>
            <li>
           	  <input type="file" name="imageOriginal" id="imageOriginal"/>
            </li>
        </ul>
        <?php if(isset($_REQUEST['id'])){?>
        <ul>
        	<li>
        	  <label>&nbsp;</label>
        	</li>
            <li>
                <img src="<?php echo EVENT_BIG_IMAGE.$listEdit[0]['image'];?>" alt="" width="100" height="100" />
                <input type="hidden" name="hiddenImage" id="hiddenImage" value="<?php echo $listEdit[0]['image']; ?>"/>
            </li>
        </ul>
        <?php }?>
        <ul>
        	<li>
            	<label >New Arrival :</label>
            </li>
           <li>
           	  	<input type="checkbox" name="New_Arrival" id="New_Arrival" <?=$listEdit[0]['new_arrival']==1?'checked':'';?>/>
            </li>
        </ul>     
        <ul>
        	<li><label>Hot Event :</label></li>
            <li><input type="checkbox" name="Hot_Product" id="Hot_Product" <?=$listEdit[0]['hot_product']==1?'checked':'';?>/></li>
        </ul>    
     	<ul>
        	<li>
        	   <label >Description :</label>
        	</li>
            <li>
            <?
                $path = pathinfo($_SERVER['SCRIPT_NAME']);
                $sBasePath = $path['dirname']."/editor/";
                $oFCKeditor = new FCKeditor('FCKeditor1') ;
                $oFCKeditor->ToolbarSet = 'MyToolbar' ;
                $oFCKeditor->Height ='450';
                $oFCKeditor->BasePath	= $sBasePath ;
                $oFCKeditor->Config['SkinPath'] = $sBasePath . 'editor/skins/silver/' ;
                $oFCKeditor->Value	= $listEdit[0]['description'];
                $oFCKeditor->Create() ;
            ?>                
      
           </li>
    	</ul>
    	<ul >
        	<li>
        	  <label >Meta Title : </label>
        	</li>
            <li>
            <input type="text" name="txtMetaTitle" id="txtMetaTitle" value="<?=$listEdit[0]['metaTitle'];?>" /></li>
        </ul>
        <ul >
        	<li>
        	  <label>Meta Description : </label>
        	</li>
            <li>
            <textarea  name="txtMetaDescription" id="txtMetaDescription" ><?=$listEdit[0]['metaDescription']; ?></textarea>           
            </li>
        </ul>
		<ul >
        	<li>
        	  <label>Meta Keywords :</label>
        	</li>
            <li>
            <textarea  name="txtMetaKeywords" id="txtMetaKeywords"><?=$listEdit[0]['metaKeywords']; ?></textarea>           
            </li>
        </ul>
        
        <!-- Multiple Image Code -->
        <ul>
            <li>
               <label>Upload Images :</label>
            </li>
            <li>
               <div id="file_container" style="float:left; padding-left:15px;">
                 <input name="images[]" type="file"  />
                  <input type="text" name="img_title[]" id="img_title"  value="Enter Title" />
                 <input type="text" onKeyPress="return isNumberKey(event);" name="img_sequence[]" id="img_sequence" value="Enter Sequence" />
                 <input type="text" onKeyPress="return isNumberKey(event);" name="price[]" id="price" value="Enter Price" />
                 <br />
                 <br />
               </div>
               <a href="javascript:void(0);" onClick="add_file_field();" style="padding:12px; background-color:#CCCCCC; text-decoration:none; color:#FFFFFF; font-weight:bold">Add another</a><br />
            </li>
        </ul>
        <!-- End Multiple Image Code -->
        <!--
        <ul>
        	<li>
        	  <label>&nbsp;</label>
        	</li>
            <li>
            &nbsp;
            </li>
        </ul>
        -->
    	</fieldset>
        <?php
		$images = $objBlog->getImages($listEdit[0]['id']); //print_r($images); ?>
		<input type="hidden" name="totalImgs" id="totalImgs" value="<?=count($images);?>" />
<?		if(!empty($images)){
		?>
            <table cellpadding="0" cellspacing="0">
                <tr>
                    
					
					<?php
                    for($i=0; $i<count($images); $i++){ 
					
					if($i%5==0 && $i>0)
					{
						?>
                        
                       
                        </tr>
                        <tr><td colspan="8"></td></tr>
                        <tr>
                        <td style="padding:10px;" align="center">
                        <input type="hidden" name="image_id<?=$i;?>" id="image_id<?=$i;?>" value="<?php echo $images[$i]['img_id']; ?>" />
                        	<p><?php //echo $images[$i]['img_title']; ?></p>
                            <img src="<?php echo BLOG_SMALL_IMAGE.$images[$i]['name']; ?>" width="50" style="border:2px solid #CCC; margin:10px; padding:5px" /><br />
                             Title : <input type="text" name="img_tit<?php echo $i; ?>" value="<?php echo $images[$i]['img_title']; ?>" id="title<?php echo $i; ?>" style="border:1px solid #999999; padding:3px; margin:3px;" />
                            <br />
                            Sequence : <input type="text" name="img_seq<?php echo $i; ?>" value="<?php echo $images[$i]['img_sequence']; ?>" id="seq<?php echo $i; ?>" style="width:30px;border:1px solid #999999; padding:3px; margin:3px;" />
                            <br />
                            Price : <input type="text" name="price<?php echo $i; ?>" value="<?php echo $images[$i]['price']; ?>" id="price<?php echo $i; ?>" style="width:70px;border:1px solid #999999; padding:3px; margin:3px;" />
                            <br /><br />
                            <input type="checkbox" name="rem_img<?=$i;?>" id="rem_img<?=$i;?>" />&nbsp;Remove
                           <?php /*?> <a href="#" style="padding:11px; background-color:#CCCCCC; text-decoration:none; color:#FFFFFF; font-weight:bold" onclick="MakeUpdateRequest(<?php echo $images[$i]['img_id']; ?>, document.getElementById('title<?php echo $i; ?>').value, document.getElementById('seq<?php echo $i; ?>').value);">Update Sequence</a>
                            <br /><br /><br />
                            <a href="#" style="padding:11px; background-color:#CCCCCC; text-decoration:none; color:#FFFFFF; font-weight:bold" onclick="return confdelimg(<?php echo $images[$i]['img_id']; ?>, '<?php echo $images[$i]['name']; ?>');">Delete</a><?php */?>
                        </td>
                        <?
					}else{
						?>
                        <td style="padding:10px;" align="center">
                        <input type="hidden" name="image_id<?=$i;?>" id="image_id<?=$i;?>" value="<?php echo $images[$i]['img_id']; ?>" />
                        	<p><?php //echo $images[$i]['img_title']; ?></p>
                            <img src="<?php echo BLOG_SMALL_IMAGE.$images[$i]['name']; ?>" width="50" style="border:2px solid #CCC; margin:10px; padding:5px" /><br />
                           Title : <input type="text" name="img_tit<?php echo $i; ?>" value="<?php echo $images[$i]['img_title']; ?>" id="title<?php echo $i; ?>" style="border:1px solid #999999; padding:3px; margin:3px;" />
                            <br />
                            Sequence : <input type="text" name="img_seq<?php echo $i; ?>" value="<?php echo $images[$i]['img_sequence']; ?>" id="seq<?php echo $i; ?>" style="width:30px;border:1px solid #999999; padding:3px; margin:3px;" />
                            <br />
                            Price : <input type="text" name="price<?php echo $i; ?>" value="<?php echo $images[$i]['price']; ?>" id="price<?php echo $i; ?>" style="width:70px;border:1px solid #999999; padding:3px; margin:3px;" />
                            <br /><br />
                            <input type="checkbox" name="rem_img<?=$i;?>" id="rem_img<?=$i;?>" />&nbsp;Remove
                            <?php /*?><a href="#" style="padding:11px; background-color:#CCCCCC; text-decoration:none; color:#FFFFFF; font-weight:bold" onclick="MakeUpdateRequest(<?php echo $images[$i]['img_id']; ?>, document.getElementById('title<?php echo $i; ?>').value, document.getElementById('seq<?php echo $i; ?>').value);">Update Sequence</a>
                            <br /><br /><br />
                            <a href="#" style="padding:11px; background-color:#CCCCCC; text-decoration:none; color:#FFFFFF; font-weight:bold" onclick="return confdelimg(<?php echo $images[$i]['img_id']; ?>, '<?php echo $images[$i]['name']; ?>');">Delete</a><?php */?>
                        </td>
                        <?
					}
                } 
                    ?>
                </tr>
            </table>
        <?php
		}
		?>
        
        <ul>
        	<li>
        	   <label>&nbsp;</label>
        	</li>
            <li>
            	  <? frmButtons($heading); if(isset($_GET['id']) && $_GET['id']!=''){
						frmApplyButtons($heading);
					}
					?>
                    
            </li>
        </ul>
        
         <input type=hidden name=Validation 
        value="Field=product_name|Alias=Product Name|Validate=Blank"/>    
</form>
<? }

function rowDisplay($pageName,$object,$heading,$listRec=""){
include("inc/clsObj.php");
?>

<!-- Sorting Start -->

<? 
extract($_POST);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="5%" onClick="sortColumn('id');" >Id. <div <? if($sortClName=='id' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='id' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>    
    <th width="5%" onClick="sortColumn('seqNo');"  >Seq. No.<div <? if($sortClName=='seqNo' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='seqNo' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?>></div></th>   
    <th width="24%" onClick="sortColumn('product_name');" > Name <div <? if($sortClName=='product_name' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='product_name' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?>></div>
    </th>
    <th width="46%" onClick="sortColumn('category_name');"   >Category <div <? if($sortClName=='category_name' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='category_name' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?>></div></th>
    
    <th width="19%">Actions&nbsp;
    <input type="checkbox" id="selectAll" name="selectAll" onClick="check_all(this.form,this);"/></th>
  </tr>  
   <?  
    if(count($listRec)>0)
	 {
	 	$colorflg=0;
         for($e=0;$e<count($listRec);$e++){
	     if ($colorflg==1){	$colorflg=0;?>
  		 <tr class="odd" onMouseOver="Javascript:this.className='rowhover'" onMouseOut="Javascript:this.className='odd'">
  		 <? }	else {	$colorflg=1;?>
		 <tr class="even" onMouseOver="Javascript:this.className='rowhover'" onMouseOut="Javascript:this.className='even'">
  		 <? } ?>		        
                <td><?=$listRec[$e]['id'];?>
</td> 
                 <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$listRec[$e]['seqNo'];?>"/>
                <input type="hidden"  name="categoryId[]" id="categoryId" value="<?=$listRec[$e]['id'];?>" size="3"/>
                </td> 
				<td><?=$listRec[$e]['product_name'];?></td>
                <td>
				<? 
				if($listRec[$e]['catid']!=0)
				{
					$objGstCat->id = $listRec[$e]['catid']; 
					$catDetail = $objGstCat->selectRecById(); 
					echo $catDetail[0]['category_name'];
				}
				else
					echo "-";
					?>
				</td>
                <td>
				<? frmActionButton($listRec[$e]['id'],$listRec[$e]['status'],$pageName,$listRec[$e]['name'],$heading); ?>
                </td>
	     </tr>
           <?php }}else {?>
  		<tr>
        	<td colspan="7" align="center">
            	No Records Found...
			</td>
        </tr>
    <?php }?>    
  </table>
<? } ?>