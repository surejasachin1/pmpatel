<table width="100%">
<tr>
<td align="center">
<form name="frmAdminLogin" method="POST" action="codeCheckLogin.php">
<div align="left">
<table cellpadding="0" border="0" style="border-collapse: collapse" bordercolor="#111111" cellspacing="0" width="300" height="118">
  <?php
  if(isset($_GET['opt']))  echo '<tr><td colspan="2"><font color="red"><strong>Invalid Login/ Account Blocked</strong></font></td></tr>';
  		
  ?> 
<tr> 
<td height="48" colspan="2" align="center" width="300">
<p align="left"><strong>Please 
  Login</strong></td>
</tr>
    <tr>
	  <?php if(isset($_GET['opt']))if($_GET['opt'] == 1) ?> 
      <td align="left" width="107" height="22"><b>Username</b></td>
      <td align="left" width="247" height="22"> 
      <input type=text name="txtUserName" class="txtbox"  id="txtUserName" size="30"></td>
    </tr>
    <tr> 
      <td align="left" width="107" height="22"><b>Password</b></td>
      <td align="left" width="247" height="22">
      <input name="txtPassword" type="password" id="txtPassword" size="30"></td>
    </tr>
    <tr> 
      <td align="center" width="107" height="22">&nbsp;</td>
      <td width="247" height="26"><?php if(isset($_GET['msg'])){ echo $mess[$_GET['msg']]; }?></td>
    <tr> 
      <td align="center" width="107" height="22">&nbsp; </td>
      <td width="247" height="26">
      <input type="submit" name="btnLogin" value="Login to my Account"></td>
    </table>
</div>
</form>
</td>
</tr>
</table>
