<div style="padding:10px;background:url(images/header-back.gif);border:#999999 1px solid">
<script type="text/javascript">
	function addphotofields()
	{
		var bucket,imgname,title,seq,brfield,brfield1; 
		bucket=document.getElementById("photocontainer");
		imgname=document.createElement('input');
		imgname.name="photoimages[]";
		imgname.type='file';
		
		title=document.createElement('input');
		title.name="phototitle[]";
		title.type='text';
		title.value='Enter Title';
		
		seq=document.createElement('input');
		seq.name="photoseq[]";
		seq.type='text';
		seq.value='Enter Sequence';
		
		brfield=document.createElement('br');
		
		bucket.appendChild(imgname);
		bucket.appendChild(title);
		bucket.appendChild(seq);
		bucket.appendChild(brfield);
		
		brfield1=document.createElement('br');
		bucket.appendChild(brfield1);
		
	}
	function getXMLHttp(){
	  var xmlHttp
	  try{
		//Firefox, Opera 8.0+, Safari
		xmlHttp = new XMLHttpRequest();
	  }
	  catch(e){
		//Internet Explorer
		try{
		  xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
		}
		catch(e){
		  try{
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		  }
		  catch(e){
			alert("Your browser does not support AJAX!")
			return false;
		  }
		}
	  }
	  return xmlHttp;
	}
	//For updating title & sqno num of image start
	function MakeUpdateRequest(getId, getTitle, getSeq)
	{
	
	  var xmlHttp = getXMLHttp();
	  xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4){
		  HandleUpdateResponse(xmlHttp.responseText);
		}
	  }
	  xmlHttp.open("GET", "multiple_photo.php?img_id="+getId+"&title="+getTitle+"&seq="+getSeq, true); 
	  xmlHttp.send(null);
	}
	function MakeDeleteRequest(id,image)
	{
	var xmlHttp = getXMLHttp();
	  xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4){
		  HandleUpdateResponse(xmlHttp.responseText);
		}
	  }
	  xmlHttp.open("GET", "multiple_photo.php?property_id="+id+"&image="+image, true); 
	  xmlHttp.send(null);
	}
	//For updating title & sqno num of image end
	function HandleUpdateResponse(response){
	  	alert(response);
		window.location.reload();
	}
	/*function checkForm(obj)
	{
		
		var txt=document.frmManage['phototitle[]'];
		var flg=false;
		for(var i=0;i<txt.length;i++)
		{
			if(txt[i].value=="")
			{
				flg=true;
				break;
			}
			
		}
		if(flg)
		{
			alert("Enter Title");
			return false;
		}
		return true;
	}*/
</script>
<form action="codeManagePhotos.php" method="post" name="frmAddRec"  >
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
  <tr>
    <td width="83%" class="title">
       <?php 
	  		if(isset($_REQUEST['btnAddCategory']))
				{ 
    				echo $heading."&raquo; Add Photo";
       			} 
		    else if( isset($_REQUEST['id']))
				{
				   	echo $heading."&raquo; Edit Photo";
      		    }
			else 
				{
					echo $heading;
				}	 
	    ?>    
	</td>
    <td width="17%">
    <?php if(isset($_REQUEST['btnAddCategory']) or isset($_REQUEST['id'])) { ?>
    	<input name="btnBack" id="btnBack"  type="submit" class="button" style="float:right;" onmouseover="this.className='button_hover'" onmouseout="this.className='button'" value="Back"  />
    <?php } else { ?>
       <input name="btnAddCategory" id="btnAddCategory"  type="submit" class="button" style="float:right;" onmouseover="this.className='button_hover'" onmouseout="this.className='button'" value="Add Photo"/>
    <?php } ?>
    </td>
  </tr>
</table>
</form>
</div>
<?php if(isset($_REQUEST['btnAddCategory']) or isset($_REQUEST['id'])) { ?>
<div id="form_container">
  <form action="codeManagePhotos.php" method="post" name="frmManage" enctype="multipart/form-data" onsubmit="return checkForm(this)">
     <input type="hidden" name="hid" id="hid" value="<?=$_REQUEST['id'];?>"/>
   <fieldset>
    	<legend>Photo Details</legend>
                  
         <!--<ul>
                <li>
                    <label >Name <span class="requiredt"> * </span> :</label>
                </li>
                <li>
                    <input type="text" name="name" id="name" value="<? // $listEdit[0]['name'];?>">
                </li>
         </ul> -->  
        
         <!--<ul>
        	<li>
        	  <label>Sequence No :</label>
        	</li>
            <li>
              <input name="txtSeqNo" type="text" id="txtSeqNo" value="<?=$listEdit[0]['seqno']; ?>">
            </li>
        </ul>-->
              
        <ul>
        	<li>
            	<label >Upload Image :</label>
            </li>
            <li>
				<div id="photocontainer" style="float:left;padding-left:15px;">
		           	  <!--<input type="file" name="imageOriginal" id="imageOriginal"/>-->
                      <input type="file" name="photoimages[]" />
                      <input type="text" name="phototitle[]" id="phototitle" value="Enter Title" />
                      <input type="text" name="photoseq[]" id="photoseq" value="Enter Sequence" />
                      <br/><br/>
                      
              </div>
              <a href="javascript:void(0);" onClick="addphotofields();" style="padding:12px; background-color:#CCCCCC; text-decoration:none; color:#FFFFFF; font-weight:bold">Add Photo</a><br />
            </li>
        </ul>
        
        <?php if(isset($_REQUEST['id'])){?>
         <!--<ul>
        	<li>
        	  <label>&nbsp;</label>
        	</li>
            <li>
            	<img src="<?php echo PHOTO_GALLERY_SMALL.$listEdit[0]['image'];?>" alt="" width="100" height="100" />
                <input type="hidden" name="productPhoto" id="productPhoto" value="<?=$listEdit[0]['image'];?>"/>
            </li>
        </ul>-->
         <?php }?>
        </fieldset>
        <!--Display Multiple photo start-->
        <?
       		$images=$objPhotos->getPhotoByCategory($listEdit[0]['id']);
			if(!empty($images))
			{
			?>
            	<table cellpadding="0" cellspacing="0">
                	<tr>
                   <?
                    for($i=0; $i<count($images); $i++)
					{ 
							if($i%8==0 && $i>0)
						{
						?>
							</tr>
							<tr><td colspan="8"></td></tr>
							<tr>
								<td style="padding:10px;" align="center">
								<p><?php //echo $images[$i]['img_title']; ?></p>
								<img src="<?php echo PHOTO_GALLERY_SMALL.$images[$i]['image']; ?>" width="50" style="border:2px solid #CCC; margin:10px; padding:5px" /><br />
								Title : <input type="text" name="img_tit" value="<?php echo $images[$i]['name']; ?>" id="title<?php echo $i; ?>" style="border:1px solid #999999; padding:3px; margin:3px;" />
								<br />
								Sequence : <input type="text" name="img_seq" value="<?php echo $images[$i]['seqno']; ?>" id="seq<?php echo $i; ?>" style="width:30px;border:1px solid #999999; padding:3px; margin:3px;" />
								<br /><br />
								<a href="#" style="padding:11px; background-color:#CCCCCC; text-decoration:none; color:#FFFFFF; font-weight:bold" onclick="MakeUpdateRequest(<?php echo $images[$i]['id']; ?>, document.getElementById('title<?php echo $i; ?>').value, document.getElementById('seq<?php echo $i; ?>').value);">Update Title & Sequence</a>
								<br /><br /><br />
								<a href="#" style="padding:11px; background-color:#CCCCCC; text-decoration:none; color:#FFFFFF; font-weight:bold" onclick="return confdelimg(<?php echo $images[$i]['id']; ?>, '<?php echo $images[$i]['image']; ?>');">Delete</a>
							</td>
						<?
						}
						else
						{
						?>
							<td style="padding:10px;" align="center">
								<p><?php //echo $images[$i]['img_title']; ?></p>
								<img src="<?php echo PHOTO_GALLERY_SMALL.$images[$i]['image']; ?>" width="50" style="border:2px solid #CCC; margin:10px; padding:5px" /><br />
								Title : <input type="text" name="img_tit" value="<?php echo $images[$i]['name']; ?>" id="title<?php echo $i; ?>" style="border:1px solid #999999; padding:3px; margin:3px;" />
								<br />
								Sequence : <input type="text" name="img_seq" value="<?php echo $images[$i]['seqno']; ?>" id="seq<?php echo $i; ?>" style="width:30px;border:1px solid #999999; padding:3px; margin:3px;" />
								<br /><br />
								<a href="#" style="padding:11px; background-color:#CCCCCC; text-decoration:none; color:#FFFFFF; font-weight:bold" onclick="MakeUpdateRequest(<?php echo $images[$i]['id']; ?>, document.getElementById('title<?php echo $i; ?>').value, document.getElementById('seq<?php echo $i; ?>').value);">Update Title & Sequence</a>
								<br /><br /><br />
								<a href="#" style="padding:11px; background-color:#CCCCCC; text-decoration:none; color:#FFFFFF; font-weight:bold" onclick="MakeDeleteRequest(<?php echo $images[$i]['id']; ?>, '<?php echo $images[$i]['image']; ?>');">Delete</a>
							</td>	
						<?
						}
					}
				?>
                </tr>
                </table>
            <?
			}//If end
			
		?>
        <!--Display Multiple photo end-->
         <ul>
        	<li>
        	   <label >&nbsp;</label>
        	</li>
            <li>
            	  <?php if(isset($_GET['id'])){?>
           	  <input type="submit" name="btnUpdate" value="Update Photo" class="button" onmouseover="this.className='button_hover'" onmouseout="this.className='button'" />
            	  <?php } else {?>
   			  <input type="submit" name="btnAdd" value="Add Photo" class="button" onmouseover="this.className='button_hover'" onmouseout="this.className='button'" />
			      <?php } ?>  
           </li>
    </ul>        
      
    <input type=hidden name=Validation
     		      value="Field=name|Alias=Photo Name|Validate=Blank"/>      
</form>
</div>	
<?php } else {?>
<div style="width:100%; text-align:center; padding-bottom:5px; padding-top:0px;">
	        <?php if(isset($_GET['msg'])){ echo $mess[$_GET['msg']]; }?>
</div> 
<div class="paging">
     <?=$object->pagination;?>
</div>

<form action="" id="tmpFrm" name="tmpFrm" method="post">

    <input type="hidden" name="editTbl" value="<? echo $editTbl?>">
	<input type="hidden" name="editTblBool" value="<? echo $editTblBool?>">
	<input type="hidden" name="newTbl" value="<? echo $newTbl?>">
	<input type="hidden" name="rowNo" value="<? echo $rowNo?>">
	<input type="hidden" name="ascdsc" value="<? echo $ascdsc?>">
	<input type="hidden" id="sortClName" name="sortClName" value="<? echo $sortClName?>">
	<input type="hidden" name="offset" value="<? echo $offset?>">
    
</form>

<form action="codeManagePhotos.php" method="post" name="frmManageDetails" onsubmit="return ValidateForm(this)">
<div class="action">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="55%">
      		<a href="Javascript:select_all(true);">Select All</a> | 
            <a href="Javascript:select_all(false);">Deselect All</a> | <span id="total_selected">0</span> items selected 
      </td>
      <td width="45%" align="right">
	  Action : 
	  <select name="optAction">
          <option value="-1">--Select Action--</option>
          <option value="0">Delete</option>
          <option value="1">Published</option>
          <option value="2">Unpublished</option>
          <option value="3">Update Sequence</option>               
	  </select>
	  <input type="submit" class="button" onmouseover="this.className='button_hover'" onmouseout="this.className='button'" value="Submit" name="btnAction" id="btnAction" />
	  </td>
    </tr>
  </table>
</div>
<div class="table_border">
<? extract($_POST); ?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="5%" onclick="sortColumn('id');" >Id. <div <? if($sortClName=='id' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='id' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>
    <th width="10%" onclick="sortColumn('seqno');">Seq. No. <div <? if($sortClName=='seqno' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='seqno' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>
    <th width="20%" onclick="sortColumn('name');">Photo Name <div <? if($sortClName=='name' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='name' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>
    
   <th width="22%">Image</th>
    <th width="11%">Actions&nbsp;<input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>
  
   <?  
    if(count($listRec)>0)
	 {
      $colorflg=0;
	   for($e=0;$e<count($listRec);$e++){
		  if ($colorflg==1){		$colorflg=0;?>
  		  <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
   <? }	else {	$colorflg=1;?>
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">
   <? } ?>
                <td><?=$listRec[$e]['id'];?></td>
               <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$listRec[$e]['seqno'];?>"/>
                <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$listRec[$e]['id'];?>" size="3"/>
                </td>
                <td><?=$listRec[$e]['name'];?></td>  
                <td><img src="<?php echo PHOTO_GALLERY_SMALL.$listRec[$e]['image'];?>" height="100" width="100"/></td>               
                <td>
	                <input type="checkbox" name="chkAction[]" id="chkAction[]"  value="<? echo $listRec[$e]['id'];?>" onclick="chkTotal(this.form);"/>&nbsp;
                    <?php  if($listRec[$e]['status']=='0'){?>
                        <a href="?status=1&amp;uid=<? echo $listRec[$e]['id'];?>"><img src="images/minus-circle.gif" width="16" height="16" alt="published"  border="0"/></a>
                    <?php } else {?>
                        <a href="?status=0&amp;uid=<? echo $listRec[$e]['id'];?>"><img src="images/tick-circle.gif" width="16" height="16" alt="published"  border="0"/></a>
                    <?php } ?>
                        <a href="codeManagePhotos.php?id=<?php echo $listRec[$e]['id'];?>"><img src="images/pencil.gif" width="16" height="16" alt="edit" border="0" /></a>
                    <img src="images/close.png" width="16" height="16" alt="delete"  border="0" onclick="deleteAll(<?php echo $listRec[$e]['id'];?>,'<?php echo $listRec[$e]['name'];?>','Product','codeManagePhotos.php')"/>
                </td>
	     </tr>
  <? } } else {?>
  		<tr>
        	<td colspan="5" align="center">
            	No Records Found...
            </td>
        </tr>
    <?php }?>    
  </table>
</div>	
<input type=hidden name=Validation value="Field=optAction|Alias=Action|Validate=Combo"/>	    
</form>
<?php } ?>