<?
	$filepath = (stristr($_SERVER['PHP_SELF'],"sitecontrol")!="") ?	"../" : "" ;

	define("TEMPLATE",$template);
	$basepath1 = "http://" . $_SERVER['HTTP_HOST']  . $_SERVER['REQUEST_URI']; 	
	$basepath2 = explode('/',$basepath1);
		
	for($i=0; $i<count($basepath2)-1; $i++)
	{
		$basepath .= $basepath2[$i].'/';
	}
	
	/* Banner path */
	define("BANNER_BIG_IMAGE", $filepath.TEMPLATE."images/banner/big/");
	define("BANNER_SMALL_IMAGE", $filepath.TEMPLATE."images/banner/small/");
	/* Banner end */
	
	/* Category Path  */
	define("CATEGORY_SMALL_IMAGE", $filepath.TEMPLATE."images/category/small/");	
	define("CATEGORY_BIG_IMAGE", $filepath.TEMPLATE."images/category/big/");
	/* Category End */
	
	/* Product path */
	define("PRODUCT_SMALL_IMAGE", $filepath.TEMPLATE."images/product/small/");	
	define("PRODUCT_BIG_IMAGE", $filepath.TEMPLATE."images/product/big/");
	/* Product end */	
	
	/* Photogalley Path, Height and Width */
	define("PHOTO_GALLERY_SMALL", $filepath."images/photo_gallery/photos/small/");	
	define("PHOTO_GALLERY_BIG", $filepath."images/photo_gallery/photos/big/");	
	define("PHOTO_CATEGORY", $filepath."images/photo_gallery/category/");	
	/* Photogallery End */
	
	/* Product path */
	define("EVENT_SMALL_IMAGE", $filepath.TEMPLATE."images/event/small/");	
	define("EVENT_BIG_IMAGE", $filepath.TEMPLATE."images/event/big/");
	/* Product end */
	
	/* Soical Images */
	define("SOCIAL_IMAGE", $filepath."images/social/");	
		
	define("BASE_URL",$basepath);	
	define("COPYRIGHTS", date("Y"));
	define("TOTAL_RECORDS",30);	
	define("CURRENCY","$");		

	

	//-------constants for payment gateway -------
	define("TEST_MODE",true);

	//-------constants for other modules-------
	define("MENU_EDIT",1);
?>	