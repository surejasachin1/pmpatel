<?php
error_reporting(0);

	$fpath = (stristr($_SERVER['PHP_SELF'],"sitecontrol")!="") ?	"" : "sitecontrol/" ;
	
	include($fpath."inc/constant.php");
	include($fpath."system/config.inc.php");
	include($fpath."system/paging.inc.php");
	include($fpath."editor/fckeditor.php");
	include($fpath."html/frmFunctions.php");
	
	include($fpath."classes/classPhpMailer.php");
	include($fpath."classes/classAdmin.php");
	include($fpath."classes/classAdminMenu.php");
	include($fpath."classes/classFrontMenu.php");
	include($fpath."classes/classProCategory.php");	
	include($fpath."classes/classProducts.php");
	include($fpath."classes/classProducts1.php");	
	include($fpath."classes/classPhotoGallery.php");
	include($fpath."classes/classManageBanner.php");
	include($fpath."classes/classManageSearch.php");
	include($fpath."classes/classManageUser.php");
	include($fpath."classes/classManagePhotoCat.php");
	include($fpath."classes/classManagePhotos.php");
	include($fpath."classes/classSocialLinks.php");
	include($fpath."classes/classLanguages.php");
	include($fpath."classes/classUploads.php");
	include($fpath."classes/classGlobalConfig.php");
	include($fpath."classes/classEvent.php"); 
	include($fpath."classes/classTest.php");
	include($fpath."classes/classBlog.php"); 
	include($fpath."classes/classGstCat.php");		 // Global Configuration
?>
