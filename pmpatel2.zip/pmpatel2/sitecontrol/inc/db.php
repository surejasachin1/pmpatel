<?php
error_reporting();
	define("DB_NAME","imagein_pmp");
	define("SERVER_NAME","localhost");
	define("USER_NAME","root");
	define("PASSWORD","");
?>
