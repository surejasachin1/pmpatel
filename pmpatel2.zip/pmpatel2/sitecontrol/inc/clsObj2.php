<?php 

	error_reporting(0);

	$obj_admin=new adminMaster();
	$objAdminMenu=new adminMenuMaster();
	$objFrontMenu=new userFrontMenuMaster();
	$objProCat=new pro_categories();
	$objGstCat=new gst_categories();
	$objProduct=new products();
	$objProduct1=new products1();
	$objPhotoGallery=new photo_gallery();
	$objSearch=new search();
	$objBanner=new banner();
	
	
	$objPhotoCat=new photoCategory();
	$objPhotos=new Photos();
	
	$objSocialLinks = new social_links();
	
	$objUploads = new uploads();
	
	$objGlobalConfig = new golbalConfig(); // Global Configuration
	
	$objEvent=new event();
	$objTest1=new test1();
	
	$objBlog=new blog();
	
?>