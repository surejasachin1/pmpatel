<?php session_start();  

if(isset($_SESSION['membername']) && $_SESSION['membername']!='')
{
	header("Location:frmMain.php");
}

if(isset($_POST['btnRetrivePassword']))
{
	include("inc/fileInclude.php");
	include("inc/clsObj.php");
	$obj_admin->adminEmail=$_POST['Email_Address'];
	$rs=$obj_admin->forgotPassoword();
	if(count($rs)>0){
		$username = $rs[0]['adminUsername'];
		$password = decryptPassword($rs[0]['adminPassword']); 
		$to=$_POST['Email_Address'];
		$headers  = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "To:$to\r\n";
		$headers .= "From:Web Portal.us<noreply@webportal.com>\r\n";	
		$subject="Admin Forgot password";
		$message="Now you can login in web portal admin panel using following login details.";
		$message.="<br><br>Username : $username<br/>Password : $password";
		$sm = mail($to, $subject, $message, $headers);	
?>
		<script type="text/javascript">
		alert("The login details has been sent to <?=$_POST['Email_Address'];?>");
		document.location = "index.php?sent=true"
		</script>
	<? 
	}else{ ?>
		<script type="text/javascript">
		alert("Invalid Email address, this kind of address not found in the record.");
		document.location = "index.php?error=true"
		</script>
	<? }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Control Pannel</title>
<link href="css/template.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/forms.css">
<style>
body
{
	margin:0px auto;
	padding:0px;
	background:#ccc;
}
</style>
<script type="text/javascript" src="js/ajax.js"></script>
<script type="text/javascript">
var ajax = new sack();

function whenLoading(){
	var e = document.getElementById('replaceme'); 
	e.innerHTML = '<b id="veryfying">Verifying username and password...</b>';
}

function whenLoaded(){
	var e = document.getElementById('replaceme'); 
	e.innerHTML = '<b id="veryfying">Verifying username and password...</b>';
}

function whenInteractive(){
	var e = document.getElementById('replaceme'); 
	e.innerHTML = '<b id="veryfying">Verifying username and password...</b>';
}

function whenCompleted(){
	var e = document.getElementById('replaceme'); 
	var return_value = ajax.response;	
	if(return_value.indexOf("Please wait,redirecting...")!=-1)
		document.location="frmMain.php";
	else
		e.innerHTML = ajax.response;	
}

function doit(){
	var form = document.getElementById('frmAdminLogin');
	if(form.txtUserName.value=="" || form.txtPassword.value==""){
		var e = document.getElementById('replaceme'); 
		e.innerHTML = "<div id='logout'><b>Username and Password required.</b></div>";
		return false	
	}else{  
		ajax.setVar("txtUserName", form.txtUserName.value); 
		ajax.setVar("txtPassword", form.txtPassword.value);
		ajax.requestFile = "codeCheckLogin.php";
		ajax.method = "post";
		ajax.element = 'replaceme';
		ajax.onLoading = whenLoading;
		ajax.onLoaded = whenLoaded; 
		ajax.onInteractive = whenInteractive;
		ajax.onCompletion = whenCompleted;
		ajax.runAJAX();
	}
}
function MM_validateForm() { //v4.0
  if (document.getElementById){
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);
      if (val) { nm=val.name; if ((val=val.value)!="") {
        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
        } else if (test!='R') { num = parseFloat(val);
          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
            min=test.substring(8,p); max=test.substring(p+1);
            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
    } if (errors) alert('The following error(s) occurred:\n'+errors);
    document.MM_returnValue = (errors == '');
} }
</script>

</head>
<body>
<div id="screen_wrapper">
<div id="login_leftpan">
<div class="login_head_text">Administration Login</div>
	Use a valid username and password to login to the control panel(Back-end) of your site.</div>

<div id="login_rightpan">
  <form name="frmAdminLogin" method="POST" id="frmAdminLogin" action="codeCheckLogin.php" onSubmit="return sendForm(this);">
	<div class="login_header">ENTER YOUR LOGIN DETAILS HERE :</div>
	<div id="controls">
	<ul>
		<li><span >Login Name :</span></li>
		<li class="control">
        	<input type=text name="txtUserName" class="textbox"  id="txtUserName" size="30">
        </li>
	</ul>
	<ul>	
		<li>
        	  <span>Password :</span>
		</li>
		<li class="control">
        	<input name="txtPassword" type="password" id="txtPassword" size="30" class="textbox">
        </li>
	</ul>
    <ul>	
		<li class="control">
        	<div style="text-align:center;" id="replaceme">
<?php 	if(isset($_GET['logout']))
			echo "<div id='logout'>You are successfully logout</div>"; ?> 
            </div>
        </li>
	</ul>
	</div>
	<div id="buttons">
	<ul>
		<li>
		  <input type="submit" value="Submit" name="btnPassword" id="btnPassword" style="cursor: pointer;" onMouseOver="this.className='login_button_hover'" onMouseOut="this.className='login_button'"  class="login_button"  onclick="doit(); return false;" onDblClick="doit(); return false;"  />
		</li>					
		<li >
		    <input type="reset" name="btnResetPassword" id="btnResetPassword"  onmouseover="this.className='reset_button_hover'" onMouseOut="this.className='reset_button'"  class="reset_button"    />
		</li>
	</ul>
	</div>
    </form>
    <form action="" method="post" name="frmFgtPassword" id="frmFgtPassword" onSubmit="MM_validateForm('Email_Address','','RisEmail');return document.MM_returnValue">
	<div class="login_header">FORGOT LOGIN DETAILS ? </div>
	<div id="buttons">    
	<ul>
		<li ><span >Email   :</span></li>					
		<li >
        	<input type="text" name="Email_Address" id="Email_Address" class="textbox"  />
        </li>
		<li >
        	<input type="submit" name="btnRetrivePassword" id="btnRetrivePassword" value="Retrive Now" onMouseOver="this.className='forgot_button_hover'" onMouseOut="this.className='forgot_button'"  class="forgot_button"     />
        </li>
	</ul> 
	</div>
    </form>
</div>
</div>
</body>
</html>