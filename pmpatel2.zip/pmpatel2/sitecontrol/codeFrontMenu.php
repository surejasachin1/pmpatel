<?php 
include("template.php");
function main()	
{
	include("inc/clsObj.php");
	$heading="Front Menu";
	$pageName="codeFrontMenu.php";
	$object=$objFrontMenu;
	
	$object->tablename = 'menumgr';
	$object->limit=TOTAL_RECORDS;
	extract($_POST);		
	$object->id=isset($_GET['uid']) ? $_GET['uid'] : (isset($_GET['delete']) ? $_GET['delete'] : (isset($_GET['id']) ? $_GET['id'] : $hid  )) ;	
		$txtAreaDesc=$_POST['FCKeditor1'];					
		$txtAreaDesc=str_replace("\&quot;","", $txtAreaDesc);		
		$txtAreaDesc=str_replace('\\', '', $txtAreaDesc);				
		$txtAreaDesc=str_replace("\'","'", $txtAreaDesc);		
		$txtAreaDesc=str_replace("'","\'", $txtAreaDesc);		  				
		$rnd=createRandomCode();
		$object->menuName=$Menu_name;
		
		
		
		// Added //
		$Alias_Name = preg_replace("![^a-z0-9]+!i", "-", $Alias_Name);
		$Alias_Name = strtolower($Alias_Name);
		$object->alias_name=$Alias_Name;
		// End //
		
		$object->seqNo=$txtSeqNo;
		$object->menuPosition=$Menu_Position;
		$object->menuSubId=$optMenuLevel;
		$object->menuType=$Menu_Type;
		$object->menuUrl=$txtMenuLink;
		$object->menuTarget=$optTargetWindow;
		$object->menuDesc=$txtAreaDesc;
		$object->metaTitle=$txtMetaTitle;
		$object->metaDescription=$txtMetaTag;
		$object->metaKeywords=$txtMetaKeywords;
		$object->menuRobots=$txtRobots;
		$object->menuAuthor=$txtAuthor;
		$object->status=isset($_GET['status']) ? $_GET['status'] : 1;
		$object->menuFileName=uploadFile("fileUpload",$rnd.$_FILES['fileUpload']['name'],FILEPATH);
	
	if(isset($_GET['id']))
	{				
		$editRec=$object->selectRecById();												
	}					
	if(isset($_POST['btnAdd']))
	{						
		$object->insert();		
		redirect($pageName."?msg=add");
	}		
	if(isset($_POST['btnUpdate']))
	{				
		$object->update();
		redirect($pageName."?msg=edit");
	}	
	if(isset($_POST['btnApply'])){		
		$object->update();
		redirect($pageName."?id=".$_POST['hid']."&page=");
	}	
	if(isset($_POST['btnAction']))
	{
	  extract($_POST);
	  switch($optAction)
	  {
		case 0:
				$object->deleteSelect($chkAction);
				redirect($pageName."?msg=del");
				break;
		case 1:
				$object->statusUpdatePublish($chkAction);
				redirect($pageName."?msg=Publish");
				break;
		case 2:
				$object->statusUpdateUnPublish($chkAction);
				redirect($pageName."?msg=UnPublish");
				break;
		case 3:
				extract($_POST);
				for($i=0;count($categoryId)>$i;$i++)
				{
					$object->id=$categoryId[$i];
					$object->seqNo=$txtSeqNo[$i];
					$object->sequenceUpdate();				
				}	
				redirect($pageName."?msg=seq");
	  } 		  
	}	
	if(isset($_GET['status']))
	{					
		$object->status();
		redirect($pageName."?msg=status");
	} 		
	if(isset($_GET['delete']))
	{			
		$object->delete();			
		redirect($pageName."?msg=del");
	}		
	
	// Sorting Start 
	
if (isset($_REQUEST['editTblBool']))
   $editTblBool = $_REQUEST['editTblBool'];
else
   $editTblBool=0;

if (isset($_REQUEST['ascdsc']))
   $ascdsc = $_REQUEST['ascdsc'];
else
   $ascdsc=0;

if (isset($_REQUEST['sortClName']))
   $sortClName = $_REQUEST['sortClName'];
else
   $sortClName="";

if (isset($_REQUEST['offset']))
   $offset=$_REQUEST['offset'];
else
   $offset=0;


if ($editTblBool!=1)
{
	if ($ascdsc==0)
		$ascdsc = 1;
	else
		$ascdsc = 0;
}

// Sorting End

	$listRec=$object->menuCategoryList();		
	include("html/frmFrontMenu.php");	
}

function display($cid,$n) 
{
	include("inc/clsObj.php");	
	$objFrontMenu->id=$cid;
	$menuSubCatList=$objFrontMenu->menuSubCategoryList();
	$n+=2;
	for($i=0;$i<count($menuSubCatList);$i++)
	{ ?>
	<option value="<?=$menuSubCatList[$i]['id'];?>"><?php  echo str_repeat("&nbsp;",$n).$menuSubCatList[$i]['menuName'];?></option>	    	<? display($menuSubCatList[$i]['id'],$n); 
	}
}

function displayRow($cid,$n,$heading) 
	{
		include("inc/clsObj.php");	
			$objFrontMenu->id=$cid;
			$menuSubCatList=$objFrontMenu->menuSubCategoryList();
			$n+=2;		
	     	$colorflg=0;
         for($i=0;$i<count($menuSubCatList);$i++){
	     if ($colorflg==1){		$colorflg=0;?>
  		 <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
  		 <? }	else {	$colorflg=1;?>
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">
  		 <? } ?>		        
                <td><?=$menuSubCatList[$i]['id'];?></td>
                <td style="padding-left:20px;">
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$menuSubCatList[$i]['seqNo'];?>"/>
                <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$menuSubCatList[$i]['id'];?>" size="3"/>
                </td>
                <td><? echo str_repeat("&nbsp;",$n).$menuSubCatList[$i]['menuName'];?></td>						                <td><? echo $menuSubCatList[$i]['menuPosition'];?></td>                
                <td>                
                <?
				   	frmActionButton($menuSubCatList[$i]['id'],$menuSubCatList[$i]['status'],"codeFrontMenu.php",$menuSubCatList[$i]['menuName'],$heading);
				?>	               
                </td>
	     </tr>			
    	<? 
	displayRow($menuSubCatList[$i]['id'],$n,$heading); 
	}
}
?>
<script type="text/javascript">
function show(id)
{
	document.getElementById('uploadFile').style.display='none';
	document.getElementById('description').style.display='none';				
	document.getElementById('url').style.display='none';
	if(id.value==1)
	{
		document.getElementById('uploadFile').style.display='block';
	}
	if(id.value==2)			
	{
		document.getElementById('description').style.display='block';			
			
	}
	if(id.value==3)			
	{
		document.getElementById('url').style.display='block';		
		document.getElementById('description').style.display='block';						
				
	}
}

function validateFormMenu()
{ //v4.0	
  if (document.getElementById)
  {
    var i,p,q,nm,test,num,min,max,errors='',args=validateFormMenu.arguments;
    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);
      if (val) { nm=val.name; if ((val=val.value)!="") {
        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
        } else if (test!='R') { num = parseFloat(val);
          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
            min=test.substring(8,p); max=test.substring(p+1);
            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
   } 
   
	if(document.frmManage.Menu_Type.value==1 && document.frmManage.fileUpload.value=="")
  	errors += '- File is required.';

	if(document.frmManage.Menu_Type.value==3 && document.frmManage.txtMenuLink.value=="")
	errors += '- Url is required.';
  
	if (errors) alert('The following error(s) occurred:\n'+errors);
    document.MM_returnValue = (errors == '');
  }  
}				
</script>