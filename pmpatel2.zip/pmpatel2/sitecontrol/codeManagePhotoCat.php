<?php 
include("template.php");

function main()	
	{
	


		$heading="Manage Photo Category";
		include("inc/clsObj.php");			
//		JscriptDeleteVerification($page."");
		$page="codeManagePhotoCat.php";
		$object=$objPhotoCat;
		extract($_POST);	
	
		if($_FILES['imageOriginal']['name']!="")
					{
						if(isset($menuImage))
							{
								unlink(PHOTO_CATEGORY.$menuImage);
							}
					}	
			$rnd=createRandomCode();
		$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid  )) ;				  				
			$object->name=$Menu_name;
			$object->home=isset($home)?1:0;				
			$object->catid=$optMenuLevel;				
			$object->status=isset($_GET['status']) ? $_GET['status'] : 1;
			if($txtSeqNo=="")
				 	  $object->seqno=0;		
				else	  
					   $object->seqno=$txtSeqNo;
			if($_FILES['imageOriginal']['name']!="")
			{
		   			$object->image=uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],PHOTO_CATEGORY,200,150);
		    } else {
				
				if(isset($menuImage))
					{
						  $object->image=$menuImage;	
     				}
				else
					{
						 $object->image=NULL;
					}			 	  
			}
		if(isset($_GET['id']))
		{				
				$menuCatListEdit=$object->selectRecById();												
		}			
		
		if(isset($_POST['btnAdd']))
		{						
			$object->insert();		
			redirect($page."?msg=add");
		}
		
		if(isset($_POST['btnUpdate']))
		{				
			$object->update();
			redirect($page."?msg=edit");
		}
		
		if(isset($_POST['btnAction']))
		{
		  extract($_POST);
		  switch($optAction)
		  {
		  	case 0:
					$object->deleteSelect($chkAction);
					redirect($page."?msg=del");
					break;
			case 1:
			 		$object->statusUpdatePublish($chkAction);
					redirect($page."?msg=Publish");
			        break;
			case 2:
			        $object->statusUpdateUnPublish($chkAction);
					redirect($page."?msg=UnPublish");
					break;
			case 3:
					extract($_POST);
					for($i=0;count($categoryId)>$i;$i++)
					{
						$object->id=$categoryId[$i];
						$object->seqno=$txtSeqNo[$i];
						$object->sequenceUpdate();				
					}	
					redirect($page."?msg=seq");
		  } 		  
		}										 
	
		if(isset($_GET['status']))
		{					
			$object->status();
			redirect($page."?msg=status");
		 } 
		
		if(isset($_GET['delete']))
		{			
			$object->delete();			
			redirect($page."?msg=del");
		}		
		
		
		// Sorting Start 

		if (isset($_REQUEST['editTblBool']))
		   $editTblBool = $_REQUEST['editTblBool'];
		else
		   $editTblBool=0;
		
		if (isset($_REQUEST['ascdsc']))
		   $ascdsc = $_REQUEST['ascdsc'];
		else
		   $ascdsc=0;
		
		if (isset($_REQUEST['sortClName']))
		   $sortClName = $_REQUEST['sortClName'];
		else
		   $sortClName="";
		
		if (isset($_REQUEST['offset']))
		   $offset=$_REQUEST['offset'];
		else
		   $offset=0;
		
		
		if ($editTblBool!=1)
		{
			if ($ascdsc==0)
				$ascdsc = 1;
			else
				$ascdsc = 0;
		}
		
		// Sorting End
		
		$menuMainCatList=$object->menuCategoryList();	
			
		include("html/frmManagePhotoCat.php");	
	}

function display($cid,$n) 
	{
		include("inc/clsObj.php");		
		$objProjects->id=$cid;
	    $menuSubCatList=$objProjects->menuSubCategoryList();
	    $n+=2;
	    for($i=0;$i<count($menuSubCatList);$i++)
		    {				
	    ?>
				<option value="<?=$menuSubCatList[$i]['id'];?>"><?php  echo str_repeat("&nbsp;",$n).$menuSubCatList[$i]['name'];?></option>	    
    	<? 
	display($menuSubCatList[$i]['id'],$n); 
	}
}
function displayRow($cid,$n) 
	{
		include("inc/clsObj.php");		
		$objProjects->id=$cid;
	    $menuSubCatList=$objProjects->menuSubCategoryList();
	    $n+=2;
		
	     	$colorflg=0;
         for($i=0;$i<count($menuSubCatList);$i++){
	     if ($colorflg==1){		$colorflg=0;?>
  		 <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
  		 <? }	else {	$colorflg=1;?>
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">
  		 <? } ?>		        
                <td><?=$menuSubCatList[$i]['id'];?></td>  
                 <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$menuSubCatList[$i]['seqno'];?>"/>
                <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$menuSubCatList[$e]['id'];?>" size="3"/>
                </td>               
                <td><? echo str_repeat("&nbsp;",$n).$menuSubCatList[$i]['name'];?></td>						              
                <td>
	                <input type="checkbox" name="chkAction[]" id="chkAction[]"  value="<? echo $menuSubCatList[$i]['id'];?>"/>&nbsp;
                  
                    <?php  if($menuSubCatList[$i]['status']=='0'){?>
                        <a href="?status=1&uid=<? echo $menuSubCatList[$i]['id'];?>"><img src="images/minus-circle.gif" width="16" height="16" alt="published"  border="0"/></a>
                    <?php } else {?>
                        <a href="?status=0&uid=<? echo $menuSubCatList[$i]['id'];?>"><img src="images/tick-circle.gif" width="16" height="16" alt="published"  border="0"/></a>
                    <?php } ?>
                        <a href="codeManageProjects.php?id=<?php echo $menuSubCatList[$i]['id'];?>"><img src="images/pencil.gif" width="16" height="16" alt="edit" border="0" /></a>
                    <img src="images/close.png" width="16" height="16" alt="delete"  border="0" onclick="deleteAll(<?php echo $menuSubCatList[$i]['id'];?>,'<?php echo $menuSubCatList[$i]['name'];?>','Menu Item','codeManageProjects.php')"/>
                </td>
	     </tr>			
    	<? 
		displayRow($menuSubCatList[$i]['id'],$n); 
	}
}
?>
