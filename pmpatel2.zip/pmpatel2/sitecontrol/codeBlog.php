<?php

include("template.php");


function main()
{

	include("inc/clsObj.php");
	$heading = "Blog";	
	$object = $objBlog;
		
	$pageName = "codeBlog.php";
	
	$object->limit = TOTAL_RECORDS;
	
	extract($_POST);
	
	/*
	echo "<pre>";
	print_r($_FILES);
	echo "</pre>";
	exit;
	*/
	
    $rnd=createRandomCode();
	$txtAreaDesc=$_POST['FCKeditor1'];					
	$txtAreaDesc=str_replace("\&quot;","", $txtAreaDesc);		
	$txtAreaDesc=str_replace('\\', '', $txtAreaDesc);				
	$txtAreaDesc=str_replace("\'","'", $txtAreaDesc);		
	$txtAreaDesc=str_replace("'","\'", $txtAreaDesc);		  				
	$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid )) ;
	
	if($_FILES['imageOriginal']['name']!=""){
		if(isset($hiddenImage)){
			unlink(BLOG_BIG_IMAGE.$hiddenImage);								
			unlink(ELOG_SMALL_IMAGE.$hiddenImage);
		}
	}			
	$object->catid=$Category;
	$object->sqno=$Sequence_No;
	$object->product_name=$product_name;
	
	// Added //
	$Alias_Name = preg_replace("![^a-z0-9]+!i", "-", $Alias_Name);
	$Alias_Name = strtolower($Alias_Name);
	$object->alias_name=$Alias_Name;
	// End //
	
	$object->posted_by=$posted_by;
	$object->seqNo=$txtSeqNo;
	
	$object->size=$Size;
	$object->description=$txtAreaDesc;
	$object->price=$Price;

	$object->metaTitle=$txtMetaTitle;
	$object->metaDescription=$txtMetaDescription;
	$object->metaKeywords=$txtMetaKeywords;

	$object->new_arrival=isset($New_Arrival) ? 1 : 0;
	$object->hot_product=isset($Hot_Product) ? 1 : 0;
	
	
	if($_FILES['imageOriginal']['name']!="")
				$object->image=uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],BLOG_SMALL_IMAGE,BLOG_SMALL_WIDTH,'');

	if($_FILES['imageOriginal']['name']!="")
		$object->image=uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],BLOG_BIG_IMAGE,BLOG_BIG_WIDTH,'');  

	if($_FILES['imageOriginal']['name']==""){
		if(isset($hiddenImage)){
				  $object->image=$hiddenImage;	
		}else{
				 $object->image=NULL;
		}			 	  
	}
	$object->status=isset($_GET['status']) ? $_GET['status'] : 1;
	if(isset($_POST['btnAdd'])){
		$object->insert();
		redirect($pageName."?msg=add");
	}
	if(isset($_POST['btnUpdate'])){
		
		//===============update multiple images===========
		for($ti=0;$ti<$totalImgs;$ti++)
		{
			$img_id = "image_id".$ti;

			/* $totimg = "total_imgs".$ti;
			$object->$totimg = $$img_title;
			echo $object->$totimg."<br/>"; */
			// echo $$img_title."<br/>";

			$img_title = "img_tit".$ti;
			$$img_title = ($$img_title!="Enter Title") ? $$img_title : "";
			
			$img_seq = "img_seq".$ti;
			$$img_seq = ($$img_seq!="Enter Sequence") ? $$img_seq : "";
			// echo $$img_id." : ".$$img_title." : ",$$img_seq."<br/>";
			$pro_price = "price".$ti;
			$$pro_price = ($$pro_price!="Enter Price") ? $$pro_price : "";
			
			$remove_img = "rem_img".$ti;
						
			if(!empty($$remove_img))
			{
				$object->img_id = $$img_id;
				$object->delRecbyImgId();
			}
			else
			{
				$object->updateRecById($$img_id,$$img_title,$$img_seq,$$pro_price);
			}
		}
		//============end of update multiple images=======
		
		
		$object->update();
		
		if(isset($_POST['page'])){
			$redirect = "?page=".$_POST['page']."&msg=edit"; 	
		}else{
			$redirect = "?msg=edit";	
		}
		
		//redirect($pageName.$redirect);
	}	
	if(isset($_POST['btnApply'])){
		
		//===============update multiple images===========
		for($ti=0;$ti<$totalImgs;$ti++)
		{
			$img_id = "image_id".$ti;

			/* $totimg = "total_imgs".$ti;
			$object->$totimg = $$img_title;
			echo $object->$totimg."<br/>"; */
			// echo $$img_title."<br/>";

			$img_title = "img_tit".$ti;
			$$img_title = ($$img_title!="Enter Title") ? $$img_title : "";
			
			$img_seq = "img_seq".$ti;
			$$img_seq = ($$img_seq!="Enter Sequence") ? $$img_seq : "";
			// echo $$img_id." : ".$$img_title." : ",$$img_seq."<br/>";
			$pro_price = "price".$ti;
			$$pro_price = ($$pro_price!="Enter Price") ? $$pro_price : "";
			
			$remove_img = "rem_img".$ti;
						
			if(!empty($$remove_img))
			{
				$object->img_id = $$img_id;
				$object->delRecbyImgId();
			}
			else
			{
				$object->updateRecById($$img_id,$$img_title,$$img_seq,$$pro_price);
			}
		}
		//============end of update multiple images=======
				
		$object->update();
		
		if(isset($_POST['page'])){
			$redirect = "?id=".$_POST['hid']."&page=".$_POST['page']; 	
		}else{
			$redirect = "?id=".$_POST['hid'];	
		}
		
		redirect($pageName.$redirect);
	}		
	if(isset($_POST['btnAction']))	{
		switch($optAction){
			case 0:
					$object->deleteSelect($chkAction);
					redirect($pageName."?msg=del");
					break;
			case 1:
					$object->statusUpdatePublish($chkAction);
					redirect($pageName."?msg=Publish");
					break;
			case 2:
					$object->statusUpdateUnPublish($chkAction);
					redirect($pageName."?msg=UnPublish");
					break;
			case 3:
					for($i=0;count($categoryId)>$i;$i++){
						$object->id=$categoryId[$i];
						$object->seqno=$txtSeqNo[$i];
						$object->sequenceUpdate();				
					}	
					redirect($pageName."?msg=seq");					
			} 
		}						
	if(isset($_GET['id']))
		$editRec=$object->selectRecById();									
	if(isset($_GET['delete'])){				  	
		$delRec=$object->selectRecById();	
		if($delRec[0]['image']!=""){	
			unlink(PROPERTIES_BIG_IMAGE.$delRec[0]['image']);						
			unlink(PROPERTIES_SMALL_IMAGE.$delRec[0]['image']);
		}	
		$object->delete();
		redirect($pageName."?msg=del");
	}	
	if(isset($_GET['status'])){			
		$object->status();
		redirect($pageName."?msg=status");		
	}
	
	// Sorting Start 
	
if (isset($_REQUEST['editTblBool']))
   $editTblBool = $_REQUEST['editTblBool'];
else
   $editTblBool=0;

if (isset($_REQUEST['ascdsc']))
   $ascdsc = $_REQUEST['ascdsc'];
else
   $ascdsc=0;

if (isset($_REQUEST['sortClName']))
   $sortClName = $_REQUEST['sortClName'];
else
   $sortClName="";

if (isset($_REQUEST['offset']))
   $offset=$_REQUEST['offset'];
else
   $offset=0;


if ($editTblBool!=1)
{
	if ($ascdsc==0)
		$ascdsc = 1;
	else
		$ascdsc = 0;
}

// Sorting End
	
	$listRec=$object->paging($sql);
	
    include("html/frmBlog.php");
} 

function displaySubCat($cid,$n,$selid) 
	{
		include("inc/clsObj.php");	
		$objGstCat->id=$cid;
		$menuSubCatList=$objGstCat->menuSubCategoryList();
		
		$n+=2;
		for($i=0;$i<count($menuSubCatList);$i++)
		{ ?>
		<option value="<?=$menuSubCatList[$i]['id'];?>" <?php if($menuSubCatList[$i]['id']==$selid){?> selected <?php }?> ><?php  echo str_repeat("&nbsp;",$n).'--'.$menuSubCatList[$i]['category_name'];?></option>
		<? displaySubCat($menuSubCatList[$i]['id'],$n+5,$selid); 
		}
	}
?>
