<?php
$msg="Change Password ";
include("template.php");
function main()
{	
include("inc/clsObj.php");
	   if(isset($_POST['btnAdminChangePassword']))
   		{
			extract($_POST);
			$obj_admin->id=$_SESSION['memberid'];
			$adminRec=$obj_admin->selectRecById();			
			if($adminRec[0]['adminPassword']==encryptPassword($txtOldPassword))
				{
					$obj_admin->adminPassword=encryptPassword($txtNewPassword);
					$obj_admin->adminUpdatePassword();
				}
	?><script>document.location="codeManageAdminUser.php?msg=chp"</script><? 					
		}	
include("html/frmAdminChangePassword.php");
}?>		