<div id="qm0" class="qmmc">
    <?php for($i=0;$i<count($adminListRec);$i++){
	//=============define rights to access the page=========
	if(($_SESSION['accessby']=="admin") || ($adminListRec[$i]['head_rights']==1  && $_SESSION['accessby']=="head") || ($adminListRec[$i]['executive_rights']==1  && $_SESSION['accessby']=="executive"))
	{
	
       $objAdminMenu->id=$adminListRec[$i]['id'];
    	$adminSubListRec=$objAdminMenu->menuSubCategoryList();
		if(count($adminSubListRec)==0)
			{
     ?>   
	     <a href="<?=$adminListRec[$i]['adminMenuLink'];?>">
                <?=$adminListRec[$i]['adminMenuName'];?>
         </a>
     <?php } else { ?>
		
	    <a class="qmparent" href="<?=$adminListRec[$i]['adminMenuLink'];?>">
         <?=$adminListRec[$i]['adminMenuName'];?>
        </a>
			<div>
            <?php for($j=0;$j<count($adminSubListRec);$j++){
			
			if(($_SESSION['accessby']=="admin") || ($adminSubListRec[$j]['head_rights']==1  && $_SESSION['accessby']=="head") || ($adminSubListRec[$j]['executive_rights']==1  && $_SESSION['accessby']=="executive"))
			{ ?>
		    	<a href="<?=$adminSubListRec[$j]['adminMenuLink'];?>">
				<?=$adminSubListRec[$j]['adminMenuName'];?>
                </a>
        	<?php }
			}
			?>
			</div>
   <?php }
   	} //======end fo testing rights=========
   }?> 
<span class="qmclear"> </span>
</div>
<script type="text/javascript">qm_create(0,false,0,500,'lev2',false,false,false,true);
</script>