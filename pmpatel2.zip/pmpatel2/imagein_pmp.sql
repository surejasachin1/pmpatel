-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2017 at 08:01 PM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imagein_pmp`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminmaster`
--

CREATE TABLE `adminmaster` (
  `id` int(11) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminUsername` varchar(255) NOT NULL,
  `adminPassword` varchar(255) NOT NULL,
  `adminEmail` varchar(255) NOT NULL,
  `adminJoinDate` date NOT NULL,
  `adminRights` varchar(255) NOT NULL,
  `adminLastLogin` varchar(255) NOT NULL,
  `adminIp` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminmaster`
--

INSERT INTO `adminmaster` (`id`, `adminName`, `adminUsername`, `adminPassword`, `adminEmail`, `adminJoinDate`, `adminRights`, `adminLastLogin`, `adminIp`, `status`) VALUES
(1, 'Admin', 'admin', 'VZlSzZlVsNnUsRGVU1GeXVGSOhVVB1TP', 'rahul@pmpatel.com', '2010-03-03', '', '', '', 1),
(2, 'Prakash', 'prakash', '=AFVxIkVWZ1RhxmRhFWRap2UEZkVZt2Y10EbWlXYHFDa', 'info@domainname.com', '2013-03-22', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `adminmenumgr`
--

CREATE TABLE `adminmenumgr` (
  `id` int(11) NOT NULL,
  `adminMenuSubId` int(11) NOT NULL,
  `seqNo` int(11) NOT NULL DEFAULT '0',
  `adminMenuName` varchar(255) NOT NULL,
  `adminMenuDesc` text NOT NULL,
  `adminMenuLink` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminmenumgr`
--

INSERT INTO `adminmenumgr` (`id`, `adminMenuSubId`, `seqNo`, `adminMenuName`, `adminMenuDesc`, `adminMenuLink`, `status`) VALUES
(5, 0, 1, 'Admin ', '', '#', 1),
(6, 5, 1, 'Manage user', '', 'codeAdminUser.php', 1),
(8, 5, 2, 'Change Password', '', 'codeAdminChangePassword.php', 1),
(9, 0, 4, 'Front Menu', '', 'codeFrontMenu.php', 1),
(15, 5, 3, 'Admin Menu', '', 'codeAdminMenu.php', 1),
(16, 0, 6, 'Dashboard', '', 'frmMain.php', 1),
(27, 0, 6, 'Category & Products', '', '#', 1),
(28, 27, 1, 'Categories', '', 'codeProCategory.php', 1),
(32, 0, 7, 'Clients Logo', '', 'codeManagePhotos.php', 1),
(33, 0, 6, 'Banners', '', 'codeManageBanner.php', 1),
(47, 0, 12, 'Social Links', '', 'codeSocialLinks.php', 1),
(48, 0, 13, 'Testimonials', '', 'codeTest.php', 1),
(49, 0, 20, 'Settings', '', '#', 1),
(50, 49, 1, 'Global Configuration', '', 'codeGlobalConfig.php', 1),
(51, 0, 5, 'Registration', '', 'codeEvent.php', 1),
(52, 27, 2, 'Products', '', 'codeProducts.php', 1),
(53, 0, 10, 'Blog', '', '#', 1),
(54, 0, 6, 'Videos', '', 'codeManageVideos.php', 1),
(55, 53, 2, 'Blogs', '', 'codeBlog.php', 1),
(56, 53, 2, 'Blog Category', '', 'codeGstCat.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `caption` text NOT NULL,
  `url_link` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `name`, `seqNo`, `caption`, `url_link`, `image`, `status`) VALUES
(1, 'Choosing a financial advisor ', 1, '<p>We will help you take control of the things that matter most in your life</p>', '#', 'mb60rihn1jpg.jpg', 1),
(2, 'Personal<br/>Advisor Services ', 2, '<p>You may sleep tight while we are taking care of your finance issues.</p>', '#', 'c70fqcm42jpg.jpg', 1),
(3, 'Reliable & Trusted Advice ', 3, '<p>Our compnay provides worry-free services  									you can always count on.</p>', '#', 'f44wia0u3jpg.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `alias_name` text NOT NULL,
  `posted_by` varchar(250) NOT NULL,
  `size` varchar(255) NOT NULL,
  `price` float(8,2) NOT NULL,
  `description` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `new_arrival` tinyint(1) NOT NULL DEFAULT '0',
  `hot_product` tinyint(1) NOT NULL,
  `metaTitle` text NOT NULL,
  `metaDescription` text NOT NULL,
  `metaKeywords` text NOT NULL,
  `status` int(1) NOT NULL,
  `created_on` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `catid`, `seqNo`, `product_name`, `alias_name`, `posted_by`, `size`, `price`, `description`, `image`, `new_arrival`, `hot_product`, `metaTitle`, `metaDescription`, `metaKeywords`, `status`, `created_on`) VALUES
(13, 8, 1, ' Ten Facts You Might Not Know About Stamp Duty ', '', '', '', 0.00, '<p>Sed ut perspiciatis, unde omnis iste natus error sit voluptatem  accusantium doloremque laudantium, totam rem aperiam eaque ipsa, quae ab  illo inventore veritatis et quasi architecto beatae vitae dicta sunt,  explicabo. Nemo enim ipsam voluptatem...</p>', '', 0, 0, ' Ten Facts You Might Not Know About Stamp Duty ', 'Ten Facts You Might Not Know About Stamp Duty ', 'Ten Facts You Might Not Know About Stamp Duty ', 1, '0000-00-00'),
(14, 9, 1, ' Ten Facts You Might Not Know About Stamp Duty ', '', '', '', 0.00, '<p>Sed ut perspiciatis, unde omnis iste natus error sit  voluptatem  accusantium doloremque laudantium, totam rem aperiam eaque  ipsa, quae ab  illo inventore veritatis et quasi architecto beatae vitae  dicta sunt,  explicabo. Nemo enim ipsam voluptatem...</p>\r\n<div class="column-1_2">&nbsp;</div>', '', 0, 0, ' Ten Facts You Might Not Know About Stamp Duty ', ' Ten Facts You Might Not Know About Stamp Duty ', ' Ten Facts You Might Not Know About Stamp Duty ', 1, '0000-00-00'),
(17, 8, 2, 'testing', '', 'Pratik Rathod', '', 0.00, '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod<br />\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,<br />\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo<br />\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse<br />\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non<br />\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', '', 1, 1, '', '', '', 1, '15/02/2017');

-- --------------------------------------------------------

--
-- Table structure for table `blog_comment`
--

CREATE TABLE `blog_comment` (
  `img_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `comment` text NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog_comment`
--

INSERT INTO `blog_comment` (`img_id`, `product_id`, `name`, `comment`, `email`) VALUES
(1, 13, 'test', 'test', 'test@gmail.com'),
(2, 13, 'test', 'test', 'test@gmail.com'),
(3, 14, 'test', 'njihk', 'kaneriyanidhi271@gmail.com'),
(4, 13, 'deve', 'testlive', 'developer@gmail.com'),
(5, 13, 'shailesh', 'thanks', 'info@imagewebsolution.com');

-- --------------------------------------------------------

--
-- Table structure for table `blog_img`
--

CREATE TABLE `blog_img` (
  `img_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `img_sequence` int(11) NOT NULL,
  `img_title` text NOT NULL,
  `price` float(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog_img`
--

INSERT INTO `blog_img` (`img_id`, `product_id`, `name`, `img_sequence`, `img_title`, `price`) VALUES
(2, 13, '0ahmipj41jpg.jpg', 0, '', 0.00),
(3, 14, 'sw8rjp403jpg.jpg', 0, '', 0.00),
(4, 15, 'j2tw565vpratikjpg.jpg', 0, '', 0.00),
(5, 16, '7z3w8x2qpratikjpg.jpg', 0, '', 0.00),
(7, 17, '27mwogzfgstjpg.jpg', 0, '', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(11) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `metaTitle` text NOT NULL,
  `metaDescription` text NOT NULL,
  `metaKeywords` text NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `verificationcode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `seqNo`, `product_name`, `password`, `position`, `email`, `phone`, `company`, `metaTitle`, `metaDescription`, `metaKeywords`, `status`, `verificationcode`) VALUES
(12, 0, 'test123', 'test', 'test12', 'kaneriyanidhi271@gmail.com', '1234567890123', 'test12', 'test12', 'test', 'test', 1, ''),
(25, 0, 'nidhi', '13mnjh', 'position', 'dfghjkloiuy@gmail.com', '1234567890', 'company', '', '', '', 1, '1c38d8'),
(26, 0, 'nidhi', '13mnjh', 'position', 'dg@gmail.com', '909970363', 'tr', '', '', '', 1, 'bb92f6'),
(27, 0, 'fial', 'final', 'final', 'final@gmail.com', 'hijg', 'final', '', '', '', 1, 'd9636a'),
(28, 0, 'developer', 'test', 'position', 'developer@gmail.com', '1234567890', 'company', '', '', '', 1, 'e84218'),
(29, 0, 'shailesh patel', 'Sha1234', 'Owner', 'info@imagewebsolution.com', '9099145315', 'Image Web Solution', '', '', '', 1, 'fe54b5'),
(30, 0, 'Rahul', 'Rahul123', 'Partner', 'rahul@pmpatel.com', '9825232461', 'Pmp', '', '', '', 1, '1c88aa'),
(31, 0, 'Rahul Patel', 'rahul123', 'Partner', 'ho@pmpatel.com', '9825232461', 'P M P', '', '', '', 1, 'ff881a'),
(32, 0, 'Dgweb', 'dgweb', 'Developer', 'dgwebdeveloper@gmail.com', '7575004933', 'Dgweb', '', '', '', 1, '380104');

-- --------------------------------------------------------

--
-- Table structure for table `event_img`
--

CREATE TABLE `event_img` (
  `img_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `img_sequence` int(11) NOT NULL,
  `img_title` text NOT NULL,
  `price` float(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `global_config`
--

CREATE TABLE `global_config` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `constantName` varchar(255) NOT NULL,
  `constantValue` varchar(255) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `global_config`
--

INSERT INTO `global_config` (`id`, `name`, `seqNo`, `constantName`, `constantValue`, `status`) VALUES
(2, 'Banner Big Image Width', 0, 'BANNER_BIG_WIDTH', '1250', 1),
(3, 'Banner Big Image Height', 0, 'BANNER_BIG_HEIGHT', '500', 1),
(5, 'Banner Small Image Width', 0, 'BANNER_SMALL_WIDTH', '98', 1),
(6, 'Banner Small Image Height', 0, 'BANNER_SMALL_HEIGHT', '59', 1),
(8, 'Category Big Image Width', 0, 'CATEGORY_BIG_WIDTH', '770', 1),
(9, 'Category Big Image Height', 0, 'CATEGORY_BIG_HEIGHT', '504', 1),
(11, 'Category Small Image Width', 0, 'CATEGORY_SMALL_WIDTH', '370', 1),
(12, 'Category Small Image Height', 0, 'CATEGORY_SMALL_HEIGHT', '245', 1),
(14, 'Product Big Image Width', 0, 'PRODUCT_BIG_WIDTH', '770', 1),
(15, 'Product Big Image Height', 0, 'PRODUCT_BIG_HEIGHT', '504', 1),
(17, 'Product Small Image Width', 0, 'PRODUCT_SMALL_WIDTH', '540', 1),
(18, 'Product Small Image Height', 0, 'PRODUCT_SMALL_HEIGHT', '429', 1),
(21, 'Photo Gallery Big Image Width', 0, 'PHOTO_GALLERY_BIG_WIDTH', '815', 1),
(22, 'Photo Gallery Big Image Height', 0, 'PHOTO_GALLERY_BIG_HEIGHT', '543', 1),
(24, 'Photo Gallery Small Image Width', 0, 'PHOTO_GALLERY_SMALL_WIDTH', '298', 1),
(25, 'Photo Gallery Small Image Height', 0, 'PHOTO_GALLERY_SMALL_HEIGHT', '94', 1),
(33, 'Social Image Width', 0, 'SOCIAL_IMAGE_WIDTH', '40', 1),
(35, 'Product Limit', 0, 'PRODUCT_LIMIT', '10', 1),
(36, 'Website Name', 0, 'SITE_NAME', 'Distinkt Happeniings', 1),
(37, 'Powered By', 0, 'POWER_BY', 'Image Web Solution', 1),
(38, 'Powered By Website', 0, 'POWER_BY_WEBSITE', 'http://www.domainname.com/', 1),
(39, 'Currency', 0, 'CURRENCY', '$', 1),
(40, 'Meta Title', 0, 'META_TITLE', 'Distinkt Happeniings', 1),
(41, 'Meta Keyword', 0, 'META_KEYWORD', 'Distinkt Happeniings', 1),
(42, 'Meta Description', 0, 'META_DESC', 'Distinkt Happeniings', 1),
(43, 'We Offer', 0, 'WE_OFFER', 'We Offer', 1),
(44, 'User File Path', 0, 'USER_FILE_PATH', '/UserFiles/Distinkt_Happeniings/', 1),
(45, 'Event Big Image Width', 0, 'EVENT_BIG_WIDTH', '815', 1),
(46, 'Event Big Image height', 0, 'EVENT_BIG_HEIGHT', '543', 1),
(47, 'Event Small Image Width', 0, 'EVENT_SMALL_WIDTH', '370', 1),
(48, 'Event Small Image Height', 0, 'EVENT_SMALL_HEIGHT', '247', 1),
(49, 'Blog Big Image Width', 0, 'BLOG_BIG_WIDTH', '700', 1),
(50, 'Blog Big Image Height', 0, 'BLOG_BIG_HEIGHT', '300', 1),
(51, 'Blog Small Image Height', 0, 'BLOG_SMALL_HEIGHT', '300', 1),
(52, 'Blog Small Image Width', 0, 'BLOG_SMALL_WIDTH', '300', 1);

-- --------------------------------------------------------

--
-- Table structure for table `gst_categories`
--

CREATE TABLE `gst_categories` (
  `id` int(11) NOT NULL,
  `subcatid` int(11) NOT NULL,
  `seq_no` int(11) NOT NULL DEFAULT '0',
  `category_name` varchar(255) NOT NULL,
  `alias_name` text NOT NULL,
  `description` longtext NOT NULL,
  `image` text NOT NULL,
  `new_arrival` tinyint(1) NOT NULL,
  `metaTitle` text NOT NULL,
  `metaDescription` text NOT NULL,
  `metaKeywords` text NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gst_categories`
--

INSERT INTO `gst_categories` (`id`, `subcatid`, `seq_no`, `category_name`, `alias_name`, `description`, `image`, `new_arrival`, `metaTitle`, `metaDescription`, `metaKeywords`, `status`) VALUES
(8, 0, 1, 'GST ', '', '<p>Training and Continuing Education of resource persons of any organisation is key to success.  Emerging economy and rapidly changing fiscal policies require extensive training and continuing education of employees at all levels.  Our expert team mates always feel happy to provide following services :</p>\n<ul class="sc_list  sc_list_style_ul">\n    <li class="sc_list_item">Subject Level Training to Finance, Taxation and Accounting Personnel of clients</li>\n    <li class="sc_list_item">Formation and registration of Partnership Firms</li>\n    <li class="sc_list_item">Continuing Educational Workshops on current tax and financial topics</li>\n</ul>\n<p>&nbsp;</p>', 'Corporate_Training_and_Continuing_Education_vfqfxxnf.png', 0, 'GST', 'GST', 'GST', 1),
(9, 0, 2, 'Website', '', '<p>Finance is a driving factor of any business.  Availability of adequate finance at appropriate cost is essential to a sustainable business ideas.  We assist our client in ensure availability of required amount of financial support in a cost effective manner.  Over and above general financial consultancy, we also provide services in respect of financial syndication by using our vast reputed experience and untainted relations.  Services includes :</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<ul class="sc_list  sc_list_style_ul">\r\n    <li class="sc_list_item">Debt Syndication to meet long term as well as short term financial needs i.e. Term Loans, Cash</li>\r\n    <li class="sc_list_item">Credit Limits, Guarantee Limits, Letters of Credit etc.</li>\r\n    <li class="sc_list_item">Planning, structurisation and execution of Private Equity options</li>\r\n    <li class="sc_list_item">Mergers and Acquisitions</li>\r\n    <li class="sc_list_item">Joint Ventures</li>\r\n    <li class="sc_list_item">Business Valuation and Feasibility Study</li>\r\n</ul>\r\n<p>&nbsp;</p>', 'Financial_Consulting_and_Syndication_b3eh0xzw.png', 0, 'Website', 'Website', 'Website', 1);

-- --------------------------------------------------------

--
-- Table structure for table `menumgr`
--

CREATE TABLE `menumgr` (
  `id` int(11) NOT NULL,
  `menuSubId` int(11) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `menuName` varchar(255) NOT NULL,
  `alias_name` text NOT NULL,
  `menuPosition` varchar(255) NOT NULL,
  `menuDesc` longtext NOT NULL,
  `menuUrl` varchar(255) NOT NULL,
  `menuFileName` varchar(255) NOT NULL,
  `menuType` varchar(255) NOT NULL,
  `menuTargetWindow` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `metaTitle` text NOT NULL,
  `metaDescription` text NOT NULL,
  `metaKeywords` text NOT NULL,
  `menuRobots` varchar(255) NOT NULL,
  `menuAuthor` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menumgr`
--

INSERT INTO `menumgr` (`id`, `menuSubId`, `seqNo`, `menuName`, `alias_name`, `menuPosition`, `menuDesc`, `menuUrl`, `menuFileName`, `menuType`, `menuTargetWindow`, `status`, `metaTitle`, `metaDescription`, `metaKeywords`, `menuRobots`, `menuAuthor`) VALUES
(1, 0, 1, 'Home', '', 'top', '<div class="row">\r\n<div class="col-md-12 col-sm-12">\r\n<h3>Welcome To SOI Global Pte. Ltd.</h3>\r\n<p>SOI GLOBAL PTE LTD is the destination where you are eased with the availability of diversified  assortment of commodities The Company is primarily engaged in trading of various industrial Minerals, Chemicals, Agro Commodities &amp; Fertilizers. In addition to this, we are also engaged in Ship Chartering and Trading of All Agri Commodities &amp; wide range of FMCG products.... <a href="#" style="color:#2a0e72;"> Read More</a></p>\r\n</div>\r\n</div>', 'index1.php', 'jyk2xyrq', '3', '', 1, 'Welcome To SOI Global Pte. Ltd.', 'Welcome To SOI Global Pte. Ltd.', 'Welcome To SOI Global Pte. Ltd.', '', ''),
(2, 0, 2, 'About Us', '', 'top', '<p>&nbsp;</p>\r\n<p><section id="content">\r\n<div class="container">\r\n<div class="row">\r\n<div class="grid_9">\r\n<div class="grid_12">\r\n<div class="row">\r\n<div class="grid_12">\r\n<h3 style="font-family: FontAwesome; font-size: 32px; font-weight:600;"><i>SECRET behind the name.....</i></h3>\r\n<div style="padding-left: 47px;" class="grid_10"><blockquote style="text-align:left;">\r\n<p style="background-color:#e00971; padding:25px; border:solid 1px white; font-weight:600; font-family: FontAwesome; font-size: 27px; line-height: 32px;" class="text1 offset__1">&quot;An occasion comes rare in each one''s life. It is a<strong> HAPPENING </strong>which is expected to be memorable. But this can happen only if it is <strong>DISTINKT</strong> i.e. different or unique.&quot;</p>\r\n</blockquote></div>\r\n<div class="grid_1">&nbsp;</div>\r\n<div class="clear">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div class="grid_12">\r\n<h4 style="font-family: FontAwesome; font-size: 32px; font-weight:600;">PROFILE OF THE CORE TEAM</h4>\r\n<p class="text1 offset__1"><strong style="color:#de24bb;">Distinkt Happeniings</strong> is led by <strong>Narendra Davara</strong> who has qualified from <em><strong>&lsquo;National Academy of Event Management &amp; Development&rsquo;</strong></em>. He has gained considerable experience in various aspects of event management industry. He has good contacts with vendors and service providers that are the best in their respective field. During the training itself he had a chance to work with some of the largest event companies in Gujarat and had handled destination &amp; theme weddings, exhibitions, corporate events etc.</p>\r\n<p class="text1 offset__1"><strong>Diya Davara</strong> has come up to be a backbone for the company. She plays an important role in maintaining communication with the clients, handling office work and developing creative ideas for marketing.</p>\r\n<h4 style="font-family: FontAwesome; font-size: 32px; font-weight:600;">PROFILE OF <span style="color:#de24bb;">DISTINKT HAPPENIINGS..</span></h4>\r\n<p class="text1 offset__1">Capable of doing all kinds of events &ndash; exhibitions, stall designing, conferences, property launch, seminars, road shows, fashion shows, birthday parties, small to big budget weddings, festivals, promotional activities, etc.</p>\r\n<p class="text1 offset__1">Giving services in all aspects of events &ndash; production or decor, catering or food &amp; beverages, logistics or transportation, hospitality, artist management, co-ordination, manpower supply, etc.</p>\r\n<p class="text1 offset__1"><strong style="color:#de24bb;">DH</strong> also takes projects in contract of other renowned companies. Taking the whole event on its shoulders without giving its name..</p>\r\n<p class="text1 offset__1"><strong style="color:#de24bb;">DH</strong> aims at proper planning, warm service, unique creativity &amp; exclusive entertainment within the tradition and budget of the client..</p>\r\n<p class="text1 offset__1">The team believes in hard-work, perseverance and best services..</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</section></p>\r\n<p>&nbsp;</p>', 'knowus.php', '50gd4x5g', '3', '', 1, 'Know About Distinkt Happeniings', 'Know About Distinkt Happeniings', 'Know About Distinkt Happeniings', '', ''),
(3, 0, 3, 'Services', '', 'top', '<p>Coming soon...</p>', 'expertise.php', 'smpgh63s', '3', '', 1, 'Services', 'Services', 'Services', '', ''),
(6, 0, 13, 'Address', '', 'top', '<div class="textwidget">\r\n<ul class="sc_list  sc_list_style_iconed">\r\n    <li class="sc_list_item"><span class="sc_list_icon icon-home-1"> </span> 										First Floor, <br />\r\n    Sutaria Complex,<br />\r\n    Maharashtra Society, <br />\r\n    Behind HCG ( Medisurge ) Hospital, <br />\r\n    Mithakhali, Ahmedabad - 380009,<br />\r\n    Gujarat, India.</li>\r\n    <li class="sc_list_item"><span class="sc_list_icon icon-smartphone"> </span>+91-79-26420068 / 26426466</li>\r\n    <li class="sc_list_item"><span class="sc_list_icon icon-mail-2"> </span> 										<a class="footer_email" href="mailto:rahul@pmpatel.com">rahul@pmpatel.com</a></li>\r\n    <li class="sc_list_item"><span class="sc_list_icon icon-globe"> </span> 										<a class="footer_map" href="#">www.pmpatel.com</a></li>\r\n    <li class="sc_list_item"><span class="sc_list_icon icon-location-1"> </span> 										<a class="footer_map" href="#">Map &amp; Directions</a></li>\r\n</ul>\r\n<div class="sc_socials sc_socials_size_small">\r\n<div class="sc_socials_item"><a href="#" target="_blank" class="social_icons social_tumblr icons"> 											<span class="icon-tumblr"> </span> 											<span class="sc_socials_hover icon-tumblr"> </span> 										</a></div>\r\n<div class="sc_socials_item"><a href="#" target="_blank" class="social_icons social_facebook icons"> 											<span class="icon-facebook"> </span> 											<span class="sc_socials_hover icon-facebook"> </span> 										</a></div>\r\n<div class="sc_socials_item"><a href="#" target="_blank" class="social_icons social_gplus icons"> 											<span class="icon-gplus"> </span> 											<span class="sc_socials_hover icon-gplus"> </span> 										</a></div>\r\n<div class="sc_socials_item"><a href="#" target="_blank" class="social_icons social_skype icons"> 											<span class="icon-skype"> </span> 											<span class="sc_socials_hover icon-skype"> </span> 										</a></div>\r\n</div>\r\n</div>', 'inquiry.html', 'eb5p3ye4', '3', '', 0, 'Inquiry', 'Inquiry - D', 'Inquiry - K', '', ''),
(7, 0, 5, 'Updates', '', 'top', '<div class="col-md-12">\r\n<div class="about-logo">\r\n<p>We have established an ongoing relationship with our clients by providing them high quality Products. We are striving to elevate our standard of excellence for the benefit of our clients.<br />\r\nWe solicit queries from traders, buyers and others interested in our products.<br />\r\nPlease send in your queries to further know details of our products and services:</p>\r\n</div>\r\n</div>\r\n<div class="row">\r\n<div class="col-md-6">\r\n<h3>Company Addresses:</h3>\r\n<h4>SOIGlobal Pte Ltd.</h4>\r\n<strong>USA REP OFFICE </strong>\r\n<p>Global Market Intelligence,                                   POB 800921,                                  Miami,Florida 33280.<br />\r\nPh:(305)761-1588,                                   Fax:(305)792-5041</p>\r\n<br />\r\n<strong>SINGAPORE OFFICE</strong>\r\n<p>10, Anson Road,                                   #42-01 International Plaza, Singapore 079903.<br />\r\nTel: +65 62250021,                                  Fax: +65 62250072</p>\r\n<br />\r\n<strong>CANADA REP OFFICE</strong>\r\n<p>40, Morning Glory Crescent, Winnipeg Manitoba, R2J3Y6 Canada.<br />\r\nCell No.:  + 1-204 291-4202,                                   Phone No.:   + 1-1-204-255 5322</p>\r\n<br />\r\n<h4>Shreeji Overseas India Pvt. Ltd.</h4>\r\n<strong>&quot; Shreeji House&quot; Leaders in Global Trade</strong>\r\n<p>Gandhidham Kutch Gujarat 370201 India.<br />\r\nPh: +91-2836 - 234210 / 235964</p>\r\n</div>\r\n<div class="col-md-6">&nbsp;</div>\r\n</div>', '#', 'xidhcd4q', '3', '', 1, 'Updates', 'Updates', 'Updates', '', ''),
(8, 0, 14, 'Get In touch', '', 'top', '<div class="textwidget">\r\n<ul class="sc_list  sc_list_style_iconed">\r\n    <li class="sc_list_item"><span class="sc_list_icon icon-smartphone"> </span>+91-79-26420068 / 26426466</li>\r\n    <li class="sc_list_item"><span class="sc_list_icon icon-mail-2"> </span> 										<a class="footer_email" href="mailto:rahul@pmpatel.com">rahul@pmpatel.com</a></li>\r\n    <li class="sc_list_item"><span class="sc_list_icon icon-globe"> </span> 										<a class="footer_map" href="#">www.pmpatel.com</a></li>\r\n    <li class="sc_list_item"><span class="sc_list_icon icon-location-1"> </span> 										<a class="footer_map" href="#">Map &amp; Directions</a></li>\r\n</ul>\r\n</div>\r\n<p>&nbsp;</p>\r\n<div class="sc_socials sc_socials_size_small">\r\n<div class="sc_socials_item"><a href="#" target="_blank" class="social_icons social_tumblr icons"> 											<span class="icon-tumblr"> </span> 											<span class="sc_socials_hover icon-tumblr"> </span> 										</a></div>\r\n<div class="sc_socials_item"><a href="#" target="_blank" class="social_icons social_facebook icons"> 											<span class="icon-facebook"> </span> 											<span class="sc_socials_hover icon-facebook"> </span> 										</a></div>\r\n<div class="sc_socials_item"><a href="#" target="_blank" class="social_icons social_gplus icons"> 											<span class="icon-gplus"> </span> 											<span class="sc_socials_hover icon-gplus"> </span> 										</a></div>\r\n<div class="sc_socials_item"><a href="#" target="_blank" class="social_icons social_skype icons"> 											<span class="icon-skype"> </span> 											<span class="sc_socials_hover icon-skype"> </span> 										</a></div>\r\n</div>', 'sitemap.html', 'cxd6k7d6', '3', '', 0, 'Sitemap', 'Sitemap - D', 'Sitemap - K', '', ''),
(9, 0, 12, 'Login', '', 'top', '', '#', '0r50umwy', '3', '', 1, 'Login', 'Login', 'Login', '', ''),
(10, 0, 9, 'About Us', '', 'top', '<div class="logo_descr">M/s P M Patel & Co, Chartered Accountants ("PMP") was established in the year 1967 by its Managing Partner Shri CA Premjibhai M Patel.  We are entrusted with a high degree of professional ethics, integrity, technical competence towards our clients''...<br><br><a href="#">Read More</a></div>', '', 'jamxmkcm', '2', '', 0, 'Address', 'Address', 'Address', '', ''),
(13, 0, 4, 'GST', '', 'top', '', 'gst-blog.php?id=8', 'gwodze36', '3', '', 1, 'GST', 'GST', 'GST', '', ''),
(14, 0, 6, 'Knowledge', '', 'top', '', 'clientele.php', 't7jxmxpv', '3', '', 1, 'Knowledge', 'Knowledge', 'Knowledge', '', ''),
(15, 0, 10, 'Testimonals', '', 'top', '<div class="testim">I am absolutely pleased and satisfied with this company&rsquo;s service. It is so great to work with a financial adviser who is truly interested in their client&rsquo;s needs, goals and preferences. I am really impressed with their commitment. <br />\r\n<br />\r\n<em>- Alexander Davis</em> 									<br />\r\n<a href="#">View All Testimonials</a></div>', '', 'hf4wwdh4', '2', '', 0, 'Get In Touch', 'Get In Touch', 'Get In Touch', '', ''),
(16, 0, 11, 'Get Connected', '', 'top', '', '#', 'dfnkpg5s', '3', '', 1, 'Get Connected', 'Get Connected', 'Get Connected', '', ''),
(17, 2, 1, 'About Firm', '', 'top', '<div><figure class="sc_image alignleft middle sc_image_shape_square title_approve ">\r\n<div><img src="images/aboutfirm.jpg" alt="" /></div>\r\n<figcaption> About Firm</figcaption>             </figure>  </div>\r\n<p>M/s P M Patel &amp; Co, Chartered Accountants (&quot;PMP&quot;) was established in the year 1967 by its Managing Partner Shri CA Premjibhai M Patel.  We are entrusted with a high degree of professional ethics, integrity, technical competence towards our clients&rsquo; services. Satisfaction of our clientele and the commitment to enduring quality and service, have earned an outstanding reputation in the business and financial communities.  Our long existence in the Indian professional arena supplements the technical proficiency of the client service teams to create powerful business solution tailored to the client''s need.  We focus on clients. We take pride in our ability to provide quality services - whether they are an owner-managed business or a large multinational corporation. We are a multi-skilled, multi-disciplined firm, offering clients a wide range of industry-focused business solutions.</p>', '', 'f4f2e340', '2', '', 1, 'About Firm', 'About Firm', 'About Firm', '', ''),
(18, 2, 2, 'About Partners', '', 'top', '', '', 'r2rd3c8x', '2', '', 1, 'About Partners', 'About Partners', 'About Partners', '', ''),
(19, 3, 1, 'Tax Management and Advisory', '', 'top', '', '', 'jzyic5kq', '2', '', 1, 'Tax Management and Advisory', 'Tax Management and Advisory', 'Tax Management and Advisory', '', ''),
(20, 3, 2, 'Ready to Cook', '', 'top', '', '', 'kytzobxf', '2', '', 1, 'Ready to Cook', 'Ready to Cook', 'Ready to Cook', '', ''),
(25, 2, 3, 'Quality Policy', '', 'top', '<div><figure class="sc_image alignleft middle sc_image_shape_square title_approve ">\r\n<div><img src="images/qualitypolicy.jpg" alt="" /></div>\r\n<figcaption>Quality Policy</figcaption>             </figure></div><p>We strive for ''excellence'' by providing customized solutions that best satisfies the requirements of our clients and continuously improve quality, reliability and service with the help of an effective Quality Management System, encompassing all statutory, regulatory and environmental requirements at our work place.</p>\r\n<p><b>Objectives :</b></p>\r\n<ul class="sc_list  sc_list_style_ul">\r\n    <li class="sc_list_item">To render services in form of solutions that meet clients&rsquo; requirements</li>\r\n    <li class="sc_list_item">Improve productivity and reduce rework</li>\r\n    <li class="sc_list_item">To bring perfection by continuous quality improvements programs</li>\r\n</ul>', '', '64euwttp', '2', '', 1, 'Quality Policy', 'Quality Policy', 'Quality Policy', '', ''),
(26, 2, 4, 'Pro Bono', '', 'top', '<div><figure class="sc_image alignleft middle sc_image_shape_square title_approve ">\r\n<div><img src="images/probono.jpg" alt="" /></div>\r\n<figcaption>  Probono </figcaption>             </figure>     </div>\r\n<p>PRO BONO - Professional work undertaken voluntarily and without payment or at a concessional fees as a public service.   We believe in giving back to the society and helping the public at large.  Our PRO BONO work is driven with a vision to augment thoughts with actions.  We practice what we preach and altruism is our core value.  We are always eager to offer PRO BONO services for deserving causes.</p>\r\n<p>We support the cause of grassroots innovators to enable them to exploit the burgeoning rural industries in India.  From promoting small and mediums scale industries, to offering help to the needy and deserving in the various areas, our firm also organizes and actively contributes to seminars and sessions to bring awareness and to ensure continuing education.</p>\r\n<p>We are always eager to offer PRO BONO services and be associated with deserving causes.</p>\r\n<p>&nbsp;</p>', '', 'cwkv6wr6', '2', '', 1, 'Pro Bono', 'Pro Bono', 'Pro Bono', '', ''),
(27, 7, 1, 'News', '', 'top', '', 'news.php', 'pfwyx2fj', '3', '', 1, 'News', 'News', 'News', '', ''),
(28, 7, 2, 'Blogs', '', 'top', '', 'gst-blog.php?id=9', 'xaboqijk', '3', '', 1, 'Blogs', 'Blogs', 'Blogs', '', ''),
(29, 14, 1, 'Team Login', '', 'top', '', 'kwnteamlogin.php', 'a3s4rqyn', '3', '', 1, 'Team Login', 'Team Login', 'Team Login', '', ''),
(30, 14, 2, 'Client Login', '', 'top', '', 'knwclientlogin.php', 'vzwhk4j3', '3', '', 1, 'Client Login', 'Client Login', 'Client Login', '', ''),
(31, 16, 1, 'Inquiry', '', 'top', '', 'contact.php', 'jfosivuz', '3', '', 1, 'Inquiry', 'Inquiry', 'Inquiry', '', ''),
(32, 16, 3, 'Feedback', '', 'top', '', 'feedback.php', 'tdy787tp', '3', '', 1, 'Feedback', 'Feedback', 'Feedback', '', ''),
(33, 16, 2, 'Career', '', 'top', '', 'career.php', 'xpsmno08', '3', '', 1, 'Career', 'Career', 'Career', '', ''),
(34, 9, 1, 'Team Login', '', 'top', '', 'teamlogin.php', '27zfuk8e', '3', '', 1, 'Team Login', 'Team Login', 'Team Login', '', ''),
(35, 9, 2, 'Client Login', '', 'top', '', 'knwclientlogin.php', '4szhk7qd', '3', '', 1, 'Client Login', 'Client Login', 'Client Login', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `multiple_image_table`
--

CREATE TABLE `multiple_image_table` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `sqno` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `price` float(8,2) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `new_arrival` tinyint(1) NOT NULL DEFAULT '0',
  `hot_product` tinyint(1) NOT NULL,
  `metaTitle` varchar(255) NOT NULL,
  `metaKeywords` text NOT NULL,
  `metaDescription` text NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `multiple_image_table`
--

INSERT INTO `multiple_image_table` (`id`, `catid`, `sqno`, `product_name`, `size`, `price`, `description`, `image`, `new_arrival`, `hot_product`, `metaTitle`, `metaKeywords`, `metaDescription`, `status`) VALUES
(1, 0, 0, 'test', '', 0.00, '', '0urqkngxHydrangeas.jpg', 0, 0, '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `multiple_img`
--

CREATE TABLE `multiple_img` (
  `img_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `img_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` int(11) NOT NULL,
  `catgid` int(11) NOT NULL,
  `seqno` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `catgid`, `seqno`, `name`, `image`, `status`) VALUES
(53, 0, 0, '', 'agmzrw4kAdani_Custom_2png.png', 1),
(54, 0, 0, '', '3xnu0oehdivya_bhaskar_Custom_2png.png', 1),
(55, 0, 0, '', 'z0uoaccnHCL_Custom_2png.png', 1),
(56, 0, 0, '', 'anfhskuxkidzee_log_ca5ea793ba09ec5_Custom_2png.png', 1),
(57, 0, 0, '', '7ejvvi2vLIC_Logo_Custom_2jpg.jpg', 1),
(58, 0, 0, '', '05wc4cccshanti_logo_Custom_2png.png', 1),
(59, 0, 0, '', 'gtb5igr8tatamotors_Custom_2png.png', 1),
(62, 0, 0, '', 'fs33cfzoifkotokiologojpg.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `photo_category`
--

CREATE TABLE `photo_category` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `seqno` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `home` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photo_category`
--

INSERT INTO `photo_category` (`id`, `catid`, `seqno`, `name`, `image`, `home`, `status`) VALUES
(1, 0, 1, 'Category1', 'x3cx6ojxTulipsjpg.jpg', 0, 1),
(2, 0, 2, 'Category2', '8w0nxo48Penguinsjpg.jpg', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `photo_gallery`
--

CREATE TABLE `photo_gallery` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photo_gallery`
--

INSERT INTO `photo_gallery` (`id`, `title`, `image`, `seqNo`, `status`) VALUES
(1, '1', 'onigihi6Chrysanthemumjpg.jpg', 1, 1),
(2, '2', 'vwag3kaePenguinsjpg.jpg', 2, 1),
(3, '3', 'u4b4h4ddTulipsjpg.jpg', 3, 1),
(4, '4', 'pegs4xf7Koalajpg.jpg', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `alias_name` text NOT NULL,
  `size` varchar(255) NOT NULL,
  `price` float(8,2) NOT NULL,
  `description` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `new_arrival` tinyint(1) NOT NULL DEFAULT '0',
  `hot_product` tinyint(1) NOT NULL,
  `metaTitle` text NOT NULL,
  `metaDescription` text NOT NULL,
  `metaKeywords` text NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `catid`, `seqNo`, `product_name`, `alias_name`, `size`, `price`, `description`, `image`, `new_arrival`, `hot_product`, `metaTitle`, `metaDescription`, `metaKeywords`, `status`) VALUES
(114, 1, 1, 'Wheat and Wheat Flour', '', '', 0.00, '<div class="col-md-12 arrival-grid simpleCart_shelfItem">\r\n<div class="grid-arr">\r\n<div class="grid-arrival">\r\n<h5>Milling Wheat ( Soft Wheat)</h5>\r\n<strong style="color: #656565;">Indian Milling wheat is Mostly Soft Wheat.<br />\r\nIndian Milling Wheat Grade I </strong></div>\r\n</div>\r\n</div>\r\n<div class="clearfix">&nbsp;</div>\r\n<div class="col-md-4 arrival-grid simpleCart_shelfItem">\r\n<div class="grid-arr">\r\n<div class="grid-arrival"><strong>Specification :</strong>\r\n<p>- Gluten (On wet Basis) : 25% Min.<br />\r\n- Protein : 12.0 % Min.<br />\r\n- Moisture : 13.0 % .<br />\r\n- Test weight : 78 Kg/HL Min.<br />\r\n- Foreign Matter :2 % Max.<br />\r\n- Damaged : 2 % Max.<br />\r\n- Shriveled / Shrunken : 3% Max.<br />\r\n- Broken : 3% Max.<br />\r\n- Shipped : Bulk in Container''s</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class="col-md-4 arrival-grid simpleCart_shelfItem">\r\n<div class="grid-arr">\r\n<div class="grid-arrival"><figure>		 											<a href="#" class="new-gri" data-toggle="modal" data-target="#myModal2">\r\n<div class="grid-img"><img src="img/wheat1.jpg" class="img-responsive" alt="" /></div>\r\n</a>		 										</figure></div>\r\n</div>\r\n</div>\r\n<div class="col-md-4 arrival-grid simpleCart_shelfItem">\r\n<div class="grid-arr">\r\n<div class="grid-arrival"><figure>		 											<a href="#" class="new-gri" data-toggle="modal" data-target="#myModal2">\r\n<div class="grid-img"><img src="img/wheat2.jpg" class="img-responsive" alt="" /></div>\r\n</a>		 										</figure></div>\r\n</div>\r\n</div>\r\n<div class="clearfix">&nbsp;</div>\r\n<div class="col-md-4 arrival-grid simpleCart_shelfItem">\r\n<div class="grid-arr">\r\n<div class="grid-arrival"><strong>Grade 1:</strong><br />\r\n<strong style="color: #656565;">Specifications of Indian Fine White Refined Wheat Flour</strong>\r\n<p>Protein - min 13% on dry basis<br />\r\nAsh - min 0.75%- max 1%<br />\r\nMoisture - max 12%<br />\r\nWet Gluten - min 30% <br />\r\n100% pass thru - US Mesh 50<br />\r\n80% pass thru - US Mesh 100<br />\r\n<strong>Bread Grade<br />\r\nPackaging: 50 KG PP Bags / 25 KG PP Bags</strong></p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class="col-md-4 arrival-grid simpleCart_shelfItem">\r\n<div class="grid-arr">\r\n<div class="grid-arrival"><strong>Grade 2:</strong><br />\r\n<strong style="color: #656565;">Specifications of Indian Fine White Refined Wheat Flour</strong>\r\n<p>Protein - min 12% on dry basis<br />\r\nAsh - min 0.75%- max 1%<br />\r\nMoisture - max 14%<br />\r\nWet Gluten - min 26% <br />\r\n100% pass thru - US Mesh 50<br />\r\n80% pass thru - US Mesh 100<br />\r\n<strong>Bakery / Biscuit Grade<br />\r\nPackaging: 50 KG PP Bags / 25 KG PP Bags</strong></p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class="col-md-4 arrival-grid simpleCart_shelfItem">\r\n<div class="grid-arr">\r\n<div class="grid-arrival"><strong>Grade 3:</strong><br />\r\n<strong style="color: #656565;">Specifications of Indian Fine White Refined Wheat Flour</strong>\r\n<p>Protein - min 10% on dry basis<br />\r\nAsh - min 0.75%- max 1%<br />\r\nMoisture - max 14%<br />\r\nWet Gluten - min 24% <br />\r\n100% pass thru - US Mesh 50<br />\r\n80% pass thru - US Mesh 100<br />\r\n<strong>Noodles / Pasta Grade<br />\r\nPackaging: 50 KG PP Bags / 25 KG PP Bags</strong></p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class="clearfix">&nbsp;</div>\r\n<hr />\r\n<div class="col-md-12 arrival-grid simpleCart_shelfItem">\r\n<div class="grid-arr">\r\n<div class="grid-arrival">\r\n<h5>Durum Wheat (Hard Wheat)</h5>\r\n<strong style="color: #656565;">We have below DURUM WHEAT of Indian Origin for Sale into Turkey:</strong><br />\r\n<p>- Test Weight: 80 lbs/Bushel Min<br />\r\n-        Protein: 14% Min<br />\r\n-         Moisture: 12% max<br />\r\n-         Wet Gluten: 27% Min<br />\r\n-         Dry Gluten: 9% Max</p>\r\n</div>\r\n</div>\r\n</div>', '', 0, 0, 'Wheat and Wheat Flour', 'Wheat and Wheat Flour', 'Wheat and Wheat Flour', 1),
(115, 1, 2, 'Barley', '', '', 0.00, '', '', 0, 0, 'Barley', 'Barley', 'Barley', 1),
(116, 1, 3, 'Oats', '', '', 0.00, '', '', 0, 0, 'Oats', 'Oats', 'Oats', 1),
(117, 1, 4, 'Millets', '', '', 0.00, '', '', 0, 0, 'Millets', 'Millets', 'Millets', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products1`
--

CREATE TABLE `products1` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `alias_name` text NOT NULL,
  `size` varchar(255) NOT NULL,
  `price` float(8,2) NOT NULL,
  `description` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `new_arrival` tinyint(1) NOT NULL DEFAULT '0',
  `hot_product` tinyint(1) NOT NULL,
  `metaTitle` text NOT NULL,
  `metaDescription` text NOT NULL,
  `metaKeywords` text NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products1`
--

INSERT INTO `products1` (`id`, `catid`, `seqNo`, `product_name`, `alias_name`, `size`, `price`, `description`, `image`, `new_arrival`, `hot_product`, `metaTitle`, `metaDescription`, `metaKeywords`, `status`) VALUES
(1, 0, 0, 'Product1', '', '', 0.00, '<p>Test</p>', '', 0, 0, '', '', '', 1),
(2, 0, 0, 'Product2', '', '', 0.00, '<p>test</p>', '', 0, 0, '', '', '', 1),
(3, 1, 0, 'test3', '', '', 0.00, '<p>test</p>', '', 0, 0, '', '', '', 1),
(4, 3, 0, 'Product3', '', '', 0.00, '<p>test</p>', '', 0, 0, '', '', '', 1),
(5, 0, 0, 'Product4', '', '', 0.00, '<p>Coming Soon...</p>', '', 0, 0, '', '', '', 1),
(6, 0, 0, 'Product5', '', '', 0.00, '<p>Coming Soon...</p>', '', 0, 0, '', '', '', 1),
(7, 2, 0, 'Sub Prodct1', '', '', 0.00, '<p>Coming Soon...</p>', '', 0, 0, '', '', '', 1),
(8, 2, 0, 'Product6', '', '', 0.00, '<p>Coming soon...</p>', '', 0, 0, '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `productsbk`
--

CREATE TABLE `productsbk` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `alias_name` text NOT NULL,
  `size` varchar(255) NOT NULL,
  `price` float(8,2) NOT NULL,
  `description` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `new_arrival` tinyint(1) NOT NULL DEFAULT '0',
  `hot_product` tinyint(1) NOT NULL,
  `metaTitle` text NOT NULL,
  `metaDescription` text NOT NULL,
  `metaKeywords` text NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productsbk`
--

INSERT INTO `productsbk` (`id`, `catid`, `seqNo`, `product_name`, `alias_name`, `size`, `price`, `description`, `image`, `new_arrival`, `hot_product`, `metaTitle`, `metaDescription`, `metaKeywords`, `status`) VALUES
(13, 2, 1, 'Baby Shower - Paper Work', 'baby-shower-paper-work', '', 0.00, '', '', 0, 0, 'Baby Shower - Paper Work', 'Baby Shower - Paper Work', 'Baby Shower - Paper Work', 1),
(14, 2, 2, 'Baby Shower Unique Decor', 'baby-shower-unique-decor', '', 0.00, '', '', 0, 0, 'Baby Shower Unique Decor', 'Baby Shower Unique Decor', 'Baby Shower Unique Decor', 1),
(15, 2, 3, 'Baby Welcome', 'baby-welcome', '', 0.00, '', '', 0, 0, 'Baby Welcome', 'Baby Welcome', 'Baby Welcome', 1),
(16, 2, 4, 'Babyshower - Balloon Decor', 'babyshower-colorful-balloon-decor', '', 0.00, '', '', 0, 0, 'Babyshower - Colorful Balloon Decor', 'Babyshower - Colorful Balloon Decor', 'Babyshower - Colorful Balloon Decor', 1),
(17, 2, 5, 'Balloon Decor', 'balloon-decor', '', 0.00, '', '', 0, 0, 'Balloon Decor', 'Balloon Decor', 'Balloon Decor', 1),
(18, 2, 6, 'Candyland At Morbi', 'candyland-at-morbi', '', 0.00, '', '', 0, 0, 'Candyland At Morbi', 'Candyland At Morbi', 'Candyland At Morbi', 1),
(19, 2, 7, 'Dhvij''s Caaars', 'dhvijs-caaars', '', 0.00, '', '', 0, 0, 'Dhvijs Caaars', 'Dhvijs Caaars', 'Dhvijs Caaars', 1),
(20, 2, 8, 'Disney Cars', 'disney-cars', '', 0.00, '', '', 0, 0, 'Disney Cars', 'Disney Cars', 'Disney Cars', 1),
(21, 2, 9, 'Disney Theme', 'disney-theme', '', 0.00, '', '', 0, 0, 'Disney Theme', 'Disney Theme', 'Disney Theme', 1),
(22, 2, 10, 'Dora Balloon Decor', 'dora-balloon-decor', '', 0.00, '', '', 0, 0, 'Dora Balloon Decor', 'Dora Balloon Decor', 'Dora Balloon Decor', 1),
(23, 2, 11, 'Khushi''s Princess Friends', 'khushis-princess-friends', '', 0.00, '', '', 0, 0, 'Khushis Princess Friends', 'Khushis Princess Friends', 'Khushis Princess Friends', 1),
(24, 2, 12, 'Maanav''s Royal World', 'maanavs-royal-world', '', 0.00, '', '', 0, 0, 'Maanavs Royal World', 'Maanavs Royal World', 'Maanavs Royal World', 1),
(25, 2, 13, 'Masha & The Bear', 'masha-the-bear', '', 0.00, '', '', 0, 0, 'Masha & The Bear', 'Masha & The Bear', 'Masha & The Bear', 1),
(26, 2, 14, 'Minions Theme', 'minions-theme', '', 0.00, '', '', 0, 0, 'Minions Theme', 'Minions Theme', 'Minions Theme', 1),
(27, 2, 15, 'Monsoon Theme', 'monsoon-theme', '', 0.00, '', '', 0, 0, 'Monsoon Theme', 'Monsoon Theme', 'Monsoon Theme', 1),
(28, 2, 16, 'O7 - Monsoon', 'o7-monsoon', '', 0.00, '', '', 0, 0, 'O7 - Monsoon', 'O7 - Monsoon', 'O7 - Monsoon', 1),
(29, 2, 17, 'O7 - Twins 1st B''day', 'o7-twins-1st-bday', '', 0.00, '', '', 0, 0, 'O7 - Twins 1st Bday', 'O7 - Twins 1st Bday', 'O7 - Twins 1st Bday', 1),
(30, 2, 18, 'Old McDonald Had A Farm', 'old-mcdonald-had-a-farm', '', 0.00, '', '', 0, 0, 'Old McDonald Had A Farm', 'Old McDonald Had A Farm', 'Old McDonald Had A Farm', 1),
(31, 2, 19, 'OM''s Superhero Friends', 'oms-superhero-friends', '', 0.00, '', '', 0, 0, 'OMs Superhero Friends', 'OMs Superhero Friends', 'OMs Superhero Friends', 1),
(32, 2, 20, 'Raavi''s Baby Animals', 'raavis-baby-animals', '', 0.00, '', '', 0, 0, 'Raavis Baby Animals', 'Raavis Baby Animals', 'Raavis Baby Animals', 1),
(33, 2, 21, 'Radhika''s 3rd Birthday', 'radhikas-3rd-birthday', '', 0.00, '', '', 0, 0, 'Radhikas 3rd Birthday', 'Radhikas 3rd Birthday', 'Radhikas 3rd Birthday', 1),
(34, 2, 22, 'Superhero', 'superhero', '', 0.00, '', '', 0, 0, 'Superhero', 'Superhero', 'Superhero', 1),
(35, 2, 23, 'Tanishka''s Disney World', 'tanishkas-disney-world', '', 0.00, '', '', 0, 0, 'Tanishkas Disney World', 'Tanishkas Disney World', 'Tanishkas Disney World', 1),
(36, 2, 24, 'Vaachi''s Jungle Safari', 'vaachis-jungle-safari', '', 0.00, '', '', 0, 0, 'Vaachis Jungle Safari', 'Vaachis Jungle Safari', 'Vaachis Jungle Safari', 1),
(37, 2, 25, 'Yash''s WWE Friends', 'yashs-wwe-friends', '', 0.00, '', '', 0, 0, 'Yashs WWE Friends', 'Yashs WWE Friends', 'Yashs WWE Friends', 1),
(38, 5, 1, 'Romi''s Garba', 'romis-garba', '', 0.00, '', '', 0, 0, 'Romis Garba', 'Romis Garba', 'Romis Garba', 1),
(39, 6, 1, 'Romi''s Mandap Muhurat', 'romis-mandap-muhurat', '', 0.00, '', '', 0, 0, 'Romis Mandap Muhurat', 'Romis Mandap Muhurat', 'Romis Mandap Muhurat', 1),
(40, 7, 1, 'Devshri''s Mehndi', 'devshris-mehndi', '', 0.00, '', '', 0, 0, 'Devshris Mehndi', 'Devshris Mehndi', 'Devshris Mehndi', 1),
(41, 7, 2, 'Khyati''s Mehndi', 'khyatis-mehndi', '', 0.00, '', '', 0, 0, 'Khyatis Mehndi', 'Khyatis Mehndi', 'Khyatis Mehndi', 1),
(42, 7, 3, 'Priyanka''s Mehndi', 'priyankas-mehndi', '', 0.00, '', '', 0, 0, 'Priyankas Mehndi', 'Priyankas Mehndi', 'Priyankas Mehndi', 1),
(43, 7, 4, 'Romi''s Mehndi', 'romis-mehndi', '', 0.00, '', '', 0, 0, 'Romis Mehndi', 'Romis Mehndi', 'Romis Mehndi', 1),
(44, 4, 1, 'Divya Bhaskar Fun Activities', 'divya-bhaskar-employees-fun-activities', '', 0.00, '', '', 0, 0, 'Divya Bhaskar Employees Fun Activities', 'Divya Bhaskar Employees Fun Activities', 'Divya Bhaskar Employees Fun Activities', 1),
(45, 4, 2, 'NK Farm Event', 'nk-farm-event', '', 0.00, '', '', 0, 0, 'NK Farm Event', 'NK Farm Event', 'NK Farm Event', 1);

-- --------------------------------------------------------

--
-- Table structure for table `productsbk1`
--

CREATE TABLE `productsbk1` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `alias_name` text NOT NULL,
  `size` varchar(255) NOT NULL,
  `price` float(8,2) NOT NULL,
  `description` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `new_arrival` tinyint(1) NOT NULL DEFAULT '0',
  `hot_product` tinyint(1) NOT NULL,
  `metaTitle` text NOT NULL,
  `metaDescription` text NOT NULL,
  `metaKeywords` text NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productsbk1`
--

INSERT INTO `productsbk1` (`id`, `catid`, `seqNo`, `product_name`, `alias_name`, `size`, `price`, `description`, `image`, `new_arrival`, `hot_product`, `metaTitle`, `metaDescription`, `metaKeywords`, `status`) VALUES
(13, 2, 1, 'Baby Shower - Paper Work', 'baby-shower-paper-work', '', 0.00, '', '', 0, 0, 'Baby Shower - Paper Work', 'Baby Shower - Paper Work', 'Baby Shower - Paper Work', 1),
(14, 2, 2, 'Baby Shower Unique Decor', 'baby-shower-unique-decor', '', 0.00, '', '', 0, 0, 'Baby Shower Unique Decor', 'Baby Shower Unique Decor', 'Baby Shower Unique Decor', 1),
(15, 2, 3, 'Baby Welcome', 'baby-welcome', '', 0.00, '', '', 0, 0, 'Baby Welcome', 'Baby Welcome', 'Baby Welcome', 1),
(16, 2, 4, 'Babyshower - Balloon Decor', 'babyshower-colorful-balloon-decor', '', 0.00, '', '', 0, 0, 'Babyshower - Colorful Balloon Decor', 'Babyshower - Colorful Balloon Decor', 'Babyshower - Colorful Balloon Decor', 1),
(17, 2, 5, 'Balloon Decor', 'balloon-decor', '', 0.00, '', '', 0, 0, 'Balloon Decor', 'Balloon Decor', 'Balloon Decor', 1),
(18, 2, 6, 'Candyland At Morbi', 'candyland-at-morbi', '', 0.00, '', '', 0, 0, 'Candyland At Morbi', 'Candyland At Morbi', 'Candyland At Morbi', 1),
(19, 2, 7, 'Dhvij''s Caaars', 'dhvijs-caaars', '', 0.00, '', '', 0, 0, 'Dhvijs Caaars', 'Dhvijs Caaars', 'Dhvijs Caaars', 1),
(20, 2, 8, 'Disney Cars', 'disney-cars', '', 0.00, '', '', 0, 0, 'Disney Cars', 'Disney Cars', 'Disney Cars', 1),
(21, 2, 9, 'Disney Theme', 'disney-theme', '', 0.00, '', '', 0, 0, 'Disney Theme', 'Disney Theme', 'Disney Theme', 1),
(22, 2, 10, 'Dora Balloon Decor', 'dora-balloon-decor', '', 0.00, '', '', 0, 0, 'Dora Balloon Decor', 'Dora Balloon Decor', 'Dora Balloon Decor', 1),
(23, 2, 11, 'Khushi''s Princess Friends', 'khushis-princess-friends', '', 0.00, '', '', 0, 0, 'Khushis Princess Friends', 'Khushis Princess Friends', 'Khushis Princess Friends', 1),
(24, 2, 12, 'Maanav''s Royal World', 'maanavs-royal-world', '', 0.00, '', '', 0, 0, 'Maanavs Royal World', 'Maanavs Royal World', 'Maanavs Royal World', 1),
(25, 2, 13, 'Masha & The Bear', 'masha-the-bear', '', 0.00, '', '', 0, 0, 'Masha & The Bear', 'Masha & The Bear', 'Masha & The Bear', 1),
(26, 2, 14, 'Minions Theme', 'minions-theme', '', 0.00, '', '', 0, 0, 'Minions Theme', 'Minions Theme', 'Minions Theme', 1),
(27, 2, 15, 'Monsoon Theme', 'monsoon-theme', '', 0.00, '', '', 0, 0, 'Monsoon Theme', 'Monsoon Theme', 'Monsoon Theme', 1),
(28, 2, 16, 'O7 - Monsoon', 'o7-monsoon', '', 0.00, '', '', 0, 0, 'O7 - Monsoon', 'O7 - Monsoon', 'O7 - Monsoon', 1),
(29, 2, 17, 'O7 - Twins 1st B''day', 'o7-twins-1st-bday', '', 0.00, '', '', 0, 0, 'O7 - Twins 1st Bday', 'O7 - Twins 1st Bday', 'O7 - Twins 1st Bday', 1),
(30, 2, 18, 'Old McDonald Had A Farm', 'old-mcdonald-had-a-farm', '', 0.00, '', '', 0, 0, 'Old McDonald Had A Farm', 'Old McDonald Had A Farm', 'Old McDonald Had A Farm', 1),
(31, 2, 19, 'OM''s Superhero Friends', 'oms-superhero-friends', '', 0.00, '', '', 0, 0, 'OMs Superhero Friends', 'OMs Superhero Friends', 'OMs Superhero Friends', 1),
(32, 2, 20, 'Raavi''s Baby Animals', 'raavis-baby-animals', '', 0.00, '', '', 0, 0, 'Raavis Baby Animals', 'Raavis Baby Animals', 'Raavis Baby Animals', 1),
(33, 2, 21, 'Radhika''s 3rd Birthday', 'radhikas-3rd-birthday', '', 0.00, '', '', 0, 0, 'Radhikas 3rd Birthday', 'Radhikas 3rd Birthday', 'Radhikas 3rd Birthday', 1),
(34, 2, 22, 'Superhero', 'superhero', '', 0.00, '', '', 0, 0, 'Superhero', 'Superhero', 'Superhero', 1),
(35, 2, 23, 'Tanishka''s Disney World', 'tanishkas-disney-world', '', 0.00, '', '', 0, 0, 'Tanishkas Disney World', 'Tanishkas Disney World', 'Tanishkas Disney World', 1),
(36, 2, 24, 'Vaachi''s Jungle Safari', 'vaachis-jungle-safari', '', 0.00, '', '', 0, 0, 'Vaachis Jungle Safari', 'Vaachis Jungle Safari', 'Vaachis Jungle Safari', 1),
(37, 2, 25, 'Yash''s WWE Friends', 'yashs-wwe-friends', '', 0.00, '', '', 0, 0, 'Yashs WWE Friends', 'Yashs WWE Friends', 'Yashs WWE Friends', 1),
(38, 5, 1, 'Romi''s Garba', 'romis-garba', '', 0.00, '', '', 0, 0, 'Romis Garba', 'Romis Garba', 'Romis Garba', 1),
(39, 6, 1, 'Romi''s Mandap Muhurat', 'romis-mandap-muhurat', '', 0.00, '', '', 0, 0, 'Romis Mandap Muhurat', 'Romis Mandap Muhurat', 'Romis Mandap Muhurat', 1),
(40, 7, 1, 'Devshri''s Mehndi', 'devshris-mehndi', '', 0.00, '', '', 0, 0, 'Devshris Mehndi', 'Devshris Mehndi', 'Devshris Mehndi', 1),
(41, 7, 2, 'Khyati''s Mehndi', 'khyatis-mehndi', '', 0.00, '', '', 0, 0, 'Khyatis Mehndi', 'Khyatis Mehndi', 'Khyatis Mehndi', 1),
(42, 7, 3, 'Priyanka''s Mehndi', 'priyankas-mehndi', '', 0.00, '', '', 0, 0, 'Priyankas Mehndi', 'Priyankas Mehndi', 'Priyankas Mehndi', 1),
(43, 7, 4, 'Romi''s Mehndi', 'romis-mehndi', '', 0.00, '', '', 0, 0, 'Romis Mehndi', 'Romis Mehndi', 'Romis Mehndi', 1),
(44, 4, 1, 'Divya Bhaskar Fun Activities', 'divya-bhaskar-employees-fun-activities', '', 0.00, '', '', 0, 0, 'Divya Bhaskar Employees Fun Activities', 'Divya Bhaskar Employees Fun Activities', 'Divya Bhaskar Employees Fun Activities', 1),
(45, 4, 2, 'NK Farm Event', 'nk-farm-event', '', 0.00, '', '', 0, 0, 'NK Farm Event', 'NK Farm Event', 'NK Farm Event', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_img`
--

CREATE TABLE `product_img` (
  `img_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `img_sequence` int(11) NOT NULL,
  `img_title` text NOT NULL,
  `price` float(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_img`
--

INSERT INTO `product_img` (`img_id`, `product_id`, `name`, `img_sequence`, `img_title`, `price`) VALUES
(744, 58, 'twfxtth0SDC16584JPG.jpg', 0, '', 0.00),
(745, 58, 'n4abpmjbSDC16588JPG.jpg', 0, '', 0.00),
(746, 58, '8rdzhb25SDC16593JPG.jpg', 0, '', 0.00),
(747, 58, 'dyaizpmjSDC16595JPG.jpg', 0, '', 0.00),
(748, 58, '2meq7yrvSDC16604JPG.jpg', 0, '', 0.00),
(749, 58, 'nv8uwihqSDC16605JPG.jpg', 0, '', 0.00),
(750, 58, '7zzct4ccSDC16607JPG.jpg', 0, '', 0.00),
(751, 58, 'vwzm8x5rSDC16608JPG.jpg', 0, '', 0.00),
(752, 58, '4t34us80SDC16610JPG.jpg', 0, '', 0.00),
(753, 58, 'o4fejxx5SDC16611JPG.jpg', 0, '', 0.00),
(754, 58, 'ufvadxddSDC16617JPG.jpg', 0, '', 0.00),
(755, 58, 'j8ssezsuSDC16618JPG.jpg', 0, '', 0.00),
(756, 58, '5mq3h4kxSDC16630JPG.jpg', 0, '', 0.00),
(757, 58, 'uifmrwshSDC16631JPG.jpg', 0, '', 0.00),
(758, 58, 'o3wg4syaSDC16632JPG.jpg', 0, '', 0.00),
(759, 58, '36zeuhb5SDC16639JPG.jpg', 0, '', 0.00),
(760, 58, '0ped5siaSDC16652JPG.jpg', 0, '', 0.00),
(761, 58, '8qxz6qaySDC16661JPG.jpg', 0, '', 0.00),
(762, 58, 't87p5nvtSDC16666JPG.jpg', 0, '', 0.00),
(763, 58, '80hox0tiSDC16667JPG.jpg', 0, '', 0.00),
(764, 59, 'doq5zj4n1JPG.jpg', 0, '', 0.00),
(765, 59, 'p8a78fe8SDC14710JPG.jpg', 0, '', 0.00),
(766, 59, 'ynm7fciySDC14712JPG.jpg', 0, '', 0.00),
(767, 59, 'e2ztjgwsSDC14721JPG.jpg', 0, '', 0.00),
(768, 59, 'csw2n776SDC14724JPG.jpg', 0, '', 0.00),
(769, 59, 'd5rboo7eSDC14728JPG.jpg', 0, '', 0.00),
(770, 59, '7bqm0f8oSDC14735JPG.jpg', 0, '', 0.00),
(771, 59, 'svn8qrfqSDC14737JPG.jpg', 0, '', 0.00),
(772, 59, '2szvpa3pSDC14744JPG.jpg', 0, '', 0.00),
(773, 59, 'irymvok5SDC14752JPG.jpg', 0, '', 0.00),
(774, 59, '5who8ixdSDC14755JPG.jpg', 0, '', 0.00),
(775, 59, '5yqc4abbSDC14757JPG.jpg', 0, '', 0.00),
(776, 59, '2b6bh6eqSDC14759JPG.jpg', 0, '', 0.00),
(777, 59, 'u5fyfzjtSDC14770JPG.jpg', 0, '', 0.00),
(778, 59, '242ep0kwSDC14776JPG.jpg', 0, '', 0.00),
(779, 59, 'g4k57givSDC14780JPG.jpg', 0, '', 0.00),
(780, 59, 'pt6u5czcSDC14784JPG.jpg', 0, '', 0.00),
(781, 59, 'bogtjj0zSDC14788JPG.jpg', 0, '', 0.00),
(782, 59, 'xjr5efzfSDC14789JPG.jpg', 0, '', 0.00),
(783, 59, 'ho8ixdacSDC14795JPG.jpg', 0, '', 0.00),
(784, 60, '7h0cewx6IMG_8317JPG.jpg', 0, '', 0.00),
(785, 60, 'fsut2i5vIMG_8329JPG.jpg', 0, '', 0.00),
(786, 60, 'sikg6whgIMG_8356JPG.jpg', 0, '', 0.00),
(787, 60, 'n567fbbeIMG_8360JPG.jpg', 0, '', 0.00),
(788, 60, 'tc8xxrauIMG_8362JPG.jpg', 0, '', 0.00),
(789, 60, 'r2xhft58IMG_8370JPG.jpg', 0, '', 0.00),
(790, 60, 'ar7xyyubIMG_8401JPG.jpg', 0, '', 0.00),
(791, 60, 'ppmdez5cIMG_8405JPG.jpg', 0, '', 0.00),
(792, 60, 'axnz4satIMG_8418JPG.jpg', 0, '', 0.00),
(793, 60, 'ztjoh845IMG_8424JPG.jpg', 0, '', 0.00),
(794, 60, '0dzbmfgkIMG_8428JPG.jpg', 0, '', 0.00),
(795, 60, 'qjt242epIMG_8448JPG.jpg', 0, '', 0.00),
(796, 60, 'ycnqhrp5IMG_8452JPG.jpg', 0, '', 0.00),
(797, 60, '4xgt0t7bIMG_8470JPG.jpg', 0, '', 0.00),
(798, 60, 'j0h20i3cIMG_8479JPG.jpg', 0, '', 0.00),
(799, 60, 'yuscdzh3IMG_8497JPG.jpg', 0, '', 0.00),
(800, 60, 'q2h8qno7IMG_8519JPG.jpg', 0, '', 0.00),
(801, 60, 'h63svgg6IMG_8524JPG.jpg', 0, '', 0.00),
(802, 60, 'hkeum8a3IMG_8553JPG.jpg', 0, '', 0.00),
(803, 60, 'py86e7ehIMG_8557JPG.jpg', 0, '', 0.00),
(804, 60, 'e2pua3syIMG_8450JPG.jpg', 0, '', 0.00),
(805, 60, 'j8vtf6g8IMG_8454JPG.jpg', 0, '', 0.00),
(806, 60, 'vmjegpdgIMG_8519JPG.jpg', 0, '', 0.00),
(807, 60, 'nauy2eeoIMG_8608JPG.jpg', 0, '', 0.00),
(808, 60, 'f2vjfopiIMG_8622JPG.jpg', 0, '', 0.00),
(809, 60, 'hjy2ezytIMG_8589JPG.jpg', 0, '', 0.00),
(810, 60, 'txd24y8hIMG_8418JPG.jpg', 0, '', 0.00),
(811, 60, 'dgmxpctqIMG_8420JPG.jpg', 0, '', 0.00),
(812, 60, '35okrt8kIMG_8479JPG.jpg', 0, '', 0.00),
(813, 60, 'scoubpkcIMG_8524JPG.jpg', 0, '', 0.00),
(814, 60, '0z8aqimpIMG_8497JPG.jpg', 0, '', 0.00),
(815, 60, 'xnz4satgIMG_8594JPG.jpg', 0, '', 0.00),
(816, 60, 'wanybbb3IMG_8775JPG.jpg', 0, '', 0.00),
(817, 61, '0ga5uk8dIMG_7080JPG.jpg', 0, '', 0.00),
(818, 61, 'gsmz02rpIMG_7081JPG.jpg', 0, '', 0.00),
(819, 61, 'hdz656cvIMG_7085JPG.jpg', 0, '', 0.00),
(820, 61, 'ud8m6m78IMG_7087JPG.jpg', 0, '', 0.00),
(821, 61, 'kzg6q3k3IMG_7088JPG.jpg', 0, '', 0.00),
(822, 61, '5n6siotzIMG_7090JPG.jpg', 0, '', 0.00),
(823, 61, 'sig7jasoIMG_7093JPG.jpg', 0, '', 0.00),
(824, 61, '8eop4ifmIMG_7094JPG.jpg', 0, '', 0.00),
(825, 61, 'a7g0u8egIMG_7110JPG.jpg', 0, '', 0.00),
(826, 61, '5e5nhqs0IMG_7117JPG.jpg', 0, '', 0.00),
(827, 61, '4eyd2wdsIMG_7118JPG.jpg', 0, '', 0.00),
(828, 61, 'rm7xaw4oIMG_7119JPG.jpg', 0, '', 0.00),
(829, 61, 'y4nkpvm4IMG_7150JPG.jpg', 0, '', 0.00),
(830, 61, '7ywbswoxIMG_7153JPG.jpg', 0, '', 0.00),
(831, 61, 'c3j55iwgIMG_7155JPG.jpg', 0, '', 0.00),
(832, 61, 'qfqc6fi7IMG_7156JPG.jpg', 0, '', 0.00),
(833, 61, 'ohfn63oiIMG_7170JPG.jpg', 0, '', 0.00),
(834, 61, 'jusgc32bIMG_7173JPG.jpg', 0, '', 0.00),
(835, 61, 't76mqwvoIMG_7176JPG.jpg', 0, '', 0.00),
(836, 61, 'dgbzfyqxIMG_7177JPG.jpg', 0, '', 0.00),
(837, 62, 'r0gjzo6d2JPG.jpg', 0, '', 0.00),
(838, 62, 'ocgnrkzc3_1JPG.jpg', 0, '', 0.00),
(839, 62, 'jdr6iaxc4_1JPG.jpg', 0, '', 0.00),
(840, 62, 'x2n0mrpy4_2JPG.jpg', 0, '', 0.00),
(841, 62, 'mojy55i4DSC_0003JPG.jpg', 0, '', 0.00),
(842, 62, 'nbdtbudcDSC_0008JPG.jpg', 0, '', 0.00),
(843, 62, 'pmjbq688DSC_0030JPG.jpg', 0, '', 0.00),
(844, 62, 'bus46887DSC_0048JPG.jpg', 0, '', 0.00),
(845, 62, 'awmqkqtqDSC_0062JPG.jpg', 0, '', 0.00),
(846, 62, 'us5sjhpoDSC_0066JPG.jpg', 0, '', 0.00),
(847, 62, 'ep0kwb5fDSC_0067JPG.jpg', 0, '', 0.00),
(848, 62, '8sep7aj0DSC_0070JPG.jpg', 0, '', 0.00),
(849, 62, 'exqvvk4tDSC_0071JPG.jpg', 0, '', 0.00),
(850, 62, 'jabzc77tDSC_0072JPG.jpg', 0, '', 0.00),
(851, 63, 'jptoi0eiIMG_1255JPG.jpg', 0, '', 0.00),
(852, 63, 'fbmxspn3IMG_1257JPG.jpg', 0, '', 0.00),
(853, 63, '6yitmvd7IMG_1328JPG.jpg', 0, '', 0.00),
(854, 63, '6scx6au6IMG_1338JPG.jpg', 0, '', 0.00),
(855, 63, 'vtne6gnxIMG_1473JPG.jpg', 0, '', 0.00),
(856, 63, '2caxtmktIMG_1697JPG.jpg', 0, '', 0.00),
(857, 63, 'yh32z7uiIMG_1707JPG.jpg', 0, '', 0.00),
(858, 63, 'bibuy8hqIMG_1708JPG.jpg', 0, '', 0.00),
(859, 63, 'v3yv7jazIMG_1710JPG.jpg', 0, '', 0.00),
(860, 63, 'ptv4hfwwIMG_1732JPG.jpg', 0, '', 0.00),
(861, 63, 'gcpyuvbhIMG_1733JPG.jpg', 0, '', 0.00),
(862, 63, 'dajw8mh5IMG_1846JPG.jpg', 0, '', 0.00),
(863, 63, 'fejj8ev0IMG_1853JPG.jpg', 0, '', 0.00),
(864, 63, 'h7wje8inIMG_1854JPG.jpg', 0, '', 0.00),
(865, 63, '0ybqpkdwIMG_1916JPG.jpg', 0, '', 0.00),
(866, 63, 'avmn5yukIMG_1919JPG.jpg', 0, '', 0.00),
(867, 63, 'w2j3zbzqIMG_1940JPG.jpg', 0, '', 0.00),
(868, 63, 'tuwha40oIMG_1950JPG.jpg', 0, '', 0.00),
(869, 63, 'tfzg3ykgIMG_1981JPG.jpg', 0, '', 0.00),
(870, 63, '5m2o0p6fIMG_1985JPG.jpg', 0, '', 0.00),
(871, 63, 'b7u4bi6vIMG_2018JPG.jpg', 0, '', 0.00),
(872, 63, 'dn0m5erxIMG_2437JPG.jpg', 0, '', 0.00),
(873, 63, 'bwyeu3mdIMG_2463JPG.jpg', 0, '', 0.00),
(874, 63, '6xbcbkzoIMG_2532JPG.jpg', 0, '', 0.00),
(875, 63, 'wgcefabpIMG_2512JPG.jpg', 0, '', 0.00),
(876, 63, 'j0e4xxunIMG_2510JPG.jpg', 0, '', 0.00),
(877, 63, '4r4he303IMG_2600JPG.jpg', 0, '', 0.00),
(878, 63, 'ajbxezhvIMG_2598JPG.jpg', 0, '', 0.00),
(879, 64, 'sfppf2h220150822_162443jpg.jpg', 0, '', 0.00),
(880, 64, 'bvh2r64620150822_164249jpg.jpg', 0, '', 0.00),
(881, 64, 'huqj7swj20150822_165716jpg.jpg', 0, '', 0.00),
(882, 64, 'ifmrwshu20150822_174725jpg.jpg', 0, '', 0.00),
(883, 64, 'a7ry3mha20150921_104731jpg.jpg', 0, '', 0.00),
(884, 64, 'wfmuj4x020150921_105447jpg.jpg', 0, '', 0.00),
(885, 64, 'up753shq20150921_105917jpg.jpg', 0, '', 0.00),
(886, 64, 'vzfyicd620150921_110432___Copyjpg.jpg', 0, '', 0.00),
(887, 64, 'jgz4w4rd20150921_111343jpg.jpg', 0, '', 0.00),
(888, 64, 'j3fhwrbv20150921_111356jpg.jpg', 0, '', 0.00),
(889, 64, 'fct4jwjk20150921_111418jpg.jpg', 0, '', 0.00),
(890, 64, 'ae55f5xz20150921_111428jpg.jpg', 0, '', 0.00),
(891, 64, 'v5wvdzz820150921_112225jpg.jpg', 0, '', 0.00),
(892, 64, '8ku6tcfc20150921_112244jpg.jpg', 0, '', 0.00),
(893, 64, 'nmz4ek2y20150921_112328jpg.jpg', 0, '', 0.00),
(894, 64, 'f36eicr320150921_112504jpg.jpg', 0, '', 0.00),
(895, 64, 'yp3t3bg8IMG_4214JPG.jpg', 0, '', 0.00),
(896, 64, '4pe2pnpnIMG_4215JPG.jpg', 0, '', 0.00),
(897, 64, 'a2pr0g5bIMG_4224JPG.jpg', 0, '', 0.00),
(898, 64, 'tg7qrtwnIMG_4226JPG.jpg', 0, '', 0.00),
(899, 64, 'tpmorybxIMG_4243JPG.jpg', 0, '', 0.00),
(900, 64, 'j6aducchIMG_4245JPG.jpg', 0, '', 0.00),
(901, 64, '5ih42arwIMG_4293JPG.jpg', 0, '', 0.00),
(902, 64, 'n4apfd0mIMG_4294JPG.jpg', 0, '', 0.00),
(903, 64, 'kuakukj4IMG_4299JPG.jpg', 0, '', 0.00),
(904, 64, '8fh74azyIMG_4306JPG.jpg', 0, '', 0.00),
(905, 64, 'vbhkpsumIMG_4313JPG.jpg', 0, '', 0.00),
(906, 64, 'zvvef65hIMG_4321JPG.jpg', 0, '', 0.00),
(907, 64, 'qzgurt7yIMG_4377JPG.jpg', 0, '', 0.00),
(908, 64, 'phmz0o2wIMG_4385JPG.jpg', 0, '', 0.00),
(909, 64, 'm70f50dmIMG_4402JPG.jpg', 0, '', 0.00),
(910, 64, 'g6fj0h20IMG_4420JPG.jpg', 0, '', 0.00),
(911, 64, 'n5k4tamvIMG_4449JPG.jpg', 0, '', 0.00),
(912, 64, 'qs8wxhqsIMG_4591JPG.jpg', 0, '', 0.00),
(913, 64, 'akjzyic5IMG_4592JPG.jpg', 0, '', 0.00),
(914, 64, '85jfvpozIMG_4600JPG.jpg', 0, '', 0.00),
(915, 64, 'out5vy7pIMG_4609JPG.jpg', 0, '', 0.00),
(916, 64, '00fnk3z3IMG_4625JPG.jpg', 0, '', 0.00),
(917, 64, 'cboyrxp0IMG_20151015_WA0036jpg.jpg', 0, '', 0.00),
(918, 64, 'gwsq2auvIMG_4666JPG.jpg', 0, '', 0.00),
(919, 64, 'jjcqodrgIMG_4664JPG.jpg', 0, '', 0.00),
(920, 64, 'k68jxnteIMG_4668JPG.jpg', 0, '', 0.00),
(921, 65, 'j58upsuzIMG_5638JPG.jpg', 0, '', 0.00),
(922, 65, 'gudnby3iIMG_5639JPG.jpg', 0, '', 0.00),
(923, 65, '24az50ypIMG_5641JPG.jpg', 0, '', 0.00),
(924, 65, 'knunvf5tIMG_5642JPG.jpg', 0, '', 0.00),
(925, 65, '67igiaxqIMG_5643JPG.jpg', 0, '', 0.00),
(926, 65, '5ybfqcztIMG_5644JPG.jpg', 0, '', 0.00),
(927, 65, 'sq64srarIMG_5645JPG.jpg', 0, '', 0.00),
(928, 65, 'ikheixg0IMG_5646JPG.jpg', 0, '', 0.00),
(929, 66, '3oin3ge01JPG.jpg', 0, '', 0.00),
(930, 66, 'mfrbeiup2JPG.jpg', 0, '', 0.00),
(931, 66, 'pt2t44cx3JPG.jpg', 0, '', 0.00),
(932, 66, 'urj3m6ih4JPG.jpg', 0, '', 0.00),
(933, 66, 'rktrdwc35_1JPG.jpg', 0, '', 0.00),
(934, 66, 'gef6xwnj5_2JPG.jpg', 0, '', 0.00),
(935, 66, 'u7g4sdyp6_1JPG.jpg', 0, '', 0.00),
(936, 66, 'ztjoh8456_2JPG.jpg', 0, '', 0.00),
(937, 66, 'niaf608g6_3JPG.jpg', 0, '', 0.00),
(938, 66, 'ijrunr3dIMG_5227JPG.jpg', 0, '', 0.00),
(939, 66, '724a6rhyIMG_5229JPG.jpg', 0, '', 0.00),
(940, 66, 'qf5i3fbsIMG_5235JPG.jpg', 0, '', 0.00),
(941, 66, 'c77tmvyiIMG_5239JPG.jpg', 0, '', 0.00),
(942, 66, 's80equgmIMG_5241JPG.jpg', 0, '', 0.00),
(943, 67, '5rwyvq3zIMG_5276JPG.jpg', 0, '', 0.00),
(944, 67, 'emvybt2eIMG_5277JPG.jpg', 0, '', 0.00),
(945, 67, 'x0swcsmwIMG_5278JPG.jpg', 0, '', 0.00),
(946, 67, '2zedjvzjIMG_5279JPG.jpg', 0, '', 0.00),
(947, 67, '2pak5ishIMG_5280JPG.jpg', 0, '', 0.00),
(948, 67, 'c0xkexrgIMG_5281JPG.jpg', 0, '', 0.00),
(949, 67, 'r0g5bwp2IMG_5282JPG.jpg', 0, '', 0.00),
(950, 67, 'mxb8dgfgWP_20151231_001jpg.jpg', 0, '', 0.00),
(951, 67, 'nryq4b7uWP_20151231_002jpg.jpg', 0, '', 0.00),
(952, 67, '8ni2m4kuWP_20151231_003jpg.jpg', 0, '', 0.00),
(953, 67, 'k7vcboyrWP_20151231_004jpg.jpg', 0, '', 0.00),
(954, 67, 'x8icgrmiWP_20151231_005jpg.jpg', 0, '', 0.00),
(955, 67, 'yxntmszeWP_20151231_006jpg.jpg', 0, '', 0.00),
(956, 67, 'o4nkb6unWP_20151231_007jpg.jpg', 0, '', 0.00),
(957, 68, 'zd04h4yoIMG_5266JPG.jpg', 0, '', 0.00),
(958, 68, 'gby7daxfIMG_5267JPG.jpg', 0, '', 0.00),
(959, 68, '7jvp6xhcIMG_5268JPG.jpg', 0, '', 0.00),
(960, 68, '75aaiz3bIMG_5269JPG.jpg', 0, '', 0.00),
(961, 68, 'r2uic8xjIMG_5270JPG.jpg', 0, '', 0.00),
(962, 68, 'tk23uwfqIMG_5271JPG.jpg', 0, '', 0.00),
(963, 68, 'dbd7mw25IMG_5272JPG.jpg', 0, '', 0.00),
(964, 68, '6agpa7ocIMG_5273JPG.jpg', 0, '', 0.00),
(965, 68, 'nsmw64viIMG_5274JPG.jpg', 0, '', 0.00),
(966, 68, 'xhi6ym6eIMG_5275JPG.jpg', 0, '', 0.00),
(967, 69, '5k47yeddIMG_1176JPG.jpg', 0, '', 0.00),
(968, 69, 'qo6rb2dyIMG_1188___CopyJPG.jpg', 0, '', 0.00),
(969, 69, '2s77m70fIMG_1189JPG.jpg', 0, '', 0.00),
(970, 69, 'hsfp34tyIMG_1198JPG.jpg', 0, '', 0.00),
(971, 70, 'je2ebqh61_2jpg.jpg', 0, '', 0.00),
(972, 70, 'vt03yyx21JPG.jpg', 0, '', 0.00),
(973, 70, '46nxyh7f2JPG.jpg', 0, '', 0.00),
(974, 70, '5asu40si3_2JPG.jpg', 0, '', 0.00),
(975, 70, '7hcoc2ja3_3JPG.jpg', 0, '', 0.00),
(976, 70, 'ufopwxyk3_4JPG.jpg', 0, '', 0.00),
(977, 70, '6vc4kna03JPG.jpg', 0, '', 0.00),
(978, 70, 'feo6kt03IMG_4482JPG.jpg', 0, '', 0.00),
(979, 70, 'gf0ybwswIMG_4483JPG.jpg', 0, '', 0.00),
(980, 70, 'y4xix8pxIMG_4484JPG.jpg', 0, '', 0.00),
(981, 70, '7gqpvpvzIMG_4487JPG.jpg', 0, '', 0.00),
(982, 70, '40oku60xIMG_4490JPG.jpg', 0, '', 0.00),
(983, 70, 'dwu0kmdwIMG_4507JPG.jpg', 0, '', 0.00),
(984, 70, 'puheqwmtIMG_4513JPG.jpg', 0, '', 0.00),
(985, 70, 'esajc5zgIMG_4515JPG.jpg', 0, '', 0.00),
(986, 70, '2zz82m74IMG_20150917_WA0060jpg.jpg', 0, '', 0.00),
(987, 70, '3tz68cjsIMG_20150917_WA0062jpg.jpg', 0, '', 0.00),
(988, 71, 'ypizzc7t1_1JPG.jpg', 0, '', 0.00),
(989, 71, '3kens7sp1_2JPG.jpg', 0, '', 0.00),
(990, 71, 'xnwdb5m52_1JPG.jpg', 0, '', 0.00),
(991, 71, '0f50dmmt3JPG.jpg', 0, '', 0.00),
(992, 71, 'j6vn2t0dIMG_0035JPG.jpg', 0, '', 0.00),
(993, 71, 'u05ba68xIMG_0040JPG.jpg', 0, '', 0.00),
(994, 71, 'qhkmur05IMG_0042JPG.jpg', 0, '', 0.00),
(995, 71, 'a5nysdvxIMG_0046JPG.jpg', 0, '', 0.00),
(996, 71, 'wtc8cnjrIMG_0047JPG.jpg', 0, '', 0.00),
(997, 71, 'cein42paIMG_0050JPG.jpg', 0, '', 0.00),
(998, 71, 'rethfb7uIMG_0051JPG.jpg', 0, '', 0.00),
(999, 71, '7rezyfknIMG_0053JPG.jpg', 0, '', 0.00),
(1000, 71, 'hnftub70IMG_0055JPG.jpg', 0, '', 0.00),
(1001, 71, 'uzug6i6dIMG_0056JPG.jpg', 0, '', 0.00),
(1002, 71, 'ryq4b7uwIMG_0066JPG.jpg', 0, '', 0.00),
(1003, 71, 'qwhdhu0aIMG_0070JPG.jpg', 0, '', 0.00),
(1004, 71, 'vs0mufhkIMG_0071JPG.jpg', 0, '', 0.00),
(1005, 71, 'wcdmm7nwIMG_0089JPG.jpg', 0, '', 0.00),
(1006, 72, 'o5u2kh67SDC15871JPG.jpg', 0, '', 0.00),
(1007, 72, 'kg6pvznoSDC15876JPG.jpg', 0, '', 0.00),
(1008, 72, '3oc88w0nSDC15879JPG.jpg', 0, '', 0.00),
(1009, 72, 'r827miyoSDC15880JPG.jpg', 0, '', 0.00),
(1010, 72, '4bqwhk3bSDC15881JPG.jpg', 0, '', 0.00),
(1011, 72, 'knyhtccbSDC15881JPG.jpg', 0, '', 0.00),
(1012, 72, '7bjiqxccSDC15882JPG.jpg', 0, '', 0.00),
(1013, 72, 'q0rb5qs8SDC15887JPG.jpg', 0, '', 0.00),
(1014, 72, 'r8gwezasSDC15888JPG.jpg', 0, '', 0.00),
(1015, 72, 'adcaqnucSDC15889JPG.jpg', 0, '', 0.00),
(1016, 72, 'v0ctbfnkSDC15890JPG.jpg', 0, '', 0.00),
(1017, 73, 'ocdv8gt0PP2_5894JPG.jpg', 0, '', 0.00),
(1018, 73, 'tsat2twjPP2_5896JPG.jpg', 0, '', 0.00),
(1019, 73, 'z8actu6yPP2_5903JPG.jpg', 0, '', 0.00),
(1020, 73, 'asdoq5zjPP2_5916JPG.jpg', 0, '', 0.00),
(1021, 73, '738b8x5dPP2_5917JPG.jpg', 0, '', 0.00),
(1022, 73, '3xrywnchPP2_5926JPG.jpg', 0, '', 0.00),
(1023, 73, '7uwq26h2PP2_5932JPG.jpg', 0, '', 0.00),
(1024, 73, 'bukjq8ufPP2_5933JPG.jpg', 0, '', 0.00),
(1025, 73, '8gqvz0dwPP2_5938JPG.jpg', 0, '', 0.00),
(1026, 73, 'yo4fejxxPP2_5964JPG.jpg', 0, '', 0.00),
(1027, 73, 'jt6retv4PP2_5967JPG.jpg', 0, '', 0.00),
(1028, 73, 'v08u7ufvPP2_5969JPG.jpg', 0, '', 0.00),
(1029, 73, '6a54pm2uPP2_5970JPG.jpg', 0, '', 0.00),
(1030, 73, 'io0kq7uxPP2_5993JPG.jpg', 0, '', 0.00),
(1031, 73, 'wnufopwxPP2_5997JPG.jpg', 0, '', 0.00),
(1032, 73, 'to4qctb0PP2_6014JPG.jpg', 0, '', 0.00),
(1033, 73, 'fdj24uejPP2_6023JPG.jpg', 0, '', 0.00),
(1034, 73, 'qtxgtn3gPP2_6045JPG.jpg', 0, '', 0.00),
(1035, 73, '6qhbu6uxPP2_6081JPG.jpg', 0, '', 0.00),
(1036, 74, 'asomzi4cIMG_3796JPG.jpg', 0, '', 0.00),
(1037, 74, '0dzwvoyaIMG_3803JPG.jpg', 0, '', 0.00),
(1038, 74, 'uxxonigiIMG_3806JPG.jpg', 0, '', 0.00),
(1039, 74, 'zstw0mq3IMG_3813JPG.jpg', 0, '', 0.00),
(1040, 74, 't3bg8aeyIMG_3811JPG.jpg', 0, '', 0.00),
(1041, 74, '6o274u3mIMG_3815JPG.jpg', 0, '', 0.00),
(1042, 74, 'rjhikgs7IMG_3818JPG.jpg', 0, '', 0.00),
(1043, 74, 'otkdtitiIMG_3839JPG.jpg', 0, '', 0.00),
(1044, 74, 'mispccaxIMG_3841JPG.jpg', 0, '', 0.00),
(1045, 74, 'uvzibcp2IMG_3845JPG.jpg', 0, '', 0.00),
(1046, 74, 'dp0etzohIMG_3877JPG.jpg', 0, '', 0.00),
(1047, 75, 'dxoijdxaIMG_3796JPG.jpg', 0, '', 0.00),
(1048, 75, 'iwtn6m0nIMG_3803JPG.jpg', 0, '', 0.00),
(1049, 75, 'k6jh7zw6IMG_3804JPG.jpg', 0, '', 0.00),
(1050, 75, 'pk2ymar0IMG_3811JPG.jpg', 0, '', 0.00),
(1051, 75, 'y6ybmunhIMG_3813JPG.jpg', 0, '', 0.00),
(1052, 75, '54zkc7jdIMG_3815JPG.jpg', 0, '', 0.00),
(1053, 75, 'zeyu3i8tIMG_3818JPG.jpg', 0, '', 0.00),
(1054, 75, 'oofzjfsxIMG_3839JPG.jpg', 0, '', 0.00),
(1055, 75, '68cjs80sIMG_3841JPG.jpg', 0, '', 0.00),
(1056, 75, '8vbhsb8vIMG_3845JPG.jpg', 0, '', 0.00),
(1057, 75, 'bvokrfitIMG_3877JPG.jpg', 0, '', 0.00),
(1058, 75, 'pghksjdrIMG_3884JPG.jpg', 0, '', 0.00),
(1059, 75, '3cdhrarqIMG_3889JPG.jpg', 0, '', 0.00),
(1060, 75, 'j5gg5t8sIMG_3897JPG.jpg', 0, '', 0.00),
(1061, 75, 'dep72xkkIMG_3922JPG.jpg', 0, '', 0.00),
(1062, 75, 'v2ymogtxIMG_3924JPG.jpg', 0, '', 0.00),
(1063, 75, 'kdfzngt5IMG_3927JPG.jpg', 0, '', 0.00),
(1064, 75, '2vrsi8wnIMG_4028JPG.jpg', 0, '', 0.00),
(1065, 75, 'k5uxcujiIMG_4037JPG.jpg', 0, '', 0.00),
(1066, 75, 'qytaz82zIMG_4247JPG.jpg', 0, '', 0.00),
(1067, 75, 'xjosk3afIMG_4250JPG.jpg', 0, '', 0.00),
(1068, 75, 'pyoea752IMG_4268JPG.jpg', 0, '', 0.00),
(1069, 75, '2ftvishnIMG_4251JPG.jpg', 0, '', 0.00),
(1070, 75, '3xuqerjsIMG_4256JPG.jpg', 0, '', 0.00),
(1071, 75, 'ttbwijvpIMG_4265JPG.jpg', 0, '', 0.00),
(1072, 75, 'pmr4ronfIMG_4257JPG.jpg', 0, '', 0.00),
(1073, 75, 'kr7xdonsIMG_3937JPG.jpg', 0, '', 0.00),
(1074, 75, 'x35kc46jIMG_3929JPG.jpg', 0, '', 0.00),
(1075, 76, 'w2n776pdIMG_8089JPG.jpg', 0, '', 0.00),
(1076, 76, 'e4738b8xIMG_8092JPG.jpg', 0, '', 0.00),
(1077, 76, 'd03aiinzIMG_8102JPG.jpg', 0, '', 0.00),
(1078, 76, 'cu475ei5IMG_8122JPG.jpg', 0, '', 0.00),
(1079, 76, 'mn46xw8uIMG_8131JPG.jpg', 0, '', 0.00),
(1080, 76, '6a2v2ye2IMG_8208JPG.jpg', 0, '', 0.00),
(1081, 76, 'hufyn6b2IMG_8266JPG.jpg', 0, '', 0.00),
(1082, 76, 'we30boydIMG_8274JPG.jpg', 0, '', 0.00),
(1083, 76, '6iaxc2ufIMG_8298JPG.jpg', 0, '', 0.00),
(1084, 76, 'qe0zwp5xIMG_8302JPG.jpg', 0, '', 0.00),
(1085, 76, 'm3kkq4pqIMG_8391JPG.jpg', 0, '', 0.00),
(1086, 76, 'h3rgn8w4IMG_8394JPG.jpg', 0, '', 0.00),
(1087, 76, 'kahbr0n0IMG_8459JPG.jpg', 0, '', 0.00),
(1088, 76, 'inidsyeyIMG_8467JPG.jpg', 0, '', 0.00),
(1089, 76, 'njr5zq7xIMG_8470JPG.jpg', 0, '', 0.00),
(1090, 76, '680z7ofbIMG_8471JPG.jpg', 0, '', 0.00),
(1091, 76, 'ifz2yhboIMG_8473JPG.jpg', 0, '', 0.00),
(1092, 76, 'f7cvx4uvIMG_8478JPG.jpg', 0, '', 0.00),
(1093, 76, 'krca50csIMG_8518JPG.jpg', 0, '', 0.00),
(1094, 76, 'i2qd7ixyIMG_8538JPG.jpg', 0, '', 0.00),
(1095, 76, '7seaii0qIMG_8544JPG.jpg', 0, '', 0.00),
(1096, 76, 'nms48s5vIMG_8581JPG.jpg', 0, '', 0.00),
(1097, 76, '0xkexrg5IMG_8589JPG.jpg', 0, '', 0.00),
(1098, 76, '6hxwnxshIMG_8619JPG.jpg', 0, '', 0.00),
(1099, 76, 'xn7p8a78IMG_8655JPG.jpg', 0, '', 0.00),
(1100, 76, 'kbzcmwk3IMG_8661JPG.jpg', 0, '', 0.00),
(1101, 76, '7afsxs63IMG_8671JPG.jpg', 0, '', 0.00),
(1102, 76, 'xuf2se6rIMG_8698JPG.jpg', 0, '', 0.00),
(1103, 76, '2wv8rdmsIMG_8725JPG.jpg', 0, '', 0.00),
(1104, 76, 'nmboy5ogIMG_8746JPG.jpg', 0, '', 0.00),
(1105, 76, 'eithwanyIMG_8747JPG.jpg', 0, '', 0.00),
(1106, 77, 's6zfgsio20130622_172331jpg.jpg', 0, '', 0.00),
(1107, 77, 'pz2k68xn20130622_172411jpg.jpg', 0, '', 0.00),
(1108, 77, 'sfpbpazr20130622_182404jpg.jpg', 0, '', 0.00),
(1109, 77, 'gkugp62g20130622_183312jpg.jpg', 0, '', 0.00),
(1110, 77, 'ad8bn2nn20130622_190816jpg.jpg', 0, '', 0.00),
(1111, 77, 'd7zzjfkc20130622_191207jpg.jpg', 0, '', 0.00),
(1112, 77, 's3xx274820130622_193833jpg.jpg', 0, '', 0.00),
(1113, 77, 'ne34ukok20130622_193915jpg.jpg', 0, '', 0.00),
(1114, 77, '8jjjc4e520130622_193955jpg.jpg', 0, '', 0.00),
(1115, 77, '76hd3jyj20130622_194448jpg.jpg', 0, '', 0.00),
(1116, 77, 'h7q5ip4720130622_200031jpg.jpg', 0, '', 0.00),
(1117, 77, 'yxca26ew20130622_200214jpg.jpg', 0, '', 0.00),
(1118, 77, '7db4zuo620130622_201011jpg.jpg', 0, '', 0.00),
(1119, 77, '5sqgugod20130622_203246jpg.jpg', 0, '', 0.00),
(1120, 77, 'mbz40gkp20130622_203253jpg.jpg', 0, '', 0.00),
(1121, 77, 'w77wjzjq20130622_203322jpg.jpg', 0, '', 0.00),
(1122, 77, 'rcv8oeh720130622_203343jpg.jpg', 0, '', 0.00),
(1123, 77, 'if4bn5zfSDC16746JPG.jpg', 0, '', 0.00),
(1124, 77, '4k8dofmgSDC16749JPG.jpg', 0, '', 0.00),
(1125, 78, 'u3mycqhzIMG_1112JPG.jpg', 0, '', 0.00),
(1126, 78, '46g28fbhIMG_1124JPG.jpg', 0, '', 0.00),
(1127, 78, 'khdbczzgIMG_1132JPG.jpg', 0, '', 0.00),
(1128, 78, '6ck7gxt7IMG_1135JPG.jpg', 0, '', 0.00),
(1129, 78, '806qpopqIMG_1139JPG.jpg', 0, '', 0.00),
(1130, 78, 't7atdjkgIMG_1142JPG.jpg', 0, '', 0.00),
(1131, 78, '2cvudcreIMG_1143JPG.jpg', 0, '', 0.00),
(1132, 78, 'jfkxz3zsIMG_1144JPG.jpg', 0, '', 0.00),
(1133, 78, 'bm8c88pfIMG_1146JPG.jpg', 0, '', 0.00),
(1134, 78, 'wjkkfj44IMG_1150JPG.jpg', 0, '', 0.00),
(1135, 78, 'axfeosv0IMG_1151JPG.jpg', 0, '', 0.00),
(1136, 78, 'stptvi66IMG_1156JPG.jpg', 0, '', 0.00),
(1137, 78, '24g3hiv0IMG_1157JPG.jpg', 0, '', 0.00),
(1138, 78, 'wbswoxgqIMG_1159JPG.jpg', 0, '', 0.00),
(1139, 78, '40d7w0guWP_20140826_013jpg.jpg', 0, '', 0.00),
(1140, 79, 'zd04h4yoIMG_20160520_WA0025jpg.jpg', 11, '', 0.00),
(1141, 79, '8jgstz6uIMG_20160520_WA0026jpg.jpg', 0, '', 0.00),
(1142, 79, 'nrkzctwqIMG_20160520_WA0029jpg.jpg', 0, '', 0.00),
(1143, 79, 'hd358sjkIMG_20160520_WA0030jpg.jpg', 0, '', 0.00),
(1144, 79, '373nh5yxIMG_20160520_WA0031jpg.jpg', 0, '', 0.00),
(1145, 79, '56xpnebtIMG_20160520_WA0033jpg.jpg', 0, '', 0.00),
(1146, 79, '2eseda06IMG_20160520_WA0035jpg.jpg', 0, '', 0.00),
(1147, 79, 'khkwsze8IMG_20160520_WA0037jpg.jpg', 0, '', 0.00),
(1148, 79, 'ksuqqps5IMG_20160520_WA0038jpg.jpg', 0, '', 0.00),
(1149, 79, '4srv2dp5IMG_20160520_WA0040jpg.jpg', 0, '', 0.00),
(1150, 79, 'nbd0wadqIMG_20160520_WA0047jpg.jpg', 0, '', 0.00),
(1151, 79, 'ugpkr7xdIMG_20160520_WA0048jpg.jpg', 0, '', 0.00),
(1152, 79, 'cv5pbwzmIMG_20160520_WA0049jpg.jpg', 0, '', 0.00),
(1153, 79, 'njd2igfjIMG_20160520_WA0050jpg.jpg', 0, '', 0.00),
(1154, 79, 'f2vjfopiIMG_20160520_WA0051jpg.jpg', 0, '', 0.00),
(1155, 80, 'ny34juzn1JPG.jpg', 0, '', 0.00),
(1156, 80, 'rva5qm4s2jpg.jpg', 0, '', 0.00),
(1157, 80, 'bj47ra2v3JPG.jpg', 0, '', 0.00),
(1158, 80, 'gionh8x04JPG.jpg', 0, '', 0.00),
(1159, 80, 'q7qyt3fsSDC14358JPG.jpg', 0, '', 0.00),
(1160, 80, 'bphbo2igSDC14363JPG.jpg', 0, '', 0.00),
(1161, 81, 'u6qmx7mzDSC_0795JPG.jpg', 0, '', 0.00),
(1162, 81, 'su4fhbg2DSC_0831JPG.jpg', 0, '', 0.00),
(1163, 81, 'rfcftg7qDSC_0926JPG.jpg', 0, '', 0.00),
(1164, 81, '3ob0ng08DSC_0937JPG.jpg', 0, '', 0.00),
(1165, 81, '3tkyccs7DSC_0954JPG.jpg', 0, '', 0.00),
(1166, 81, '7b85rtq8DSC_0957JPG.jpg', 0, '', 0.00),
(1167, 81, 'iqxccm33DSC_0962JPG.jpg', 0, '', 0.00),
(1168, 81, 'vie6kzrqDSC_0973JPG.jpg', 0, '', 0.00),
(1169, 81, 'w0q3v0xwDSC_0976JPG.jpg', 0, '', 0.00),
(1170, 81, '4md7mbsxDSC_0986JPG.jpg', 0, '', 0.00),
(1171, 81, 'v5m5p3wuDSC_0988JPG.jpg', 0, '', 0.00),
(1172, 81, 'evm53eykDSC_1003JPG.jpg', 0, '', 0.00),
(1173, 81, 'kibn8nsbDSC_1010JPG.jpg', 0, '', 0.00),
(1174, 81, 'fuvsck3tDSC_1011JPG.jpg', 0, '', 0.00),
(1175, 81, 'q3kv33tbDSC_1017JPG.jpg', 0, '', 0.00),
(1176, 81, '0jqbznyvDSC_1030JPG.jpg', 0, '', 0.00),
(1177, 81, 'opq7cvctDSC_1033JPG.jpg', 0, '', 0.00),
(1178, 81, 'h0fc0iehDSC_1050JPG.jpg', 0, '', 0.00),
(1179, 81, 'duptowq6DSC_1082JPG.jpg', 0, '', 0.00),
(1180, 81, 'mgggjwq2DSC_1089JPG.jpg', 0, '', 0.00),
(1181, 82, 'kxwq6f4qSDC15488JPG.jpg', 0, '', 0.00),
(1182, 82, 'gkfas5avSDC15490JPG.jpg', 0, '', 0.00),
(1183, 82, 'smvktoz3SDC15498JPG.jpg', 0, '', 0.00),
(1184, 82, 'unv0g2x3SDC15503JPG.jpg', 0, '', 0.00),
(1185, 82, 'y8aifa7cSDC15506JPG.jpg', 0, '', 0.00),
(1186, 82, 'wwk7rhdsSDC15507JPG.jpg', 0, '', 0.00),
(1187, 82, 'yhtq028fSDC15513JPG.jpg', 0, '', 0.00),
(1188, 82, 'on35grqdSDC15515JPG.jpg', 0, '', 0.00),
(1189, 82, 'j5xiro8wSDC15516JPG.jpg', 0, '', 0.00),
(1190, 82, '5rqdfpp7SDC15517JPG.jpg', 0, '', 0.00),
(1191, 82, 'sdde6vx0SDC15523JPG.jpg', 0, '', 0.00),
(1192, 82, 'eqrp3p0sSDC15524JPG.jpg', 0, '', 0.00),
(1193, 82, 'bpopimwuSDC15527JPG.jpg', 0, '', 0.00),
(1194, 82, 'dv7nwdpuSDC15536JPG.jpg', 0, '', 0.00),
(1195, 82, 'fci6ajfsSDC15539JPG.jpg', 0, '', 0.00),
(1196, 82, 'mqhkmur0SDC15557JPG.jpg', 0, '', 0.00),
(1197, 82, 'fcemvrqeSDC15554JPG.jpg', 0, '', 0.00),
(1198, 82, 'p6depfoeSDC15559JPG.jpg', 0, '', 0.00),
(1199, 82, '4sobnjyrSDC15560JPG.jpg', 0, '', 0.00),
(1200, 82, 'm4d8t6rzSDC15567JPG.jpg', 0, '', 0.00),
(1201, 83, 'pm5tj5xiDSC_0002jpg.jpg', 0, '', 0.00),
(1202, 83, '2qg6mi6aDSC_0005jpg.jpg', 0, '', 0.00),
(1203, 83, 'yxquoyosDSC_0199jpg.jpg', 0, '', 0.00),
(1204, 83, '62rszp68DSC_0200jpg.jpg', 0, '', 0.00),
(1205, 83, '6grb6xepDSC_0241jpg.jpg', 0, '', 0.00),
(1206, 83, '2y2ig7xyDSC_0288jpg.jpg', 0, '', 0.00),
(1207, 83, 'ra58oqn2DSC_1627jpg.jpg', 0, '', 0.00),
(1208, 83, 'ssvx6z4iDSC_1628jpg.jpg', 0, '', 0.00),
(1209, 83, 'cu0646urDSC_1640jpg.jpg', 0, '', 0.00),
(1210, 83, '3qq4errmDSC_1647jpg.jpg', 0, '', 0.00),
(1211, 83, 'p4qqi3j8DSC_1650jpg.jpg', 0, '', 0.00),
(1212, 83, 'p7d3xansDSC_1721___Copyjpg.jpg', 0, '', 0.00),
(1213, 83, 'burxks8tDSC_1721jpg.jpg', 0, '', 0.00),
(1214, 83, 'tobuob8dDSC_1722jpg.jpg', 0, '', 0.00),
(1215, 83, 'dz3maopnDSC_1729jpg.jpg', 0, '', 0.00),
(1216, 83, 'wp2pdja3DSC_1804jpg.jpg', 0, '', 0.00),
(1217, 83, 'xqjb0j7dDSC_1956jpg.jpg', 0, '', 0.00),
(1218, 83, '36vymemyDSC_2052jpg.jpg', 0, '', 0.00),
(1219, 83, '0m4sgq6jDSC_3847jpg.jpg', 0, '', 0.00),
(1220, 83, '0nxafgswDSC_3850jpg.jpg', 0, '', 0.00),
(1221, 84, 'spjq4impDSC_0039_copyjpg.jpg', 0, '', 0.00),
(1222, 84, '4mv50grtDSC_4924jpg.jpg', 0, '', 0.00),
(1223, 84, 'ewf0rw28DSC_4965jpg.jpg', 0, '', 0.00),
(1224, 84, 'qdqgd4jgDSC_4971jpg.jpg', 0, '', 0.00),
(1225, 84, 'f4fusn4oDSC_4975jpg.jpg', 0, '', 0.00),
(1226, 84, 'rvgorujfDSC_4982jpg.jpg', 0, '', 0.00),
(1227, 84, 'uj0stpf6DSC_5028jpg.jpg', 0, '', 0.00),
(1228, 84, 's5d8ezuzDSC_5036jpg.jpg', 0, '', 0.00),
(1229, 84, 'z3bxpj0hDSC_5046jpg.jpg', 0, '', 0.00),
(1230, 84, 'pdqoykktDSC_5132jpg.jpg', 0, '', 0.00),
(1231, 85, 'yvtgsqgaIMG_3211JPG.jpg', 0, '', 0.00),
(1232, 85, 'j2kpex8fIMG_3212JPG.jpg', 0, '', 0.00),
(1233, 85, '4visvch2IMG_3217JPG.jpg', 0, '', 0.00),
(1234, 85, 'iy6kpz2dIMG_3218JPG.jpg', 0, '', 0.00),
(1235, 85, 'v3owx667IMG_3221JPG.jpg', 0, '', 0.00),
(1236, 85, '2pdconzsIMG_3222JPG.jpg', 0, '', 0.00),
(1237, 85, '44n2568nIMG_3224JPG.jpg', 0, '', 0.00),
(1238, 85, 'igihi6rzIMG_3225JPG.jpg', 0, '', 0.00),
(1239, 85, 'qe58kdupIMG_3227JPG.jpg', 0, '', 0.00),
(1240, 85, 'oz65m2o0IMG_3229JPG.jpg', 0, '', 0.00),
(1241, 85, 'dg0qvk4zIMG_3230JPG.jpg', 0, '', 0.00),
(1242, 85, 'uu3ez5xmIMG_3231JPG.jpg', 0, '', 0.00),
(1243, 85, 'ob4ey5ghIMG_3232JPG.jpg', 0, '', 0.00),
(1244, 85, 'y8s24opxIMG_3233JPG.jpg', 0, '', 0.00),
(1245, 85, 'kbbok266IMG_3234JPG.jpg', 0, '', 0.00),
(1246, 86, 'ed5kxt3tIMG_3611JPG.jpg', 0, '', 0.00),
(1247, 86, 'xea7jscdIMG_3613JPG.jpg', 0, '', 0.00),
(1248, 86, 'dfip2o5xIMG_3618JPG.jpg', 0, '', 0.00),
(1249, 86, 'xjosk3afIMG_3622JPG.jpg', 0, '', 0.00),
(1250, 86, 's4vbzuv3IMG_3624JPG.jpg', 0, '', 0.00),
(1251, 86, 'fd0mt8v4IMG_3630JPG.jpg', 0, '', 0.00),
(1252, 86, 'z0r00d3oIMG_3632JPG.jpg', 0, '', 0.00),
(1253, 86, 'pg3y6r3vIMG_3633JPG.jpg', 0, '', 0.00),
(1254, 86, 'm2o0p6fxIMG_3634JPG.jpg', 0, '', 0.00),
(1255, 86, 'a3p86ymsIMG_3637JPG.jpg', 0, '', 0.00),
(1256, 86, 'tom6nftgIMG_3638JPG.jpg', 0, '', 0.00),
(1257, 86, '082emorjIMG_3641JPG.jpg', 0, '', 0.00),
(1258, 86, 'njoehm0nIMG_3642JPG.jpg', 0, '', 0.00),
(1259, 86, '6wyi7wx3IMG_3643JPG.jpg', 0, '', 0.00),
(1260, 87, 'czm5z067IMG_0601JPG.jpg', 0, '', 0.00),
(1261, 87, 'piquyj8eIMG_0603JPG.jpg', 0, '', 0.00),
(1262, 87, 'khp8md48IMG_0604JPG.jpg', 0, '', 0.00),
(1263, 87, 'm05hzsxdIMG_0606JPG.jpg', 0, '', 0.00),
(1264, 87, 'ha2hrvoaIMG_0609JPG.jpg', 0, '', 0.00),
(1265, 87, 'j0kfuvscIMG_0613JPG.jpg', 0, '', 0.00),
(1266, 87, 'sxht48yaIMG_0617JPG.jpg', 0, '', 0.00),
(1267, 87, 'y44naqn8IMG_0617JPG.jpg', 0, '', 0.00),
(1268, 87, '440d7w0gIMG_0627JPG.jpg', 0, '', 0.00),
(1269, 87, '3ek8kokdIMG_0641JPG.jpg', 0, '', 0.00),
(1270, 87, 'jvp6xhcgIMG_0643JPG.jpg', 0, '', 0.00),
(1271, 87, 'm77ebt8pIMG_0644JPG.jpg', 0, '', 0.00),
(1272, 87, '7ra2vudxIMG_0662JPG.jpg', 0, '', 0.00),
(1273, 87, 'yamr7qr7IMG_0666JPG.jpg', 0, '', 0.00),
(1274, 87, 'd5ethmwoIMG_0680JPG.jpg', 0, '', 0.00),
(1275, 87, 'y0v2jobiIMG_0682JPG.jpg', 0, '', 0.00),
(1276, 87, 'cjwtfm5zIMG_0686JPG.jpg', 0, '', 0.00),
(1277, 87, 'xo5gvohfIMG_0690JPG.jpg', 0, '', 0.00),
(1278, 87, 'g6pvzno5IMG_0765JPG.jpg', 0, '', 0.00),
(1279, 88, '30pkcbkeDSC_0151jpg.jpg', 0, '', 0.00),
(1280, 88, '3oeegsq8DSC_0174jpg.jpg', 0, '', 0.00),
(1281, 88, 'pcqr4am2DSC_4560jpg.jpg', 0, '', 0.00),
(1282, 88, 'o3586adgDSC_4864jpg.jpg', 0, '', 0.00),
(1283, 88, '0vog70q3SDC15661JPG.jpg', 0, '', 0.00),
(1284, 88, 'umxbuopxSDC15662JPG.jpg', 0, '', 0.00),
(1285, 88, '3hwksu4fSDC15663JPG.jpg', 0, '', 0.00),
(1286, 88, 'rj6kb3pfSDC15665JPG.jpg', 0, '', 0.00),
(1287, 88, 'nquv6f0dSDC15666JPG.jpg', 0, '', 0.00),
(1288, 88, 'z7jsxotaSDC15667JPG.jpg', 0, '', 0.00),
(1289, 88, '4gb2yve4SDC15669JPG.jpg', 0, '', 0.00),
(1290, 88, '6grb6xepSDC15670JPG.jpg', 0, '', 0.00),
(1291, 89, 'f26wdtbn1JPG.jpg', 0, '', 0.00),
(1292, 89, 'bvv57gwm2_1JPG.jpg', 0, '', 0.00),
(1293, 89, 'kvhsmtfm2_2JPG.jpg', 0, '', 0.00),
(1294, 89, 'wjsya4ii3_2JPG.jpg', 0, '', 0.00),
(1295, 89, 'ziqnrszh3JPG.jpg', 0, '', 0.00),
(1296, 89, 'u72f0uok4_1JPG.jpg', 0, '', 0.00),
(1297, 89, 'nbjiwjsd5JPG.jpg', 0, '', 0.00),
(1298, 89, 'tnhjazod6_2JPG.jpg', 0, '', 0.00),
(1299, 89, 'dpusdyap6_3JPG.jpg', 0, '', 0.00),
(1300, 89, 'jm5i66tw6_4JPG.jpg', 0, '', 0.00),
(1301, 89, 'jb0rstmv6_5JPG.jpg', 0, '', 0.00),
(1302, 89, 'huimzmg56_6JPG.jpg', 0, '', 0.00),
(1303, 89, 'a05bhspx6_7JPG.jpg', 0, '', 0.00),
(1304, 89, 'xu0dzwvo6_8JPG.jpg', 0, '', 0.00),
(1305, 89, '6mtxxv7x6_9JPG.jpg', 0, '', 0.00),
(1306, 89, 'ucm7jdj66_10JPG.jpg', 0, '', 0.00),
(1307, 89, 'sgxebtuz6_12JPG.jpg', 0, '', 0.00),
(1308, 89, 'r8r8d5vv6_13JPG.jpg', 0, '', 0.00),
(1309, 89, '4yuenmh67_1JPG.jpg', 0, '', 0.00),
(1310, 89, 'gz4btjuz7_2JPG.jpg', 0, '', 0.00),
(1311, 89, 'qm00jv7q7_3JPG.jpg', 0, '', 0.00),
(1312, 89, 'akndsv057_4JPG.jpg', 0, '', 0.00),
(1313, 89, 'xcrzmjwf7_5JPG.jpg', 0, '', 0.00),
(1314, 89, 'a0gar5srIMG_2355JPG.jpg', 0, '', 0.00),
(1315, 90, 'k06w6py51_2JPG.jpg', 0, '', 0.00),
(1316, 90, 'gkfohxr61_3JPG.jpg', 0, '', 0.00),
(1317, 90, 'q2auv3at2_1JPG.jpg', 0, '', 0.00),
(1318, 90, 'ym22fqip2_2JPG.jpg', 0, '', 0.00),
(1319, 90, 'z0aygh3j3_4JPG.jpg', 0, '', 0.00),
(1320, 90, 'cx6ojxxj3_5JPG.jpg', 0, '', 0.00),
(1321, 90, 'twniatvt4_2JPG.jpg', 0, '', 0.00),
(1322, 90, 'vodkpbw7IMG_6420JPG.jpg', 0, '', 0.00),
(1323, 90, 'ue8wqopbIMG_6421JPG.jpg', 0, '', 0.00),
(1324, 90, 'f58drep0IMG_6423JPG.jpg', 0, '', 0.00),
(1325, 91, 'qnrszhmsIMG_6217JPG.jpg', 0, '', 0.00),
(1326, 91, '8npjnezhIMG_6218JPG.jpg', 0, '', 0.00),
(1327, 91, 'dt4q0u2oIMG_6219JPG.jpg', 0, '', 0.00),
(1328, 91, 'gcsqc0isIMG_6223JPG.jpg', 0, '', 0.00),
(1329, 91, 'ce4jnswuIMG_6225JPG.jpg', 0, '', 0.00),
(1330, 91, 'wucivqzuIMG_6226JPG.jpg', 0, '', 0.00),
(1331, 91, 'szi732fiIMG_6228JPG.jpg', 0, '', 0.00),
(1332, 91, '24r0qvytIMG_6230JPG.jpg', 0, '', 0.00),
(1333, 91, 'c2gis3qdIMG_6234JPG.jpg', 0, '', 0.00),
(1334, 91, 'gec0qzxwIMG_6235JPG.jpg', 0, '', 0.00),
(1335, 91, 'art86hj6IMG_6237JPG.jpg', 0, '', 0.00),
(1336, 91, '2nwaxcagIMG_6238JPG.jpg', 0, '', 0.00),
(1337, 91, '66iyerg8IMG_6244JPG.jpg', 0, '', 0.00),
(1338, 91, 'khdbczzgIMG_6245JPG.jpg', 0, '', 0.00),
(1339, 92, 'ip8shfqf1_2JPG.jpg', 0, '', 0.00),
(1340, 92, 'fwi2t4qn2_3JPG.jpg', 0, '', 0.00),
(1341, 92, 'kk4tg7c2IMG_5691JPG.jpg', 0, '', 0.00),
(1342, 92, 'bq6nxrvrIMG_5693JPG.jpg', 0, '', 0.00),
(1343, 92, '3jdrywtxIMG_5695JPG.jpg', 0, '', 0.00),
(1344, 92, '8itsviz3IMG_5700JPG.jpg', 0, '', 0.00),
(1345, 92, 'ejj0sfzoIMG_5701JPG.jpg', 0, '', 0.00),
(1346, 92, '4s270ha8IMG_5702JPG.jpg', 0, '', 0.00),
(1347, 92, '338wqayjIMG_5703JPG.jpg', 0, '', 0.00),
(1348, 92, 'tdvqbsf7IMG_5714JPG.jpg', 0, '', 0.00),
(1349, 93, 'gd4jgpkd1_1JPG.jpg', 0, '', 0.00),
(1350, 93, 'ekjiwxh41_2JPG.jpg', 0, '', 0.00),
(1351, 93, 'eqiw08nm2JPG.jpg', 0, '', 0.00),
(1352, 93, 'ahs35ji73JPG.jpg', 0, '', 0.00),
(1353, 93, 'oyrjz8e54_1JPG.jpg', 0, '', 0.00),
(1354, 93, 'h3n7zm8d4_2JPG.jpg', 0, '', 0.00),
(1355, 93, 'ajj458ddIMG_0537JPG.jpg', 0, '', 0.00),
(1356, 93, 'jy2sprckIMG_0549JPG.jpg', 0, '', 0.00),
(1357, 93, '70tg33feIMG_0550JPG.jpg', 0, '', 0.00),
(1358, 93, 'wz7j6ogbIMG_0552JPG.jpg', 0, '', 0.00),
(1359, 93, '8uzayupzIMG_0557JPG.jpg', 0, '', 0.00),
(1360, 94, '6y38z33c1_2JPG.jpg', 0, '', 0.00),
(1361, 94, 'w4h7cgr71JPG.jpg', 0, '', 0.00),
(1362, 94, 'o4qjer2c2JPG.jpg', 0, '', 0.00),
(1363, 94, '5avs7mz74_1JPG.jpg', 0, '', 0.00),
(1364, 94, 'ixaitma24_2JPG.jpg', 0, '', 0.00),
(1365, 94, 's7ez2ksj4_3JPG.jpg', 0, '', 0.00),
(1366, 94, 'b75vyfaa4_4JPG.jpg', 0, '', 0.00),
(1367, 94, '6posvf8k5JPG.jpg', 0, '', 0.00),
(1368, 94, 'swyafuhp6JPG.jpg', 0, '', 0.00),
(1369, 94, '8i4r4v3v7JPG.jpg', 0, '', 0.00),
(1370, 94, '5pabpexu8_1JPG.jpg', 0, '', 0.00),
(1371, 94, 'bhogbzto8_2JPG.jpg', 0, '', 0.00),
(1372, 94, 'bugybf508_3JPG.jpg', 0, '', 0.00),
(1373, 94, 'upz5xzmn9JPG.jpg', 0, '', 0.00),
(1374, 94, 'ra8kh2d210JPG.jpg', 0, '', 0.00),
(1375, 94, 'szeuappiIMG_4076JPG.jpg', 0, '', 0.00),
(1376, 94, 'y5ciath4IMG_4115JPG.jpg', 0, '', 0.00),
(1377, 94, 'hiofvswnIMG_4146JPG.jpg', 0, '', 0.00),
(1378, 94, '7swjpt27IMG_4156JPG.jpg', 0, '', 0.00),
(1379, 94, 'tinsi5oyIMG_4185JPG.jpg', 0, '', 0.00),
(1380, 94, '2pgphzqsIMG_4186JPG.jpg', 0, '', 0.00),
(1381, 95, 'b3k6nnfwDSC_0003JPG.jpg', 0, '', 0.00),
(1382, 95, 'meq0ugenDSC_0006JPG.jpg', 0, '', 0.00),
(1383, 95, 't3wrhr3uDSC_0007JPG.jpg', 0, '', 0.00),
(1384, 95, '6i3ne4wqDSC_0008JPG.jpg', 0, '', 0.00),
(1385, 95, '8m6m78zkDSC_0010JPG.jpg', 0, '', 0.00),
(1386, 95, 'ia02kynhDSC_0011JPG.jpg', 0, '', 0.00),
(1387, 95, 'zd0i6vgyDSC_0012JPG.jpg', 0, '', 0.00),
(1388, 95, 'i3car85jDSC_0015JPG.jpg', 0, '', 0.00),
(1389, 95, 'g67fpz5qDSC_0015JPG.jpg', 0, '', 0.00),
(1390, 95, 'qhbu6uxqDSC_0016JPG.jpg', 0, '', 0.00),
(1391, 95, 'nftnpr08DSC_0018JPG.jpg', 0, '', 0.00),
(1392, 95, 'gnqr4obtDSC_0019JPG.jpg', 0, '', 0.00),
(1393, 95, 'mqhkmur0DSC_0021JPG.jpg', 0, '', 0.00),
(1394, 95, 'kyfv604zDSC_0022JPG.jpg', 0, '', 0.00),
(1395, 95, 'gq3s2tbqDSC_0023JPG.jpg', 0, '', 0.00),
(1396, 95, 'pi4c5kj4DSC_0081JPG.jpg', 0, '', 0.00),
(1397, 95, 'qayjj4riDSC_0100JPG.jpg', 0, '', 0.00),
(1398, 95, 'k6fna4qqDSC_0111JPG.jpg', 0, '', 0.00),
(1399, 95, 'bfo6swdkDSC_0117JPG.jpg', 0, '', 0.00),
(1400, 95, 'mho2zw3uDSC_0118JPG.jpg', 0, '', 0.00),
(1401, 95, 'rbjfkqfnDSC_0126JPG.jpg', 0, '', 0.00),
(1402, 95, 'dmb2a8daDSC_0129JPG.jpg', 0, '', 0.00),
(1403, 95, 'h3rgn8w4DSC_0130JPG.jpg', 0, '', 0.00),
(1404, 95, '23oeegsqDSC_0133JPG.jpg', 0, '', 0.00),
(1405, 95, 'snbrqosoDSC_0138JPG.jpg', 0, '', 0.00),
(1406, 95, 'y866mxhcDSC_0140JPG.jpg', 0, '', 0.00),
(1407, 95, '4zdqriydDSC_0152JPG.jpg', 0, '', 0.00),
(1408, 95, 'csidvqw3DSC_0190JPG.jpg', 0, '', 0.00),
(1409, 95, 'qktk8ku6DSC_0192JPG.jpg', 0, '', 0.00),
(1410, 95, '4zdc2rh2DSC_0193JPG.jpg', 0, '', 0.00),
(1411, 95, 'ufkc4k8kDSC_0194JPG.jpg', 0, '', 0.00),
(1412, 95, 'pruqimhoDSC_0195JPG.jpg', 0, '', 0.00),
(1413, 95, 'bb7cdzppDSC_0196JPG.jpg', 0, '', 0.00),
(1414, 95, 'pjxqym3aDSC_0291JPG.jpg', 0, '', 0.00),
(1415, 95, 'kv2hj3msDSC_0295JPG.jpg', 0, '', 0.00),
(1416, 96, 'gb6cpruq1_2JPG.jpg', 0, '', 0.00),
(1417, 96, '45wf4btr1_8JPG.jpg', 0, '', 0.00),
(1418, 96, 'fngucfqi1JPG.jpg', 0, '', 0.00),
(1419, 96, 'aqfnkpab3JPG.jpg', 0, '', 0.00),
(1420, 96, 'at65pvmw4_8JPG.jpg', 0, '', 0.00),
(1421, 96, '3id8tedg4_14JPG.jpg', 0, '', 0.00),
(1422, 96, 'vt5gsco27_1JPG.jpg', 0, '', 0.00),
(1423, 96, 'o2wjbizh7_2JPG.jpg', 0, '', 0.00),
(1424, 96, 'mguj06ih7_3JPG.jpg', 0, '', 0.00),
(1425, 96, '8qqtfieh7_6JPG.jpg', 0, '', 0.00),
(1426, 96, 'zrcymhr67_7JPG.jpg', 0, '', 0.00),
(1427, 96, 'eh0xzwmw7_8JPG.jpg', 0, '', 0.00),
(1428, 96, 'h07rkizp7_9JPG.jpg', 0, '', 0.00),
(1429, 96, 'c63yozs07_10JPG.jpg', 0, '', 0.00),
(1430, 96, 'sn4apfd07_11JPG.jpg', 0, '', 0.00),
(1431, 96, 'tofom6fu7_12JPG.jpg', 0, '', 0.00),
(1432, 96, 'ey8p403h7_13JPG.jpg', 0, '', 0.00),
(1433, 96, 'u5nykrfw7_14JPG.jpg', 0, '', 0.00),
(1434, 96, '3gzxm7tf7_15JPG.jpg', 0, '', 0.00),
(1435, 96, 'hempy5257_17JPG.jpg', 0, '', 0.00),
(1436, 96, 'sxkknd6kIMG_3873JPG.jpg', 0, '', 0.00),
(1437, 97, 'd2fqwe7aIMG_5078JPG.jpg', 0, '', 0.00),
(1438, 97, 'gu23rdi0IMG_5079JPG.jpg', 0, '', 0.00),
(1439, 97, '3dr3d20mIMG_5080JPG.jpg', 0, '', 0.00),
(1440, 97, 'coc2jab7IMG_5081JPG.jpg', 0, '', 0.00),
(1441, 97, 'jcqodrguIMG_5082JPG.jpg', 0, '', 0.00),
(1442, 97, 'y440yi4jIMG_5083JPG.jpg', 0, '', 0.00),
(1443, 97, 'zjthpo6yIMG_5084JPG.jpg', 0, '', 0.00),
(1444, 97, 'byfp6vc4IMG_5085JPG.jpg', 0, '', 0.00),
(1445, 97, 'd76eeyxqIMG_5086JPG.jpg', 0, '', 0.00),
(1446, 97, '3jyj2v2dIMG_5088JPG.jpg', 0, '', 0.00),
(1447, 97, '0snm4ptdIMG_5089JPG.jpg', 0, '', 0.00),
(1448, 97, 'mhac8fsrIMG_5090JPG.jpg', 0, '', 0.00),
(1449, 97, 'obt2zzudIMG_5091JPG.jpg', 0, '', 0.00),
(1450, 97, 'npukndkaIMG_5092JPG.jpg', 0, '', 0.00),
(1451, 97, 'f5xzs84xIMG_5093JPG.jpg', 0, '', 0.00),
(1452, 97, 'heqiw08nIMG_5094JPG.jpg', 0, '', 0.00),
(1453, 97, '3ebiwqhyIMG_5095JPG.jpg', 0, '', 0.00),
(1454, 97, 'pi4c5kj4IMG_5096JPG.jpg', 0, '', 0.00),
(1455, 97, '45qbstwfIMG_5097JPG.jpg', 0, '', 0.00),
(1456, 97, '7p03g0jwIMG_5098JPG.jpg', 0, '', 0.00),
(1457, 97, 'rf8gqvz0IMG_5098JPG.jpg', 0, '', 0.00),
(1458, 97, '7zpm578wIMG_5100JPG.jpg', 0, '', 0.00),
(1459, 97, '2f4m6pk0IMG_5101JPG.jpg', 0, '', 0.00),
(1460, 97, 'nszmxm6mIMG_5104JPG.jpg', 0, '', 0.00),
(1461, 97, 'p0oa4i4uIMG_5105JPG.jpg', 0, '', 0.00),
(1462, 98, 'k4frftrx1_1JPG.jpg', 0, '', 0.00),
(1463, 98, 'p2pdja3z1_2JPG.jpg', 0, '', 0.00),
(1464, 98, 'x7ssmk8u1_4JPG.jpg', 0, '', 0.00),
(1465, 98, 'jiq5wsmh2_1JPG.jpg', 0, '', 0.00),
(1466, 98, '62533fz22_2JPG.jpg', 0, '', 0.00),
(1467, 98, 'e7o8edyg3_2JPG.jpg', 0, '', 0.00),
(1468, 98, 'hout5vy7IMG_6252JPG.jpg', 0, '', 0.00),
(1469, 98, '62jkahbrIMG_6253JPG.jpg', 0, '', 0.00),
(1470, 98, '00d3oes5IMG_6254JPG.jpg', 0, '', 0.00),
(1471, 98, 'wei77prxIMG_6259JPG.jpg', 0, '', 0.00),
(1472, 98, 'urcakq4bIMG_6268JPG.jpg', 0, '', 0.00),
(1473, 98, 'wf0rw28iIMG_6271JPG.jpg', 0, '', 0.00),
(1474, 98, 'kc4k8kavIMG_6272JPG.jpg', 0, '', 0.00),
(1475, 98, 'qtqgou7dIMG_6274JPG.jpg', 0, '', 0.00),
(1476, 99, '6hxbcpas1_1JPG.jpg', 0, '', 0.00),
(1477, 99, 'fghkeum81_3JPG.jpg', 0, '', 0.00),
(1478, 99, 'oxutdu4z2_2JPG.jpg', 0, '', 0.00),
(1479, 99, 'posa402a2_5JPG.jpg', 0, '', 0.00),
(1480, 99, 'eaii0qhe3_2JPG.jpg', 0, '', 0.00),
(1481, 99, 'c5squk853_3JPG.jpg', 0, '', 0.00),
(1482, 99, 'oyd8wjkd4_1JPG.jpg', 0, '', 0.00),
(1483, 99, '3vf0d7br4_2JPG.jpg', 0, '', 0.00),
(1484, 99, 'wig46ggx5_1JPG.jpg', 0, '', 0.00),
(1485, 99, 'fakgo56m5_2JPG.jpg', 0, '', 0.00),
(1486, 99, 'ji7vqhkz5_3JPG.jpg', 0, '', 0.00),
(1487, 99, 'kyj8zduz6_2JPG.jpg', 0, '', 0.00),
(1488, 99, 'doijjjquIMG_9616JPG.jpg', 0, '', 0.00),
(1489, 99, '7kpmvgkzIMG_9622JPG.jpg', 0, '', 0.00),
(1490, 99, 'n7zm8duiIMG_9625JPG.jpg', 0, '', 0.00),
(1491, 99, 'yerg8xueIMG_9629JPG.jpg', 0, '', 0.00),
(1492, 99, 'mxsbxbgjIMG_9630JPG.jpg', 0, '', 0.00),
(1493, 99, 'qqipuheqIMG_9631JPG.jpg', 0, '', 0.00),
(1494, 99, 'g0dee2p8IMG_9699JPG.jpg', 0, '', 0.00),
(1495, 99, 'cpum8ossIMG_9700JPG.jpg', 0, '', 0.00),
(1496, 100, 'xcdspj4uIMG_0994JPG.jpg', 0, '', 0.00),
(1497, 100, 'auhs73o3IMG_0995JPG.jpg', 0, '', 0.00),
(1498, 100, 'boyrxp0vIMG_0996JPG.jpg', 0, '', 0.00),
(1499, 100, 'ktxrrwgjIMG_1000JPG.jpg', 0, '', 0.00),
(1500, 100, 's4azrc67IMG_1001JPG.jpg', 0, '', 0.00),
(1501, 100, '2bo6hkegIMG_1004JPG.jpg', 0, '', 0.00),
(1502, 100, 'oeviekasIMG_1010JPG.jpg', 0, '', 0.00),
(1503, 100, 'wbarocggIMG_1011JPG.jpg', 0, '', 0.00),
(1504, 100, '44q08rgcIMG_1012JPG.jpg', 0, '', 0.00),
(1505, 100, 'gimhac8fIMG_1013JPG.jpg', 0, '', 0.00),
(1506, 100, 'ksxg7tzgIMG_1014JPG.jpg', 0, '', 0.00),
(1507, 100, '2nqv3sv2IMG_1016JPG.jpg', 0, '', 0.00),
(1508, 100, 'a0gar5srIMG_1021JPG.jpg', 0, '', 0.00),
(1509, 100, '7zmn2n07IMG_1022JPG.jpg', 0, '', 0.00),
(1510, 100, '8n3up3saIMG_1023JPG.jpg', 0, '', 0.00),
(1511, 100, 'c85j7a8oIMG_1024JPG.jpg', 0, '', 0.00),
(1512, 100, 'an2gi7siIMG_1025JPG.jpg', 0, '', 0.00),
(1513, 100, '8krfc78zIMG_1027JPG.jpg', 0, '', 0.00),
(1514, 101, '4uve83tz1_1jpg.jpg', 0, '', 0.00),
(1515, 101, 'un6zqf2v1_3JPG.jpg', 0, '', 0.00),
(1516, 101, 'k33xc6pd2_2JPG.jpg', 0, '', 0.00),
(1517, 101, 'qmihtiq53_1JPG.jpg', 0, '', 0.00),
(1518, 101, 'creixuqm3JPG.jpg', 0, '', 0.00),
(1519, 101, 'cti03kvh4_2JPG.jpg', 0, '', 0.00),
(1520, 101, 'zczndkh64_4JPG.jpg', 0, '', 0.00),
(1521, 101, 'bch20ws34_5JPG.jpg', 0, '', 0.00),
(1522, 101, 'f8kktv7u4jpg.jpg', 0, '', 0.00),
(1523, 101, 'mrm7xaw45_2JPG.jpg', 0, '', 0.00),
(1524, 101, 'naukdmwdIMG_20160320_WA0089jpg.jpg', 0, '', 0.00),
(1525, 102, 'ybfqczt2IMG_5316JPG.jpg', 0, '', 0.00),
(1526, 102, 'mt4jc8c8IMG_5320JPG.jpg', 0, '', 0.00),
(1527, 102, 'o4n6mfccIMG_5322JPG.jpg', 0, '', 0.00),
(1528, 102, 'qwsbr742IMG_5324JPG.jpg', 0, '', 0.00),
(1529, 102, '0fxw04ohIMG_5325JPG.jpg', 0, '', 0.00),
(1530, 102, 'dh8cckisIMG_5329JPG.jpg', 0, '', 0.00),
(1531, 102, '2nj5g2g0IMG_5331JPG.jpg', 0, '', 0.00),
(1532, 102, 'm578wgtuIMG_5336JPG.jpg', 0, '', 0.00),
(1533, 102, '84dfqwswIMG_5340JPG.jpg', 0, '', 0.00),
(1534, 102, 'gw6pdum2IMG_5345JPG.jpg', 0, '', 0.00),
(1535, 102, 'bmfgkqmrIMG_5347JPG.jpg', 0, '', 0.00),
(1536, 102, 'dde6vx03IMG_5350___CopyJPG.jpg', 0, '', 0.00),
(1537, 102, 'sikg6whgIMG_5353JPG.jpg', 0, '', 0.00),
(1538, 102, 'dw840v5bIMG_5360JPG.jpg', 0, '', 0.00),
(1539, 103, 'dxam6ens1_1JPG.jpg', 0, '', 0.00),
(1540, 103, '4uapbtnt2_2JPG.jpg', 0, '', 0.00),
(1541, 103, 'jcxsp8e62_3JPG.jpg', 0, '', 0.00),
(1542, 103, '3eoz3ssp3_1JPG.jpg', 0, '', 0.00),
(1543, 103, 'axjuwwk74JPG.jpg', 0, '', 0.00),
(1544, 103, 'wjpmhrsi5_1JPG.jpg', 0, '', 0.00),
(1545, 103, 'qkimz7rd5_3JPG.jpg', 0, '', 0.00),
(1546, 103, 'o6rb2dyv6_1JPG.jpg', 0, '', 0.00),
(1547, 103, 'n0wv2o046_2JPG.jpg', 0, '', 0.00),
(1548, 103, 'bzg6cetk6_3JPG.jpg', 0, '', 0.00),
(1549, 103, '7szkrzqm6_4JPG.jpg', 0, '', 0.00),
(1550, 103, 'h6sbrmtu6_6JPG.jpg', 0, '', 0.00),
(1551, 103, '24r8ccy77_2JPG.jpg', 0, '', 0.00),
(1552, 103, '0rbdb88iIMG_2568JPG.jpg', 0, '', 0.00),
(1553, 103, 'uxtbt5riIMG_2578JPG.jpg', 0, '', 0.00),
(1554, 103, 'aap4fs8qIMG_2608JPG.jpg', 0, '', 0.00),
(1555, 103, 'crhvq7fnIMG_2610JPG.jpg', 0, '', 0.00),
(1556, 103, 'd2w660qpIMG_2615JPG.jpg', 0, '', 0.00),
(1557, 103, '8ygby7daIMG_2617JPG.jpg', 0, '', 0.00),
(1558, 103, 'n30mtu6dIMG_2616JPG.jpg', 0, '', 0.00),
(1559, 104, 'axu7u05b1JPG.jpg', 0, '', 0.00),
(1560, 104, 'wyy2vc3r2_1JPG.jpg', 0, '', 0.00),
(1561, 104, '87auk50g3_1JPG.jpg', 0, '', 0.00),
(1562, 104, 'tcxee6od4JPG.jpg', 0, '', 0.00),
(1563, 104, 'mtxxv7xg5_2JPG.jpg', 0, '', 0.00),
(1564, 104, 'tw0tcjpm5_3JPG.jpg', 0, '', 0.00),
(1565, 104, 'ydx6voaf6_1JPG.jpg', 0, '', 0.00),
(1566, 104, 'kas80equ6_4JPG.jpg', 0, '', 0.00),
(1567, 104, 'dw5s8igb6_5JPG.jpg', 0, '', 0.00),
(1568, 104, '88wnx66t7_2JPG.jpg', 0, '', 0.00),
(1569, 104, 'e45jbn007_3JPG.jpg', 0, '', 0.00),
(1570, 105, 'hxdvnxy31_1JPG.jpg', 0, '', 0.00),
(1571, 105, 'v3h075aa1_2JPG.jpg', 0, '', 0.00),
(1572, 105, 'smvktoz32JPG.jpg', 0, '', 0.00),
(1573, 105, 'kphio7bc3JPG.jpg', 0, '', 0.00),
(1574, 105, '352ajcjp4JPG.jpg', 0, '', 0.00),
(1575, 105, 'xop2d7pgIMG_6329JPG.jpg', 0, '', 0.00),
(1576, 105, '28fbhhjkIMG_6330JPG.jpg', 0, '', 0.00),
(1577, 105, 'yd5rboo7IMG_6331JPG.jpg', 0, '', 0.00),
(1578, 105, '6jw4dui3IMG_6332JPG.jpg', 0, '', 0.00),
(1579, 105, '3uiida0yIMG_6338JPG.jpg', 0, '', 0.00),
(1580, 105, 'ah6tw0tcIMG_6339JPG.jpg', 0, '', 0.00),
(1581, 105, 'c32b54vqIMG_6340JPG.jpg', 0, '', 0.00),
(1582, 106, 'qhoxn4r51_1JPG.jpg', 0, '', 0.00),
(1583, 106, 'rnjsdk681_2JPG.jpg', 0, '', 0.00),
(1584, 106, 'h3r2xhft1_3JPG.jpg', 0, '', 0.00),
(1585, 106, 'bk0vyxcv2JPG.jpg', 0, '', 0.00),
(1586, 106, '2d6vjbbv3_1JPG.jpg', 0, '', 0.00),
(1587, 106, 'xocj65eq3_2JPG.jpg', 0, '', 0.00),
(1588, 106, 'v8uitp86IMG_1203JPG.jpg', 0, '', 0.00),
(1589, 106, 'xysdanoqIMG_1207JPG.jpg', 0, '', 0.00),
(1590, 106, 'j0hgrbknIMG_1209JPG.jpg', 0, '', 0.00),
(1591, 106, '6ur0xmmiIMG_1210JPG.jpg', 0, '', 0.00),
(1592, 106, 'byw0bstbIMG_1211JPG.jpg', 0, '', 0.00),
(1593, 106, 'inh56iekIMG_1215JPG.jpg', 0, '', 0.00),
(1594, 106, 'k543pj48IMG_1216JPG.jpg', 0, '', 0.00),
(1595, 106, 'vqvar0tnIMG_1217JPG.jpg', 0, '', 0.00),
(1596, 106, 'g2js8n3nIMG_1219JPG.jpg', 0, '', 0.00),
(1597, 106, '0exfwm70IMG_1221JPG.jpg', 0, '', 0.00),
(1598, 106, '4ozvsnw2IMG_1230JPG.jpg', 0, '', 0.00),
(1599, 106, '0wy7vxthIMG_1231JPG.jpg', 0, '', 0.00),
(1600, 106, 'jtvt5gscIMG_1232JPG.jpg', 0, '', 0.00),
(1601, 106, '4hzmu0stIMG_1229JPG.jpg', 0, '', 0.00),
(1602, 107, 'g642wngq1_2JPG.jpg', 0, '', 0.00),
(1603, 107, 'q7ucnf4t1_4JPG.jpg', 0, '', 0.00),
(1604, 107, 'ft58geq42_2JPG.jpg', 0, '', 0.00),
(1605, 107, '7000j3t6IMG_6085JPG.jpg', 0, '', 0.00),
(1606, 107, 'hpupz5xzIMG_6086JPG.jpg', 0, '', 0.00),
(1607, 107, 'i3cogznuIMG_6087JPG.jpg', 0, '', 0.00),
(1608, 107, 'q43newcaIMG_6089JPG.jpg', 0, '', 0.00),
(1609, 107, 'hjvbvvriIMG_6090JPG.jpg', 0, '', 0.00),
(1610, 107, 'amv2one3IMG_6091JPG.jpg', 0, '', 0.00),
(1611, 107, 'pcmjhmwaIMG_6092JPG.jpg', 0, '', 0.00),
(1612, 107, '8cnxgxh0IMG_6094JPG.jpg', 0, '', 0.00),
(1613, 107, 'k5qi3rudIMG_6097JPG.jpg', 0, '', 0.00),
(1614, 108, 'yyopg3y61JPG.jpg', 0, '', 0.00),
(1615, 108, '5excjsuc2___CopyJPG.jpg', 0, '', 0.00),
(1616, 108, 'oc0xy3p84JPG.jpg', 0, '', 0.00),
(1617, 108, 'udjy5rtc5JPG.jpg', 0, '', 0.00),
(1618, 108, '6vdquvsq6JPG.jpg', 0, '', 0.00),
(1619, 108, 'yh0wsb5w7JPG.jpg', 0, '', 0.00),
(1620, 108, 'uzj47dka9JPG.jpg', 0, '', 0.00),
(1621, 108, 'iso5rtxu10JPG.jpg', 0, '', 0.00),
(1622, 108, 'fgak82q511JPG.jpg', 0, '', 0.00),
(1623, 108, '70phzi7p12JPG.jpg', 0, '', 0.00),
(1624, 108, 'ne6gnxdk15JPG.jpg', 0, '', 0.00),
(1625, 108, 't76604ed17JPG.jpg', 0, '', 0.00),
(1626, 108, 'q7dhn04318JPG.jpg', 0, '', 0.00),
(1627, 108, 'acxo4ukg19JPG.jpg', 0, '', 0.00),
(1628, 108, '8ijgweey20JPG.jpg', 0, '', 0.00),
(1629, 108, '287hg05e20JPG.jpg', 0, '', 0.00),
(1630, 108, 'ro8pxi2721JPG.jpg', 0, '', 0.00),
(1631, 108, 'eoirou7r22JPG.jpg', 0, '', 0.00),
(1632, 108, '44cxshnx24JPG.jpg', 0, '', 0.00),
(1633, 108, 'fy8hik2325_2JPG.jpg', 0, '', 0.00),
(1634, 108, 'wtz3htfk27JPG.jpg', 0, '', 0.00),
(1635, 108, 'u2ysawtb28JPG.jpg', 0, '', 0.00),
(1636, 108, 'f4qfd8q529JPG.jpg', 0, '', 0.00),
(1637, 108, '355fr88b30JPG.jpg', 0, '', 0.00),
(1638, 108, 'dq2anana31JPG.jpg', 0, '', 0.00),
(1639, 108, 'gbeigzq732JPG.jpg', 0, '', 0.00),
(1640, 108, 'wrmtn67b33JPG.jpg', 0, '', 0.00),
(1641, 108, 'hzt5yqqt34JPG.jpg', 0, '', 0.00),
(1642, 108, 'xf7cvx4u35JPG.jpg', 0, '', 0.00),
(1643, 108, '8c4erjzg37JPG.jpg', 0, '', 0.00),
(1644, 108, '0s0w6en636JPG.jpg', 0, '', 0.00),
(1645, 108, '8zbpsaxf38JPG.jpg', 0, '', 0.00),
(1646, 108, 'mzfrj6kb39JPG.jpg', 0, '', 0.00),
(1647, 108, 'du4zkxir40JPG.jpg', 0, '', 0.00),
(1648, 108, '38wck70745JPG.jpg', 0, '', 0.00),
(1649, 108, 'uu6rsinm47JPG.jpg', 0, '', 0.00),
(1650, 108, '6pdum25s47JPG.jpg', 0, '', 0.00),
(1651, 108, 'ryzuy4xc48JPG.jpg', 0, '', 0.00),
(1652, 108, 'nh8jcqao51JPG.jpg', 0, '', 0.00),
(1653, 108, 'pic560xa52JPG.jpg', 0, '', 0.00),
(1654, 109, 'dkvorrkb2JPG.jpg', 0, '', 0.00),
(1655, 109, '2ir57cox3JPG.jpg', 0, '', 0.00),
(1656, 109, 'ftrjpwf05JPG.jpg', 0, '', 0.00),
(1657, 109, 'to4cn0tq7JPG.jpg', 0, '', 0.00),
(1658, 109, 'cqscv22x8JPG.jpg', 0, '', 0.00),
(1659, 109, 'z0y7skz59JPG.jpg', 0, '', 0.00),
(1660, 109, 'kcebwhca11JPG.jpg', 0, '', 0.00),
(1661, 109, 'zie376ez12JPG.jpg', 0, '', 0.00),
(1662, 109, '23uwfq7d13_2JPG.jpg', 0, '', 0.00),
(1663, 109, 'kjj4jx5v13JPG.jpg', 0, '', 0.00),
(1664, 109, 'vpdgikvy14JPG.jpg', 0, '', 0.00),
(1665, 109, 'g3v7niow16JPG.jpg', 0, '', 0.00),
(1666, 109, 'tq0uoy2i21JPG.jpg', 0, '', 0.00),
(1667, 109, 'rz4b78mh23JPG.jpg', 0, '', 0.00),
(1668, 109, '0ugscad525JPG.jpg', 0, '', 0.00),
(1669, 109, 'xuzrqoeyIMG_8557JPG.jpg', 0, '', 0.00),
(1670, 109, 'zcec43sbIMG_8558JPG.jpg', 0, '', 0.00),
(1671, 109, 'rwgxbxzh29JPG.jpg', 0, '', 0.00),
(1672, 109, 'x3uhw20j27JPG.jpg', 0, '', 0.00),
(1673, 109, 'sdoxrgji34JPG.jpg', 0, '', 0.00),
(1674, 110, 'tc2tnadi1_1JPG.jpg', 0, '', 0.00),
(1675, 110, 't0vr7q5x1_2JPG.jpg', 0, '', 0.00),
(1676, 110, '0cpghrez1_4JPG.jpg', 0, '', 0.00),
(1677, 110, '8bc3dafh2_1JPG.jpg', 0, '', 0.00),
(1678, 110, 'vrwyhzbh2_2JPG.jpg', 0, '', 0.00),
(1679, 110, 'gdtm6bhk2_3JPG.jpg', 0, '', 0.00),
(1680, 110, 'pwieyyjr3_1JPG.jpg', 0, '', 0.00),
(1681, 110, 'rytvtd283_2JPG.jpg', 0, '', 0.00),
(1682, 110, '7f0jqbzn3_3JPG.jpg', 0, '', 0.00),
(1683, 110, 'azrc67wr3_4JPG.jpg', 0, '', 0.00),
(1684, 110, '24jgavk03_5JPG.jpg', 0, '', 0.00),
(1685, 110, '3r253vuj3_6JPG.jpg', 0, '', 0.00),
(1686, 110, 'eixuqmcz3_7JPG.jpg', 0, '', 0.00),
(1687, 110, 'pinh56ie3_8JPG.jpg', 0, '', 0.00),
(1688, 111, 'euzjcttk1_1JPG.jpg', 0, '', 0.00),
(1689, 111, '4rjshttv2_5JPG.jpg', 0, '', 0.00),
(1690, 111, 'jqmyvczi2_7JPG.jpg', 0, '', 0.00),
(1691, 111, 'mr7i5rm03_3JPG.jpg', 0, '', 0.00),
(1692, 111, 'anspuap33_4JPG.jpg', 0, '', 0.00),
(1693, 111, 'nhff2s6m4_3JPG.jpg', 0, '', 0.00),
(1694, 111, 'paegw3205_1JPG.jpg', 0, '', 0.00),
(1695, 111, 'hiotmkfy5_2JPG.jpg', 0, '', 0.00),
(1696, 111, 'y5o2tf3m5_5JPG.jpg', 0, '', 0.00),
(1697, 111, 'a4w7crhv5_6JPG.jpg', 0, '', 0.00),
(1698, 111, 'cxhntb0c5_13JPG.jpg', 0, '', 0.00),
(1699, 111, '2ja4mhou6_1JPG.jpg', 0, '', 0.00),
(1700, 111, 'rgxzk0dp6_5JPG.jpg', 0, '', 0.00),
(1701, 111, 'hwdzsn0b6_3JPG.jpg', 0, '', 0.00),
(1702, 111, 'jv7qovt27_3JPG.jpg', 0, '', 0.00),
(1703, 111, 'ohchy6yw7_5JPG.jpg', 0, '', 0.00),
(1704, 111, 'ue5jwcyb7_6JPG.jpg', 0, '', 0.00),
(1705, 111, '8duiwxvt7_8JPG.jpg', 0, '', 0.00),
(1706, 111, '4bikkn5k7_9JPG.jpg', 0, '', 0.00),
(1707, 111, 'ojrc32pu7_10JPG.jpg', 0, '', 0.00),
(1708, 111, '74yju3zv7_12JPG.jpg', 0, '', 0.00),
(1709, 111, 'cvvkw7fw7_4JPG.jpg', 0, '', 0.00),
(1710, 112, 'vh3xrk6u1_1JPG.jpg', 0, '', 0.00),
(1711, 112, 'pt6ggjiz2_2JPG.jpg', 0, '', 0.00),
(1712, 112, 'j8mo2iui3_2JPG.jpg', 0, '', 0.00),
(1713, 112, 'btrggarc3_7JPG.jpg', 0, '', 0.00),
(1714, 112, 'bzfk05bv4JPG.jpg', 0, '', 0.00),
(1715, 112, 'qe0600nu5_3JPG.jpg', 0, '', 0.00),
(1716, 112, 'ax554ea36_1JPG.jpg', 0, '', 0.00),
(1717, 112, 'w3gimhacIMG_4458JPG.jpg', 0, '', 0.00),
(1718, 112, '4f2e3406IMG_4459JPG.jpg', 0, '', 0.00),
(1719, 112, '2dv4ve7hIMG_4460JPG.jpg', 0, '', 0.00),
(1720, 112, 'c6m8ubtjIMG_4461JPG.jpg', 0, '', 0.00),
(1721, 112, 'dftamarfIMG_4463JPG.jpg', 0, '', 0.00),
(1722, 112, 'u3inidsyIMG_4464JPG.jpg', 0, '', 0.00),
(1723, 112, 'vm4h3r2xIMG_4465JPG.jpg', 0, '', 0.00),
(1724, 112, 'rm7jk5ndIMG_5776JPG.jpg', 0, '', 0.00),
(1725, 112, 'cmwysykuIMG_5778JPG.jpg', 0, '', 0.00),
(1726, 112, 'hz4473umIMG_5790JPG.jpg', 0, '', 0.00),
(1727, 112, 'eutup4ekIMG_5822JPG.jpg', 0, '', 0.00),
(1728, 112, 'visa0aj4IMG_5827JPG.jpg', 0, '', 0.00),
(1729, 112, '635rcayfIMG_5828JPG.jpg', 0, '', 0.00),
(1730, 112, 'mxzvecucIMG_5829JPG.jpg', 0, '', 0.00),
(1731, 112, 'k3kens7sIMG_5830JPG.jpg', 0, '', 0.00),
(1732, 112, 'hmsf72iyIMG_5836JPG.jpg', 0, '', 0.00),
(1733, 112, 'ni87kk82IMG_5837JPG.jpg', 0, '', 0.00),
(1734, 112, 'x8ij27mwIMG_6014JPG.jpg', 0, '', 0.00),
(1735, 112, '8gz0dpxnIMG_6015JPG.jpg', 0, '', 0.00),
(1736, 112, 's30ih0tnIMG_6016JPG.jpg', 0, '', 0.00),
(1737, 112, '8e5rqdfpIMG_6026JPG.jpg', 0, '', 0.00),
(1738, 112, 't62d387vIMG_6029JPG.jpg', 0, '', 0.00),
(1739, 112, '6sts6ouwIMG_6033JPG.jpg', 0, '', 0.00),
(1740, 112, 'kdijk502IMG_6135JPG.jpg', 0, '', 0.00),
(1741, 112, 'k3ksckp3IMG_6136JPG.jpg', 0, '', 0.00),
(1742, 113, 'd4rnft8zIMG_7916JPG.jpg', 0, '', 0.00),
(1743, 113, 'qy4fexoqIMG_7917JPG.jpg', 0, '', 0.00),
(1744, 113, 'm8nm6t0aIMG_7919JPG.jpg', 0, '', 0.00),
(1745, 113, 'cgndv8uiIMG_7920JPG.jpg', 0, '', 0.00),
(1746, 113, 'du4zkxirIMG_7922JPG.jpg', 0, '', 0.00),
(1747, 113, '2anvxhxdIMG_7923JPG.jpg', 0, '', 0.00),
(1748, 113, '00cid6agIMG_7925JPG.jpg', 0, '', 0.00),
(1749, 113, 'fdcr6whuIMG_7927JPG.jpg', 0, '', 0.00),
(1750, 113, 'jmrtfpitIMG_7928JPG.jpg', 0, '', 0.00),
(1751, 113, 'g7qyfdnbIMG_7929JPG.jpg', 0, '', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `product_imgbk1`
--

CREATE TABLE `product_imgbk1` (
  `img_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `img_sequence` int(11) NOT NULL,
  `img_title` text NOT NULL,
  `price` float(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_imgbk1`
--

INSERT INTO `product_imgbk1` (`img_id`, `product_id`, `name`, `img_sequence`, `img_title`, `price`) VALUES
(90, 13, 'knyvi3um1JPG.jpg', 0, '', 0.00),
(91, 13, 'nch8jx0i2_1JPG.jpg', 0, '', 0.00),
(92, 13, 'k0vyxcvc2_2JPG.jpg', 0, '', 0.00),
(93, 13, 'pwffvec03_2JPG.jpg', 0, '', 0.00),
(94, 13, 'd6yifw3v3JPG.jpg', 0, '', 0.00),
(95, 13, '7rvuytkd4_1JPG.jpg', 0, '', 0.00),
(96, 13, 'cwoubizv5JPG.jpg', 0, '', 0.00),
(97, 13, 'e66by8yk6_2JPG.jpg', 0, '', 0.00),
(98, 13, '7ezov00u6_3JPG.jpg', 0, '', 0.00),
(99, 13, 'p2kefpvb6_4JPG.jpg', 0, '', 0.00),
(100, 13, 'ua3zk4476_5JPG.jpg', 0, '', 0.00),
(101, 13, 'i7e6s7iy6_6JPG.jpg', 0, '', 0.00),
(102, 13, '2pyuhmp36_7JPG.jpg', 0, '', 0.00),
(103, 13, 'vwkfcxd66_8JPG.jpg', 0, '', 0.00),
(104, 13, '3y2burxk6_9JPG.jpg', 0, '', 0.00),
(105, 13, 'ju3emg546_10JPG.jpg', 0, '', 0.00),
(106, 13, '3a0stbqe6_12JPG.jpg', 0, '', 0.00),
(107, 13, 'pt2t44cx6_13JPG.jpg', 0, '', 0.00),
(108, 13, '4xcy3x0t7_1JPG.jpg', 0, '', 0.00),
(109, 13, 'o5d45c7b7_2JPG.jpg', 0, '', 0.00),
(110, 14, 'a8hwojd81_2JPG.jpg', 0, '', 0.00),
(111, 14, 'iwfxf3pj1_3JPG.jpg', 0, '', 0.00),
(112, 14, 'wsze8zh62_1JPG.jpg', 0, '', 0.00),
(113, 14, 'h7wrypiz2_2JPG.jpg', 0, '', 0.00),
(114, 14, 'k7rv2kam3_4JPG.jpg', 0, '', 0.00),
(115, 14, 'iuwbr4ra3_5JPG.jpg', 0, '', 0.00),
(116, 14, 'xvqwv2ac4_2JPG.jpg', 0, '', 0.00),
(117, 14, 'ots2g78iIMG_6420JPG.jpg', 0, '', 0.00),
(118, 14, '4ps66wh2IMG_6421JPG.jpg', 0, '', 0.00),
(119, 14, 'mpvs8tkoIMG_6423JPG.jpg', 0, '', 0.00),
(120, 15, 'a7kenm3hIMG_6217JPG.jpg', 0, '', 0.00),
(121, 15, 'q36dw0jkIMG_6218JPG.jpg', 0, '', 0.00),
(122, 15, '3oin3ge0IMG_6219JPG.jpg', 0, '', 0.00),
(123, 15, 'uyfvkqwhIMG_6223JPG.jpg', 0, '', 0.00),
(124, 15, '2d3ui4nhIMG_6225JPG.jpg', 0, '', 0.00),
(125, 15, '5ip472nzIMG_6226JPG.jpg', 0, '', 0.00),
(126, 15, 'teabwkp3IMG_6228JPG.jpg', 0, '', 0.00),
(127, 15, '8jcqaoyyIMG_6230JPG.jpg', 0, '', 0.00),
(128, 15, '8nb8ko6oIMG_6234JPG.jpg', 0, '', 0.00),
(129, 15, 'qr4obt2zIMG_6235JPG.jpg', 0, '', 0.00),
(130, 15, '8uhm3s66IMG_6237JPG.jpg', 0, '', 0.00),
(131, 15, '7kk824uzIMG_6238JPG.jpg', 0, '', 0.00),
(132, 15, 'bj4mh2j6IMG_6244JPG.jpg', 0, '', 0.00),
(133, 15, '742p2zpiIMG_6245JPG.jpg', 0, '', 0.00),
(134, 16, '2ztr2dsh1_2JPG.jpg', 0, '', 0.00),
(135, 16, '3n7eb0u52_3JPG.jpg', 0, '', 0.00),
(136, 16, 'zihg0j40IMG_5691JPG.jpg', 0, '', 0.00),
(137, 16, 'k5ish0fcIMG_5693JPG.jpg', 0, '', 0.00),
(138, 16, 'd3xanspuIMG_5695JPG.jpg', 0, '', 0.00),
(139, 16, 'widdoc8nIMG_5700JPG.jpg', 0, '', 0.00),
(140, 16, 'twjvwepqIMG_5701JPG.jpg', 0, '', 0.00),
(141, 16, 'azgz72coIMG_5702JPG.jpg', 0, '', 0.00),
(142, 16, 'icg5bbetIMG_5703JPG.jpg', 0, '', 0.00),
(143, 16, 'mj3w5sutIMG_5714JPG.jpg', 0, '', 0.00),
(144, 17, 'tdckb6fx1_1JPG.jpg', 0, '', 0.00),
(145, 17, 'mwse3zhs1_2JPG.jpg', 0, '', 0.00),
(146, 17, 'hiaq4bmj2JPG.jpg', 0, '', 0.00),
(147, 17, 'rtfpitmh3JPG.jpg', 0, '', 0.00),
(148, 17, '40gye6n54_1JPG.jpg', 0, '', 0.00),
(149, 17, 'cu5022074_2JPG.jpg', 0, '', 0.00),
(150, 17, 't03ka6j3IMG_0537JPG.jpg', 0, '', 0.00),
(151, 17, '3aiq8gqaIMG_0549JPG.jpg', 0, '', 0.00),
(152, 17, 'ws7s3jumIMG_0550JPG.jpg', 0, '', 0.00),
(153, 17, 'wseiq8amIMG_0552JPG.jpg', 0, '', 0.00),
(154, 17, 'mstwt0a2IMG_0557JPG.jpg', 0, '', 0.00),
(155, 18, 'd7zzjfkc1_2JPG.jpg', 0, '', 0.00),
(156, 18, 'ow5h35rq1JPG.jpg', 0, '', 0.00),
(157, 18, 'qvz0dwj32JPG.jpg', 0, '', 0.00),
(158, 18, 'dkayuhe44_1JPG.jpg', 0, '', 0.00),
(159, 18, 'p2kefpvb4_2JPG.jpg', 0, '', 0.00),
(160, 18, 'vbvh2r644_3JPG.jpg', 0, '', 0.00),
(161, 18, '8iq2desr4_4JPG.jpg', 0, '', 0.00),
(162, 18, 'on3j5j7o5JPG.jpg', 0, '', 0.00),
(163, 18, 'w3amvgdf6JPG.jpg', 0, '', 0.00),
(164, 18, '4uve83tz7JPG.jpg', 0, '', 0.00),
(165, 18, '2zi6hr6z8_1JPG.jpg', 0, '', 0.00),
(166, 18, 'nzbpzudf8_2JPG.jpg', 0, '', 0.00),
(167, 18, 'pdgikvy48_3JPG.jpg', 0, '', 0.00),
(168, 18, 'qm85ud429JPG.jpg', 0, '', 0.00),
(169, 18, '5kw7tmha10JPG.jpg', 0, '', 0.00),
(170, 18, 'krt8k6cpIMG_4076JPG.jpg', 0, '', 0.00),
(171, 18, 'nc3xg78pIMG_4115JPG.jpg', 0, '', 0.00),
(172, 18, 'wkern5ovIMG_4146JPG.jpg', 0, '', 0.00),
(173, 18, '53h4sj3zIMG_4156JPG.jpg', 0, '', 0.00),
(174, 18, 'o66iyergIMG_4185JPG.jpg', 0, '', 0.00),
(175, 19, 'bmcp2kefDSC_0003JPG.jpg', 0, '', 0.00),
(176, 19, 'myevpvmiDSC_0006JPG.jpg', 0, '', 0.00),
(177, 19, 'wkws7zpzDSC_0007JPG.jpg', 0, '', 0.00),
(178, 19, 'ar0tnhxyDSC_0008JPG.jpg', 0, '', 0.00),
(179, 19, '2xksniygDSC_0010JPG.jpg', 0, '', 0.00),
(180, 19, 'z0ad5akuDSC_0011JPG.jpg', 0, '', 0.00),
(181, 19, 'r5efzfvdDSC_0012JPG.jpg', 0, '', 0.00),
(182, 19, 'd2w660qpDSC_0015JPG.jpg', 0, '', 0.00),
(183, 19, 'bzjtotzoDSC_0016JPG.jpg', 0, '', 0.00),
(184, 19, 'sx5oafv3DSC_0018JPG.jpg', 0, '', 0.00),
(185, 19, 'a3tkyccsDSC_0019JPG.jpg', 0, '', 0.00),
(186, 19, 't62d387vDSC_0021JPG.jpg', 0, '', 0.00),
(187, 19, 'kbhe6sm7DSC_0022JPG.jpg', 0, '', 0.00),
(188, 19, 'b2gqejqrDSC_0023JPG.jpg', 0, '', 0.00),
(189, 19, 'nttdgf82DSC_0081JPG.jpg', 0, '', 0.00),
(190, 19, 'dja3z6fcDSC_0100JPG.jpg', 0, '', 0.00),
(191, 19, '6kpz2dmsDSC_0111JPG.jpg', 0, '', 0.00),
(192, 19, 'syvtgsqgDSC_0117JPG.jpg', 0, '', 0.00),
(193, 19, 'gfuy55wtDSC_0118JPG.jpg', 0, '', 0.00),
(194, 19, 'y3ic28xdDSC_0123JPG.jpg', 0, '', 0.00),
(195, 20, '7hryfrc31_2JPG.jpg', 0, '', 0.00),
(196, 20, 'fsu0oy581_8JPG.jpg', 0, '', 0.00),
(197, 20, 'xbnoj58g1JPG.jpg', 0, '', 0.00),
(198, 20, 'bavaovmq2JPG.jpg', 0, '', 0.00),
(199, 20, '3shqpo3f3JPG.jpg', 0, '', 0.00),
(200, 20, 'sds6e48a4_6JPG.jpg', 0, '', 0.00),
(201, 20, 'jbi73g4b4_8JPG.jpg', 0, '', 0.00),
(202, 20, 'kvvyit764_10JPG.jpg', 0, '', 0.00),
(203, 20, 'og7n0bsf4_14JPG.jpg', 0, '', 0.00),
(204, 20, 'g2dvim6q7_1JPG.jpg', 0, '', 0.00),
(205, 20, 'oxobcmpe7_2JPG.jpg', 0, '', 0.00),
(206, 20, 'dv887k6j7_3JPG.jpg', 0, '', 0.00),
(207, 20, '30742p2z7_4JPG.jpg', 0, '', 0.00),
(208, 20, '77zbipxg7_6JPG.jpg', 0, '', 0.00),
(209, 20, '0py232qg7_7JPG.jpg', 0, '', 0.00),
(210, 20, '70pvpapz7_8JPG.jpg', 0, '', 0.00),
(211, 20, 'qimho2zw7_9JPG.jpg', 0, '', 0.00),
(212, 20, 'zk0reii57_10JPG.jpg', 0, '', 0.00),
(213, 20, 'op54qtob7_11JPG.jpg', 0, '', 0.00),
(214, 20, 'ycx3fwba7_12JPG.jpg', 0, '', 0.00),
(215, 21, 'yqj3f37zIMG_5078JPG.jpg', 0, '', 0.00),
(216, 21, '36udc53aIMG_5079JPG.jpg', 0, '', 0.00),
(217, 21, 'vuynzw7tIMG_5080JPG.jpg', 0, '', 0.00),
(218, 21, 's46nxyh7IMG_5081JPG.jpg', 0, '', 0.00),
(219, 21, 'zxfb3e2bIMG_5082JPG.jpg', 0, '', 0.00),
(220, 21, 'sdoq5zj4IMG_5083JPG.jpg', 0, '', 0.00),
(221, 21, 'qejxcu5tIMG_5084JPG.jpg', 0, '', 0.00),
(222, 21, 'hpy48am6IMG_5085JPG.jpg', 0, '', 0.00),
(223, 21, 'g7u720c3IMG_5086JPG.jpg', 0, '', 0.00),
(224, 21, 'acfwtz3hIMG_5088JPG.jpg', 0, '', 0.00),
(225, 21, 'ftnpr08jIMG_5089JPG.jpg', 0, '', 0.00),
(226, 21, 'si5aawpvIMG_5090JPG.jpg', 0, '', 0.00),
(227, 21, 'yh32z7uiIMG_5091JPG.jpg', 0, '', 0.00),
(228, 21, 'dhrarqhoIMG_5092JPG.jpg', 0, '', 0.00),
(229, 21, 'i55cs4o3IMG_5093JPG.jpg', 0, '', 0.00),
(230, 21, 'gj37307wIMG_5094JPG.jpg', 0, '', 0.00),
(231, 21, '26pahtpfIMG_5095JPG.jpg', 0, '', 0.00),
(232, 21, '4wt0ps2xIMG_5096JPG.jpg', 0, '', 0.00),
(233, 21, 'n7mb6n0qIMG_5097JPG.jpg', 0, '', 0.00),
(234, 21, 'ajxf7x66IMG_5098JPG.jpg', 0, '', 0.00),
(235, 22, 'ka6j34jn1_1JPG.jpg', 0, '', 0.00),
(236, 22, 'p544ifsr1_2JPG.jpg', 0, '', 0.00),
(237, 22, 'bgoowgu21_4JPG.jpg', 0, '', 0.00),
(238, 22, 's5yinhjv2_1JPG.jpg', 0, '', 0.00),
(239, 22, 'ok2es6st2_2JPG.jpg', 0, '', 0.00),
(240, 22, 'di0f4f2e3_2JPG.jpg', 0, '', 0.00),
(241, 22, 'mr4ronfpIMG_6252JPG.jpg', 0, '', 0.00),
(242, 22, 'mypty8pcIMG_6253JPG.jpg', 0, '', 0.00),
(243, 22, 'jd5opc80IMG_6254JPG.jpg', 0, '', 0.00),
(244, 22, 'xm3gmnjhIMG_6259JPG.jpg', 0, '', 0.00),
(245, 22, 'hysot6acIMG_6268JPG.jpg', 0, '', 0.00),
(246, 22, '5ghdeptdIMG_6271JPG.jpg', 0, '', 0.00),
(247, 22, '0swcsmwsIMG_6272JPG.jpg', 0, '', 0.00),
(248, 22, 'a2hrvoa7IMG_6274JPG.jpg', 0, '', 0.00),
(249, 23, 'zwvoyamk1_1JPG.jpg', 0, '', 0.00),
(250, 23, 'dxub3oty1_3JPG.jpg', 0, '', 0.00),
(251, 23, 'w04as2qh2_2JPG.jpg', 0, '', 0.00),
(252, 23, 'jawi56w32_5JPG.jpg', 0, '', 0.00),
(253, 23, '4s270ha83_2JPG.jpg', 0, '', 0.00),
(254, 23, '0ym3oqx03_3JPG.jpg', 0, '', 0.00),
(255, 23, '8khoob5m4_1JPG.jpg', 0, '', 0.00),
(256, 23, 'k3ojupwf4_2JPG.jpg', 0, '', 0.00),
(257, 23, 'n5ynybwm5_1JPG.jpg', 0, '', 0.00),
(258, 23, 'k7rhdssb5_2JPG.jpg', 0, '', 0.00),
(259, 23, 'vtf6g8rg5_3JPG.jpg', 0, '', 0.00),
(260, 23, '56qy0ovt5_4JPG.jpg', 0, '', 0.00),
(261, 23, 'mufhkmg26_2JPG.jpg', 0, '', 0.00),
(262, 23, 'zo24dcyeIMG_9616JPG.jpg', 0, '', 0.00),
(263, 23, 'xgtn3gsqIMG_9622JPG.jpg', 0, '', 0.00),
(264, 23, 'cg5bbeteIMG_9625JPG.jpg', 0, '', 0.00),
(265, 23, '4mor5vefIMG_9629JPG.jpg', 0, '', 0.00),
(266, 23, '8qymhysoIMG_9630JPG.jpg', 0, '', 0.00),
(267, 23, 'jen7epqmIMG_9631JPG.jpg', 0, '', 0.00),
(268, 23, 'k4pnagvkIMG_9699JPG.jpg', 0, '', 0.00),
(269, 24, 'spuoevphIMG_0994JPG.jpg', 0, '', 0.00),
(270, 24, 'v3h075aaIMG_0995JPG.jpg', 0, '', 0.00),
(271, 24, 'ut2bkfyfIMG_0996JPG.jpg', 0, '', 0.00),
(272, 24, 'i8zy48ocIMG_1000JPG.jpg', 0, '', 0.00),
(273, 24, '57x6swrbIMG_1001JPG.jpg', 0, '', 0.00),
(274, 24, 'fy0arc6mIMG_1004JPG.jpg', 0, '', 0.00),
(275, 24, 'gec0qzxwIMG_1010JPG.jpg', 0, '', 0.00),
(276, 24, 'k3h0tfhsIMG_1011JPG.jpg', 0, '', 0.00),
(277, 24, 'gnrdfvtiIMG_1012JPG.jpg', 0, '', 0.00),
(278, 24, 'ig46ggx7IMG_1013JPG.jpg', 0, '', 0.00),
(279, 24, 'rtx87632IMG_1014JPG.jpg', 0, '', 0.00),
(280, 24, 'schxkoofIMG_1016JPG.jpg', 0, '', 0.00),
(281, 24, '5ad2wsh8IMG_1021JPG.jpg', 0, '', 0.00),
(282, 24, '5xmh6e4uIMG_1022JPG.jpg', 0, '', 0.00),
(283, 24, '5xpgaycjIMG_1023JPG.jpg', 0, '', 0.00),
(284, 24, 'zfyqxt6kIMG_1024JPG.jpg', 0, '', 0.00),
(285, 24, 'fdqokvscIMG_1025JPG.jpg', 0, '', 0.00),
(286, 24, 'ad5oangjIMG_1027JPG.jpg', 0, '', 0.00),
(287, 25, '4visvch21_1jpg.jpg', 0, '', 0.00),
(288, 25, 'a4q4zakj1_3JPG.jpg', 0, '', 0.00),
(289, 25, 'uovcz4f62_2JPG.jpg', 0, '', 0.00),
(290, 25, '3hq2rkps3_1JPG.jpg', 0, '', 0.00),
(291, 25, 'bdtiftdd3JPG.jpg', 0, '', 0.00),
(292, 25, 'oygzfoso4_2JPG.jpg', 0, '', 0.00),
(293, 25, 'm6baynh84_4JPG.jpg', 0, '', 0.00),
(294, 25, 'tmyif3pc4_5JPG.jpg', 0, '', 0.00),
(295, 25, 'rauvpk2y4jpg.jpg', 0, '', 0.00),
(296, 25, 'ny34juzn5_2JPG.jpg', 0, '', 0.00),
(297, 25, 'zyuhzeuvIMG_20160320_WA0089jpg.jpg', 0, '', 0.00),
(298, 26, '70tusuwpIMG_5316JPG.jpg', 0, '', 0.00),
(299, 26, 'onhu8a0hIMG_5317JPG.jpg', 0, '', 0.00),
(300, 26, 'bqbph32mIMG_5318JPG.jpg', 0, '', 0.00),
(301, 26, 'rjz8e5rqIMG_5320JPG.jpg', 0, '', 0.00),
(302, 26, 'c6wksgfnIMG_5321JPG.jpg', 0, '', 0.00),
(303, 26, '0baamrmfIMG_5322JPG.jpg', 0, '', 0.00),
(304, 26, '8hiyruxiIMG_5323JPG.jpg', 0, '', 0.00),
(305, 26, 'ycnqhrp5IMG_5324JPG.jpg', 0, '', 0.00),
(306, 26, 'e2fibx7vIMG_5325JPG.jpg', 0, '', 0.00),
(307, 26, 'c3rdwrswIMG_5326JPG.jpg', 0, '', 0.00),
(308, 26, '4a7ds6mpIMG_5329JPG.jpg', 0, '', 0.00),
(309, 26, 'ze0e06fqIMG_5330JPG.jpg', 0, '', 0.00),
(310, 26, 'nvn5y8aiIMG_5331JPG.jpg', 0, '', 0.00),
(311, 26, 'jj0zzgo2IMG_5332JPG.jpg', 0, '', 0.00),
(312, 26, 'gkm8xx5yIMG_5336JPG.jpg', 0, '', 0.00),
(313, 26, 'osy6rp5uIMG_5340JPG.jpg', 0, '', 0.00),
(314, 26, 'kqtqgou7IMG_5343JPG.jpg', 0, '', 0.00),
(315, 26, 'd3cu8kyqIMG_5345JPG.jpg', 0, '', 0.00),
(316, 26, 'dg0qvk4zIMG_5347JPG.jpg', 0, '', 0.00),
(317, 26, '0z0oai7wIMG_5350___CopyJPG.jpg', 0, '', 0.00),
(318, 27, 'ensmhhce1_1JPG.jpg', 0, '', 0.00),
(319, 27, 'zqmfrbei1_2JPG.jpg', 0, '', 0.00),
(320, 27, 'qvkcmf8y2_1JPG.jpg', 0, '', 0.00),
(321, 27, 'hfqfqc6f2_2JPG.jpg', 0, '', 0.00),
(322, 27, 'x07fzxf32_3JPG.jpg', 0, '', 0.00),
(323, 27, 'mscyevb62JPG.jpg', 0, '', 0.00),
(324, 27, '4i03yk8a3_1JPG.jpg', 0, '', 0.00),
(325, 27, 'xzh384ic3_2JPG.jpg', 0, '', 0.00),
(326, 27, 'z3szae2m4JPG.jpg', 0, '', 0.00),
(327, 27, '8zo6yb755_1JPG.jpg', 0, '', 0.00),
(328, 27, 'jo4qx3jj5_3JPG.jpg', 0, '', 0.00),
(329, 27, 'v8rdmsij6_1JPG.jpg', 0, '', 0.00),
(330, 27, 'p45wf4bt6_2JPG.jpg', 0, '', 0.00),
(331, 27, 'buyn7iot6_3JPG.jpg', 0, '', 0.00),
(332, 27, 'uukcebwh6_4JPG.jpg', 0, '', 0.00),
(333, 27, 'zs4vbzuv6_6JPG.jpg', 0, '', 0.00),
(334, 27, 'bc3dafhz7_1JPG.jpg', 0, '', 0.00),
(335, 27, 'ke2ke0y47_2JPG.jpg', 0, '', 0.00),
(336, 27, '3tsd6v5mIMG_2568JPG.jpg', 0, '', 0.00),
(337, 27, 'weeeatkgIMG_2578JPG.jpg', 0, '', 0.00),
(338, 28, 'zknkhirk1JPG.jpg', 0, '', 0.00),
(339, 28, 'gecffrf82_1JPG.jpg', 0, '', 0.00),
(340, 28, 'kjnv22c63_1JPG.jpg', 0, '', 0.00),
(341, 28, 'jkxbgxwg4JPG.jpg', 0, '', 0.00),
(342, 28, 'pzr873cj5_2JPG.jpg', 0, '', 0.00),
(343, 28, 'br0n00xm5_3JPG.jpg', 0, '', 0.00),
(344, 28, 'msf72iyy6_1JPG.jpg', 0, '', 0.00),
(345, 28, 'ic5kqpsc6_4JPG.jpg', 0, '', 0.00),
(346, 28, '5wbo3q2a6_5JPG.jpg', 0, '', 0.00),
(347, 28, '4azdnfpm7_2JPG.jpg', 0, '', 0.00),
(348, 28, 'e3wufvo37_3JPG.jpg', 0, '', 0.00),
(349, 29, 'tjx8w0881_1JPG.jpg', 0, '', 0.00),
(350, 29, 'ek8kokdc1_2JPG.jpg', 0, '', 0.00),
(351, 29, '05e8at5x2JPG.jpg', 0, '', 0.00),
(352, 29, 'ps2cymvg3JPG.jpg', 0, '', 0.00),
(353, 29, 'hp2vreth4JPG.jpg', 0, '', 0.00),
(354, 29, 'iwxh4h74IMG_6329JPG.jpg', 0, '', 0.00),
(355, 29, 't7svxekjIMG_6330JPG.jpg', 0, '', 0.00),
(356, 29, '85dbj7rpIMG_6331JPG.jpg', 0, '', 0.00),
(357, 29, 'biht40dtIMG_6332JPG.jpg', 0, '', 0.00),
(358, 29, 'zpvwv5zuIMG_6338JPG.jpg', 0, '', 0.00),
(359, 29, '2t44cxshIMG_6339JPG.jpg', 0, '', 0.00),
(360, 29, 'ionh8x0iIMG_6340JPG.jpg', 0, '', 0.00),
(361, 30, 'hjeyrybc1_1JPG.jpg', 0, '', 0.00),
(362, 30, 'zvs0mufh1_2JPG.jpg', 0, '', 0.00),
(363, 30, 'yvs87bgv1_3JPG.jpg', 0, '', 0.00),
(364, 30, '6q6qbk8g2JPG.jpg', 0, '', 0.00),
(365, 30, 'qmihtiq53_1JPG.jpg', 0, '', 0.00),
(366, 30, 'a4ma2ee23_2JPG.jpg', 0, '', 0.00),
(367, 30, 'newqy0a53_3JPG.jpg', 0, '', 0.00),
(368, 30, 'dwc35gdzIMG_1203JPG.jpg', 0, '', 0.00),
(369, 30, 'hfbz8ufgIMG_1207JPG.jpg', 0, '', 0.00),
(370, 30, 'igf4qt2zIMG_1209JPG.jpg', 0, '', 0.00),
(371, 30, 'zgg22qosIMG_1210JPG.jpg', 0, '', 0.00),
(372, 30, 'y34juzn3IMG_1211JPG.jpg', 0, '', 0.00),
(373, 30, 'qkimz7rdIMG_1212JPG.jpg', 0, '', 0.00),
(374, 30, '7pxqnotwIMG_1215JPG.jpg', 0, '', 0.00),
(375, 30, 'qt8zd8pxIMG_1216JPG.jpg', 0, '', 0.00),
(376, 30, 'z7o0mch2IMG_1217JPG.jpg', 0, '', 0.00),
(377, 30, 'gcefabpzIMG_1219JPG.jpg', 0, '', 0.00),
(378, 30, 'ssezsu4nIMG_1221JPG.jpg', 0, '', 0.00),
(379, 30, 'cvoyh704IMG_1229JPG.jpg', 0, '', 0.00),
(380, 30, 'wpdu7ddaIMG_1230JPG.jpg', 0, '', 0.00),
(381, 31, '2bdtiftd1_4JPG.jpg', 0, '', 0.00),
(382, 31, '26po6k7rIMG_6087JPG.jpg', 0, '', 0.00),
(383, 31, 'pu6xk3yh1_2JPG.jpg', 0, '', 0.00),
(384, 31, '334o3nbrIMG_6097JPG.jpg', 0, '', 0.00),
(385, 31, '8tedg4heIMG_6092JPG.jpg', 0, '', 0.00),
(386, 31, 'xuqmczs8IMG_6094JPG.jpg', 0, '', 0.00),
(387, 31, 'koeoqc4vIMG_6085JPG.jpg', 0, '', 0.00),
(388, 31, '4k8yyn35IMG_6090JPG.jpg', 0, '', 0.00),
(389, 31, 'bc6ihc6mIMG_6091JPG.jpg', 0, '', 0.00),
(390, 31, 'n4ycg8giIMG_6086JPG.jpg', 0, '', 0.00),
(391, 31, 'as80equg2_2JPG.jpg', 0, '', 0.00),
(392, 31, 'a2s3usubIMG_6089JPG.jpg', 0, '', 0.00),
(393, 32, 'vuytkd771JPG.jpg', 0, '', 0.00),
(394, 32, 's3jumxbu2___CopyJPG.jpg', 0, '', 0.00),
(395, 32, '2jpwtqx42JPG.jpg', 0, '', 0.00),
(396, 32, '6fqfcnfw3JPG.jpg', 0, '', 0.00),
(397, 32, '6py5ukuo4JPG.jpg', 0, '', 0.00),
(398, 32, '53pq8jgs5JPG.jpg', 0, '', 0.00),
(399, 32, 'bibuy8hq6JPG.jpg', 0, '', 0.00),
(400, 32, 'b5fgayxu7JPG.jpg', 0, '', 0.00),
(401, 32, '5txg08jg8JPG.jpg', 0, '', 0.00),
(402, 32, 'xxxd6dmw9JPG.jpg', 0, '', 0.00),
(403, 32, 'csfer5pe10JPG.jpg', 0, '', 0.00),
(404, 32, 'e0hrpjxq11JPG.jpg', 0, '', 0.00),
(405, 32, 'ndshcdme12JPG.jpg', 0, '', 0.00),
(406, 32, 'b3342ses13JPG.jpg', 0, '', 0.00),
(407, 32, '8z2vrsi814JPG.jpg', 0, '', 0.00),
(408, 32, '8ky4xxo015JPG.jpg', 0, '', 0.00),
(409, 32, '37h5o6an16JPG.jpg', 0, '', 0.00),
(410, 32, 'toq85r0c17JPG.jpg', 0, '', 0.00),
(411, 32, '3ruycnx218JPG.jpg', 0, '', 0.00),
(412, 32, '83i2wv8r19JPG.jpg', 0, '', 0.00),
(413, 33, '7dz6rhke2JPG.jpg', 0, '', 0.00),
(414, 33, 'b3k6nnfw3JPG.jpg', 0, '', 0.00),
(415, 33, 'uam25z4c4JPG.jpg', 0, '', 0.00),
(416, 33, 'sjamdbdt5JPG.jpg', 0, '', 0.00),
(417, 33, 'o5ayxgip6JPG.jpg', 0, '', 0.00),
(418, 33, 'swdz6dss7JPG.jpg', 0, '', 0.00),
(419, 33, 'hr6ex4yc8JPG.jpg', 0, '', 0.00),
(420, 33, 'eghszbmn9JPG.jpg', 0, '', 0.00),
(421, 33, 'wgtupwt410JPG.jpg', 0, '', 0.00),
(422, 33, 'jvi3nzf511JPG.jpg', 0, '', 0.00),
(423, 33, 'tb0q7idd12JPG.jpg', 0, '', 0.00),
(424, 33, '8qg2rkb313_2JPG.jpg', 0, '', 0.00),
(425, 33, 'ke8wcywt13JPG.jpg', 0, '', 0.00),
(426, 33, 'r8ccy7ke14JPG.jpg', 0, '', 0.00),
(427, 33, '00rtfw3a15JPG.jpg', 0, '', 0.00),
(428, 33, '2mm05wpk16JPG.jpg', 0, '', 0.00),
(429, 33, 'fveqrp3p20JPG.jpg', 0, '', 0.00),
(430, 33, 'k3eoz3ss21JPG.jpg', 0, '', 0.00),
(431, 33, 'r00d3oes23JPG.jpg', 0, '', 0.00),
(432, 33, 'ozkgorgu25JPG.jpg', 0, '', 0.00),
(433, 34, '4cft2ixa1_1JPG.jpg', 0, '', 0.00),
(434, 34, '8hi6dbxw1_2JPG.jpg', 0, '', 0.00),
(435, 34, 'itactnmi1_4JPG.jpg', 0, '', 0.00),
(436, 34, '5ppmr4ro2_1JPG.jpg', 0, '', 0.00),
(437, 34, '7swjpt272_2JPG.jpg', 0, '', 0.00),
(438, 34, 'rfx4rrew2_3JPG.jpg', 0, '', 0.00),
(439, 34, 'wkvmnjpm3_1JPG.jpg', 0, '', 0.00),
(440, 34, '3rr7tiqr3_2JPG.jpg', 0, '', 0.00),
(441, 34, 'gfqz0jp43_3JPG.jpg', 0, '', 0.00),
(442, 34, '7dhn043t3_4JPG.jpg', 0, '', 0.00),
(443, 34, 'qrphetaf3_5JPG.jpg', 0, '', 0.00),
(444, 34, 'obfd7ija3_6JPG.jpg', 0, '', 0.00),
(445, 34, 'hykdw8cn3_7JPG.jpg', 0, '', 0.00),
(446, 34, '0yfd0ziz3_8JPG.jpg', 0, '', 0.00),
(447, 35, 'rw2uto731_1JPG.jpg', 0, '', 0.00),
(448, 35, 'j6o2mtnk1_3JPG.jpg', 0, '', 0.00),
(449, 35, 'r6by0e451_4JPG.jpg', 0, '', 0.00),
(450, 35, 'ab7xo86e1_5JPG.jpg', 0, '', 0.00),
(451, 35, '3skvwkt22_4JPG.jpg', 0, '', 0.00),
(452, 35, '6b6mt4jc2_5JPG.jpg', 0, '', 0.00),
(453, 35, 'xb8k2vg22_6JPG.jpg', 0, '', 0.00),
(454, 35, 'uws7eerd2_7JPG.jpg', 0, '', 0.00),
(455, 35, 'gdtzv3yv3_1JPG.jpg', 0, '', 0.00),
(456, 35, 'njk8apbz3_3JPG.jpg', 0, '', 0.00),
(457, 35, 'ptvpsnfm3_4JPG.jpg', 0, '', 0.00),
(458, 35, '44foamu84_3JPG.jpg', 0, '', 0.00),
(459, 35, 'ha8hwojd4_6JPG.jpg', 0, '', 0.00),
(460, 35, '4g680z7o5_1JPG.jpg', 0, '', 0.00),
(461, 35, 'dnpgaknr5_2JPG.jpg', 0, '', 0.00),
(462, 35, 'be8pct4x5_5JPG.jpg', 0, '', 0.00),
(463, 35, 'zuam25z45_6JPG.jpg', 0, '', 0.00),
(464, 35, 'qpopq7cv5_8JPG.jpg', 0, '', 0.00),
(465, 35, 'jwpghksj5_13JPG.jpg', 0, '', 0.00),
(466, 35, 'k57givt86_1JPG.jpg', 0, '', 0.00),
(467, 36, 'q6tuhwoc1_1JPG.jpg', 0, '', 0.00),
(468, 36, 'wtxxaxqy1_8JPG.jpg', 0, '', 0.00),
(469, 36, '7umd30wy2_2JPG.jpg', 0, '', 0.00),
(470, 36, 'i732fiw82_3JPG.jpg', 0, '', 0.00),
(471, 36, 'yx55qphm3_1JPG.jpg', 0, '', 0.00),
(472, 36, 'mrhu4w743_2JPG.jpg', 0, '', 0.00),
(473, 36, '5znv47j33_6JPG.jpg', 0, '', 0.00),
(474, 36, '77ebt8pn3_7JPG.jpg', 0, '', 0.00),
(475, 36, 'kj7yo40p3_8JPG.jpg', 0, '', 0.00),
(476, 36, 'fw7quy5j3_12JPG.jpg', 0, '', 0.00),
(477, 36, '63yozs044JPG.jpg', 0, '', 0.00),
(478, 36, 'uvhkv6q65_1JPG.jpg', 0, '', 0.00),
(479, 36, 'q3o7vfjb5_3JPG.jpg', 0, '', 0.00),
(480, 36, '5zfap76b6_1JPG.jpg', 0, '', 0.00),
(481, 36, 'mqe8sh006_2JPG.jpg', 0, '', 0.00),
(482, 36, 'twnwykd46_3JPG.jpg', 0, '', 0.00),
(483, 36, 'iw8feubw6_4JPG.jpg', 0, '', 0.00),
(484, 36, 'b2kbscg56_5JPG.jpg', 0, '', 0.00),
(485, 36, 'd3qjz2au6_6JPG.jpg', 0, '', 0.00),
(486, 36, 'rbaowtc86_7JPG.jpg', 0, '', 0.00),
(487, 37, 'wd7ze862IMG_7916JPG.jpg', 0, '', 0.00),
(488, 37, 'eu6x6d7zIMG_7917JPG.jpg', 0, '', 0.00),
(489, 37, '8in7fimbIMG_7919JPG.jpg', 0, '', 0.00),
(490, 37, 'vbet6onbIMG_7920JPG.jpg', 0, '', 0.00),
(491, 37, '4mag36kmIMG_7922JPG.jpg', 0, '', 0.00),
(492, 37, 'cjsgm8fzIMG_7923JPG.jpg', 0, '', 0.00),
(493, 37, 'is635ywqIMG_7925JPG.jpg', 0, '', 0.00),
(494, 37, 'ir324r8cIMG_7927JPG.jpg', 0, '', 0.00),
(495, 37, 'px8wu4wfIMG_7928JPG.jpg', 0, '', 0.00),
(496, 37, 'uty5ciatIMG_7929JPG.jpg', 0, '', 0.00),
(497, 38, 'kibn8nsbDSC_0002jpg.jpg', 0, '', 0.00),
(498, 38, 'as8f3hcrDSC_0005jpg.jpg', 0, '', 0.00),
(499, 38, '3jnzhbgvDSC_0199jpg.jpg', 0, '', 0.00),
(500, 38, 'mpkgaozkDSC_0200jpg.jpg', 0, '', 0.00),
(501, 38, 'accewcvjDSC_0241jpg.jpg', 0, '', 0.00),
(502, 38, 'sg7joifqDSC_0288jpg.jpg', 0, '', 0.00),
(503, 38, 'hetaf5fxDSC_1627jpg.jpg', 0, '', 0.00),
(504, 38, 'qgrtcxzpDSC_1628jpg.jpg', 0, '', 0.00),
(505, 38, 'xij2tw56DSC_1640jpg.jpg', 0, '', 0.00),
(506, 38, '0oykyj8zDSC_1647jpg.jpg', 0, '', 0.00),
(507, 38, 'xof6jkktDSC_1650jpg.jpg', 0, '', 0.00),
(508, 38, 'chnnfbbkDSC_1721___Copyjpg.jpg', 0, '', 0.00),
(509, 38, '0huurufkDSC_1721jpg.jpg', 0, '', 0.00),
(510, 38, '565a3eomDSC_1722jpg.jpg', 0, '', 0.00),
(511, 38, '77zbipxgDSC_1729jpg.jpg', 0, '', 0.00),
(512, 38, 'na5xbrihDSC_1804jpg.jpg', 0, '', 0.00),
(513, 38, 'k3pqf5wsDSC_1956jpg.jpg', 0, '', 0.00),
(514, 38, 'z82zwwa8DSC_2052jpg.jpg', 0, '', 0.00),
(515, 38, 'xx2tehb2DSC_3847jpg.jpg', 0, '', 0.00),
(516, 38, 'x3j5xwgfDSC_3850jpg.jpg', 0, '', 0.00),
(517, 39, 'wtn6m0njDSC_0039_copyjpg.jpg', 0, '', 0.00),
(518, 39, 'ydys5vs4DSC_4924jpg.jpg', 0, '', 0.00),
(519, 39, 'amajupptDSC_4965jpg.jpg', 0, '', 0.00),
(520, 39, 'won3rrz7DSC_4971jpg.jpg', 0, '', 0.00),
(521, 39, '608umj7dDSC_4975jpg.jpg', 0, '', 0.00),
(522, 39, 'mz7rdep7DSC_4982jpg.jpg', 0, '', 0.00),
(523, 39, 'ykuyu6ogDSC_5028jpg.jpg', 0, '', 0.00),
(524, 39, 'hrkqzus5DSC_5036jpg.jpg', 0, '', 0.00),
(525, 39, '4r8ccy7kDSC_5046jpg.jpg', 0, '', 0.00),
(526, 39, 'wsmpgh63DSC_5132jpg.jpg', 0, '', 0.00),
(527, 40, '7z7xa4q4IMG_3211JPG.jpg', 0, '', 0.00),
(528, 40, 'k36oubwpIMG_3212JPG.jpg', 0, '', 0.00),
(529, 40, 'evfr8um5IMG_3217JPG.jpg', 0, '', 0.00),
(530, 40, '2di0f4f2IMG_3218JPG.jpg', 0, '', 0.00),
(531, 40, '4bqisskzIMG_3221JPG.jpg', 0, '', 0.00),
(532, 40, 'pygst7raIMG_3222JPG.jpg', 0, '', 0.00),
(533, 40, '8nbuvvpdIMG_3224JPG.jpg', 0, '', 0.00),
(534, 40, 'rqe0zwp5IMG_3225JPG.jpg', 0, '', 0.00),
(535, 40, 'etsradffIMG_3227JPG.jpg', 0, '', 0.00),
(536, 40, '6ewwdvujIMG_3229JPG.jpg', 0, '', 0.00),
(537, 40, 't5jtdvqbIMG_3230JPG.jpg', 0, '', 0.00),
(538, 40, 'h35d078nIMG_3231JPG.jpg', 0, '', 0.00),
(539, 40, 'afuhpubbIMG_3232JPG.jpg', 0, '', 0.00),
(540, 40, 'c2uf600uIMG_3233JPG.jpg', 0, '', 0.00),
(541, 40, 'fgkqmrbvIMG_3234JPG.jpg', 0, '', 0.00),
(542, 41, 'ncdp44c4IMG_3611JPG.jpg', 0, '', 0.00),
(543, 41, '6bki73utIMG_3613JPG.jpg', 0, '', 0.00),
(544, 41, '4y5qmq3aIMG_3618JPG.jpg', 0, '', 0.00),
(545, 41, '2ks5gemvIMG_3622JPG.jpg', 0, '', 0.00),
(546, 41, 'djd8734xIMG_3624JPG.jpg', 0, '', 0.00),
(547, 41, '8pxi27tiIMG_3630JPG.jpg', 0, '', 0.00),
(548, 41, 'ujc4su0aIMG_3632JPG.jpg', 0, '', 0.00),
(549, 41, 'me7ajnvoIMG_3633JPG.jpg', 0, '', 0.00),
(550, 41, 'gw3obnxoIMG_3634JPG.jpg', 0, '', 0.00),
(551, 41, 'yr2n4gpkIMG_3637JPG.jpg', 0, '', 0.00),
(552, 41, 'eiq8amy7IMG_3638JPG.jpg', 0, '', 0.00),
(553, 41, 'uaaimeiuIMG_3641JPG.jpg', 0, '', 0.00),
(554, 41, 'k228m67iIMG_3642JPG.jpg', 0, '', 0.00),
(555, 41, 'seiq8amyIMG_3643JPG.jpg', 0, '', 0.00),
(556, 42, 'axfzy0eqIMG_0601JPG.jpg', 0, '', 0.00),
(557, 42, 'p8sv5iw2IMG_0603JPG.jpg', 0, '', 0.00),
(558, 42, 'szscgqz7IMG_0604JPG.jpg', 0, '', 0.00),
(559, 42, 'bcpohx6vIMG_0606JPG.jpg', 0, '', 0.00),
(560, 42, '6gyhx5a6IMG_0609JPG.jpg', 0, '', 0.00),
(561, 42, 'dcdh5yj8IMG_0613JPG.jpg', 0, '', 0.00),
(562, 42, 'x0znyh0wIMG_0617JPG.jpg', 0, '', 0.00),
(563, 42, 'pk2ymar0IMG_0627JPG.jpg', 0, '', 0.00),
(564, 42, 'aatxdof7IMG_0641JPG.jpg', 0, '', 0.00),
(565, 42, 'uvsck3tkIMG_0643JPG.jpg', 0, '', 0.00),
(566, 42, 'mouweimwIMG_0644JPG.jpg', 0, '', 0.00),
(567, 42, 'pm2gqs8iIMG_0662JPG.jpg', 0, '', 0.00),
(568, 42, 'fv604zooIMG_0666JPG.jpg', 0, '', 0.00),
(569, 42, 'xmh6e4ukIMG_0680JPG.jpg', 0, '', 0.00),
(570, 42, '5ei5os3rIMG_0682JPG.jpg', 0, '', 0.00),
(571, 42, 'cjkavzjiIMG_0686JPG.jpg', 0, '', 0.00),
(572, 42, 'zoac4kuvIMG_0690JPG.jpg', 0, '', 0.00),
(573, 42, 'hhu5iicoIMG_0765JPG.jpg', 0, '', 0.00),
(574, 43, 'wtcn0f02DSC_0151jpg.jpg', 0, '', 0.00),
(575, 43, '2qv5w3xgDSC_0174jpg.jpg', 0, '', 0.00),
(576, 43, 'xzmnow8qDSC_4560jpg.jpg', 0, '', 0.00),
(577, 43, 'j3fph7b8DSC_4864jpg.jpg', 0, '', 0.00),
(578, 43, 'iiu7g4sdSDC15661JPG.jpg', 0, '', 0.00),
(579, 43, '3t3wrhr3SDC15662JPG.jpg', 0, '', 0.00),
(580, 43, '66ikozyxSDC15663JPG.jpg', 0, '', 0.00),
(581, 43, 'zzj0vk7kSDC15665JPG.jpg', 0, '', 0.00),
(582, 43, 'g0jwfc4vSDC15666JPG.jpg', 0, '', 0.00),
(583, 43, 'zodhchjhSDC15667JPG.jpg', 0, '', 0.00),
(584, 43, 'bmnufaz5SDC15669JPG.jpg', 0, '', 0.00),
(585, 43, '8jnbuakgSDC15670JPG.jpg', 0, '', 0.00),
(586, 44, 'hxof6jkkSDC147211_815x543jpg.jpg', 0, '', 0.00),
(587, 45, 'wtwcyp7aIMG_0559_815x543jpg.jpg', 0, '', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `pro_categories`
--

CREATE TABLE `pro_categories` (
  `id` int(11) NOT NULL,
  `subcatid` int(11) NOT NULL,
  `seq_no` int(11) NOT NULL DEFAULT '0',
  `category_name` varchar(255) NOT NULL,
  `alias_name` text NOT NULL,
  `description` longtext NOT NULL,
  `image` text NOT NULL,
  `new_arrival` tinyint(1) NOT NULL,
  `metaTitle` text NOT NULL,
  `metaDescription` text NOT NULL,
  `metaKeywords` text NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pro_categories`
--

INSERT INTO `pro_categories` (`id`, `subcatid`, `seq_no`, `category_name`, `alias_name`, `description`, `image`, `new_arrival`, `metaTitle`, `metaDescription`, `metaKeywords`, `status`) VALUES
(1, 0, 1, 'Tax Management and Advisory', '', '<p>We offer clients a broad range of completely integrated tax services.  Our approach combines insight and innovation from multiple disciplines with business and industrial knowledge to help the client.  We assist businesses of small scale to large scale, enterprises, organizations, institutions and individuals with tax strategy, planning and compliance.  Tax implications forecasting and litigation risk mitigation are the key challenges in India and we assist the clients to carry out effective forecasting of tax implications and equip them with efficient tools of risk mitigation.  Our services include</p>\r\n<hr />\r\n<h4 class="sc_title sc_title_regular">Direct Taxes</h4>\r\n<ul class="sc_list  sc_list_style_ul">\r\n    <li class="sc_list_item">Advising on Tax Planning</li>\r\n    <li class="sc_list_item">Assistance in compliances including registrations, filing of returns etc.</li>\r\n    <li class="sc_list_item">Appearing before Authorities starting from assessing officer to ITAT, Settlement Commission and Central Board of Direct Taxes</li>\r\n    <li class="sc_list_item">Advising on Cross Border Transactions, Transfer Pricing</li>\r\n    <li class="sc_list_item">Income Tax Audit, Transfer Pricing Audit</li>\r\n</ul>\r\n<hr />\r\n<h4 class="sc_title sc_title_regular">Indirect Taxes</h4>\r\n<ul class="sc_list  sc_list_style_ul">\r\n    <li class="sc_list_item">Assistance in compliances including registrations, filing of returns etc.</li>\r\n    <li class="sc_list_item">Appearing before Authorities starting from Adjudicating Authority to CESTAT, Settlement Commission, DGCEI, DRI, ED, CERA / CAG, Central Board of Excise and Customs, VAT Tribunals, Advance Ruling Authority</li>\r\n    <li class="sc_list_item">Assisting in management and administering Departmental Audits of Service Tax and Central Excise</li>\r\n    <li class="sc_list_item">Tax Implications Forecast and Management</li>\r\n    <li class="sc_list_item">Litigation Risk Mitigation and Management</li>\r\n    <li class="sc_list_item">Customised Service Tax / Central Excise Internal Audits</li>\r\n    <li class="sc_list_item">Assistance obtaining in Refunds / Rebates</li>\r\n    <li class="sc_list_item">Conducting Training Programs for beginners, accounts staff of clients, audit teams of client as well as department, professionals</li>\r\n    <li class="sc_list_item">Assistance and representation for Determination proceedings under VAT Laws</li>\r\n    <li class="sc_list_item">VAT Audits</li>\r\n</ul>', 'Tax_Management_and_Advisory_oes5k7jr.png', 0, 'Tax Management and Advisory', 'Tax Management and Advisory', 'Tax Management and Advisory', 1),
(2, 0, 2, 'Contract Management', '', '<p>Contract is juristic form of business relationship having different types.  Every business entity would enter into a contract with others for one or other reasons.  Failures of Contracts and Contracts Failures would both lead to financial and reputational losses, disruption of work, inefficient performance in business, increasing cost of litigations, disturbances to business continuity, tax disasters and many other direct as well as indirect consequences.  In liberalised economic environment, contract is instrumental in supplementing to the need of regulatory and supervisory framework in a suitable manner.  Drafting of contract is therefore having its own significance and requires a thoughtful process.</p>\r\n<p>Many a times, contracts are drafted with standard and pre-defined terms / clauses.  Standardisation has become widespread as it significantly reduces transactional costs. Besides reduction in costs, standardisation of contracts benefits in smooth and swift negotiations of covenants of the transactions and expedites execution of contracts.</p>\r\n<p>Therefore, drafting of a contract is no more an insignificant task in todays business environment and requires in-depth understanding of regulatory framework, laws of land, common business practices and tactics, financial impacts, taxation structure, contractual and negotiational tasks and many other aspects.  We, at our firm, gained vast experience in contract drafting and witnessed many successful contractual relations.  Services includes :</p>\r\n<ul class="sc_list  sc_list_style_ul">\r\n    <li class="sc_list_item">Drafting of Contracts and related Documents</li>\r\n    <li class="sc_list_item">Review and Vetting of Contracts</li>\r\n    <li class="sc_list_item">Assistance and Advise in negotiations of Contractual Terms and Covenants</li>\r\n    <li class="sc_list_item">Monitoring and Supervision of Contractual Performance</li>\r\n    <li class="sc_list_item">Standardisation and Customisation of Contracts as per Business and Commercial requirements</li>\r\n    <li class="sc_list_item">Advisory on disputes redressal and Arbitration</li>\r\n    <li class="sc_list_item">Advisory on legal remedies and alternative solutions</li>\r\n</ul>\r\n<p>&nbsp;</p>', 'Contract_Management_isafycnq.png', 0, 'Contract Management', 'Contract Management', 'Contract Management', 1),
(4, 0, 3, 'Risk Assessment and Advisory', '', '<p>We, at our firm, work in proximity with clients to assist in management and mitigation of risk.  Our clients achieve strategic business objectives through proper risk assessment and mitigation techniques suggested and advised by professionals of our firm.  Risks are of various types and continually transforming itself into one or another form.  Continual assessment and improvisation of internal control systems are key to succeed against definite risks.  Our services in relation to risk assessment and advisory includes :</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<ul class="sc_list  sc_list_style_ul">\r\n    <li class="sc_list_item">Internal Audit</li>\r\n    <li class="sc_list_item">Pre-audit</li>\r\n    <li class="sc_list_item">Fraud / Special Investigation Audit</li>\r\n    <li class="sc_list_item">Concurrent Audit</li>\r\n    <li class="sc_list_item">Revenue / Stock Audit</li>\r\n    <li class="sc_list_item">Information Systems Audit and Risk Management</li>\r\n    <li class="sc_list_item">Forensic Audit</li>\r\n</ul>\r\n<p>&nbsp;</p>', 'Risk_Assessment_and_Advisory_03omzwt4.png', 0, 'Risk Assessment and Advisory', 'Risk Assessment and Advisory', 'Risk Assessment and Advisory', 1),
(5, 0, 4, 'Management Consultancy', '', '<p>Management Consultancy is emerging area of focus in developing countries like India.  A myopic vision is detrimental to the organizations success in the long run. We, at our firm, offer valuable insights and various alternatives that help our clients maintain the competitive edge in the longer term as well.  Our approach is structured, as well as agile to assist clients in various phases of their life cycle. Our credentials across industry sectors echo our success in understanding the business context. Being an independent advisor with extensive knowledge and experience, we can surely help clients to achieve today, what they have set out for tomorrow.</p>\r\n<p>While our professionals can provide a variety of alternatives to cater to our clients needs, we have in addition customized approaches catering to specific performance and technology related business challenges.  Our services in relation to management consultancy broadly includes :</p>\r\n<ul class="sc_list  sc_list_style_ul">\r\n    <li class="sc_list_item">Management Information System Designing and Reporting</li>\r\n    <li class="sc_list_item">Management Audit</li>\r\n    <li class="sc_list_item">Designing of Internal Controls, Systems and Processes</li>\r\n    <li class="sc_list_item">Preparation of Operations Manual</li>\r\n</ul>\r\n<p>&nbsp;</p>', 'Management_Consultancy_hjek26s0.png', 0, 'Management Consultancy', 'Management Consultancy', 'Management Consultancy', 1),
(6, 0, 5, 'Audit and Assurances', '', '<p>Services at our firm extend beyond the conventional financial reporting function.  We take time to understand clients business, their needs and blend them with the sectors in which they operate.  Around the world, the journey to success is governed by increasingly complex and broadened regulatory requirements and stakeholders expectations.  Our experts demonstrate courage and integrity to help the clients in meeting those expectations and requirements by providing timely and constructive advise to the management, a robust and clear perspective to audit committees and transparent information to the stakeholders.  Assurance given to the stakeholders in reporting frameworks, prepared by our experts and professionals, is right in the perspective and integrity.  We always endeavor to achieve consensus between what the stakeholders read and what they perceive.  Our services in relation to auditing and assurance includes :</p>\r\n<ul class="sc_list  sc_list_style_ul">\r\n    <li class="sc_list_item">Statutory Audits</li>\r\n    <li class="sc_list_item">Tax Audits</li>\r\n    <li class="sc_list_item">Compliance Audits</li>\r\n    <li class="sc_list_item">Certifications</li>\r\n    <li class="sc_list_item">Special Audits</li>\r\n</ul>\r\n<p>&nbsp;</p>', 'Audit_and_Assurances_wo8zah6t.png', 0, 'Audit and Assurances', 'Audit and Assurances', 'Audit and Assurances', 1),
(7, 0, 6, 'Business Support Services', '', '<p>Business support is the demand of developing economy.  We understand bottlenecks in support system of the organisation and provide tailor-made solutions.  \r\n\r\nFew of the services being provided by us in relation to support to an organisation includes :\r\n</p>\r\n<ul class="sc_list  sc_list_style_ul">\r\n    <li class="sc_list_item">Formation of Business - Incorporation of Company / Limited Liability Partnerships</li>\r\n    <li class="sc_list_item">Formation and registration of Partnership Firms</li>\r\n    <li class="sc_list_item">Selection and advising in relation to Trade Zones i.e. Free Trade Zone, Special Economic </li>\r\n    <li class="sc_list_item">Zones, Software Technology Parks, Electronic Hardware Technology Park etc.</li>\r\n    <li class="sc_list_item">Cost / Revenue Budgeting and Controlling</li>\r\n    <li class="sc_list_item">Cash Management</li>\r\n    <li class="sc_list_item">Inventory Planning and Control</li>\r\n    <li class="sc_list_item">Cash Managementli>\r\n    <li class="sc_list_item">Analysis of Key Financial Indicators</li>\r\n    <li class="sc_list_item">Recruitment, Evaluation, Training of Accounting and financial department personnel</li>\r\n    <li class="sc_list_item">Complete Financial Outsourcing</li>\r\n</ul>\r\n<p>&nbsp;</p>', 'Business_Support_Services_dtq0adrk.png', 0, 'Business Support Services', 'Business Support Services', 'Business Support Services', 1),
(8, 0, 7, 'Corporate Training and Continuing Education', '', '<p>Training and Continuing Education of resource persons of any organisation is key to success.  Emerging economy and rapidly changing fiscal policies require extensive training and continuing education of employees at all levels.  Our expert team mates always feel happy to provide following services :</p>\r\n<ul class="sc_list  sc_list_style_ul">\r\n    <li class="sc_list_item">Subject Level Training to Finance, Taxation and Accounting Personnel of clients</li>\r\n    <li class="sc_list_item">Formation and registration of Partnership Firms</li>\r\n    <li class="sc_list_item">Continuing Educational Workshops on current tax and financial topics</li>\r\n</ul>\r\n<p>&nbsp;</p>', 'Corporate_Training_and_Continuing_Education_vfqfxxnf.png', 0, 'Corporate Training and Continuing Education', 'Corporate Training and Continuing Education', 'Corporate Training and Continuing Education', 1),
(9, 0, 8, 'Financial Consulting and Syndication', '', '<p>Finance is a driving factor of any business.  Availability of adequate finance at appropriate cost is essential to a sustainable business ideas.  We assist our client in ensure availability of required amount of financial support in a cost effective manner.  Over and above general financial consultancy, we also provide services in respect of financial syndication by using our vast reputed experience and untainted relations.  Services includes :</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<ul class="sc_list  sc_list_style_ul">\r\n    <li class="sc_list_item">Debt Syndication to meet long term as well as short term financial needs i.e. Term Loans, Cash</li>\r\n    <li class="sc_list_item">Credit Limits, Guarantee Limits, Letters of Credit etc.</li>\r\n    <li class="sc_list_item">Planning, structurisation and execution of Private Equity options</li>\r\n    <li class="sc_list_item">Mergers and Acquisitions</li>\r\n    <li class="sc_list_item">Joint Ventures</li>\r\n    <li class="sc_list_item">Business Valuation and Feasibility Study</li>\r\n</ul>\r\n<p>&nbsp;</p>', 'Financial_Consulting_and_Syndication_b3eh0xzw.png', 0, 'Financial Consulting and Syndication', 'Financial Consulting and Syndication', 'Financial Consulting and Syndication', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sb_group`
--

CREATE TABLE `sb_group` (
  `id` int(11) NOT NULL,
  `group_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sb_group`
--

INSERT INTO `sb_group` (`id`, `group_name`, `status`) VALUES
(1, 'Friends', 1),
(2, 'Employee', 1);

-- --------------------------------------------------------

--
-- Table structure for table `social_links`
--

CREATE TABLE `social_links` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `s_link` varchar(255) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `social_links`
--

INSERT INTO `social_links` (`id`, `title`, `image`, `s_link`, `seqNo`, `status`) VALUES
(1, 'Facebook', '8cnxgxh0facebookpng.png', 'http://www.facebook.com/distinkthappeniings', 1, 1),
(2, 'Twitter', 'ya7a0ogitwitterpng.png', 'http://twitter.com/DistinktH', 2, 1),
(3, 'G+', 'nykrfwiginpng.png', 'https://plus.google.com/113741039500881285873', 3, 1),
(4, 'You Tube', '0sqk7a03you_tubepng.png', 'http://www.youtube.com/', 4, 1),
(5, 'Instagram', 'kovp4dxyrajeshjoshipng.png', 'http://www.instagram.com/DistinktHappeniings', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `test1`
--

CREATE TABLE `test1` (
  `id` int(11) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `status` int(1) NOT NULL,
  `ndate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test1`
--

INSERT INTO `test1` (`id`, `seqNo`, `name`, `image`, `description`, `status`, `ndate`) VALUES
(9, 1, 'test', 'r7qr7nef1jpg.jpg', '<p>Sed ut perspiciatis, unde omnis iste natus error sit voluptatem  accusantium doloremque laudantium, totam rem aperiam eaque ipsa, quae ab  illo inventore veritatis et quasi architecto beatae vitae dicta sunt,  explicabo. Nemo enim ipsam voluptatem...</p>', 1, '2016-12-15'),
(10, 1, 'test12tuyriuu', 'cu475ei52jpg.jpg', '<p>Sed ut perspiciatis, unde omnis iste natus error sit voluptatem  accusantium doloremque laudantium, totam rem aperiam eaque ipsa, quae ab  illo inventore veritatis et quasi architecto beatae vitae dicta sunt,  explicabo. Nemo enim ipsam voluptatem...</p>', 1, '2016-12-17');

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `group_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `group_id`, `status`) VALUES
(8, 'Manish', 'manishdhorajia@gmail.com', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `vLink` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `seqNo`, `name`, `vLink`, `status`) VALUES
(4, 0, '', 'https://www.youtube.com/watch?v=jvZONST5YIw', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminmaster`
--
ALTER TABLE `adminmaster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adminmenumgr`
--
ALTER TABLE `adminmenumgr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_comment`
--
ALTER TABLE `blog_comment`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `blog_img`
--
ALTER TABLE `blog_img`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_img`
--
ALTER TABLE `event_img`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `global_config`
--
ALTER TABLE `global_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gst_categories`
--
ALTER TABLE `gst_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menumgr`
--
ALTER TABLE `menumgr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `multiple_image_table`
--
ALTER TABLE `multiple_image_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `multiple_img`
--
ALTER TABLE `multiple_img`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `photo_category`
--
ALTER TABLE `photo_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `photo_gallery`
--
ALTER TABLE `photo_gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products1`
--
ALTER TABLE `products1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `productsbk`
--
ALTER TABLE `productsbk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `productsbk1`
--
ALTER TABLE `productsbk1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_img`
--
ALTER TABLE `product_img`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `product_imgbk1`
--
ALTER TABLE `product_imgbk1`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `pro_categories`
--
ALTER TABLE `pro_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sb_group`
--
ALTER TABLE `sb_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_links`
--
ALTER TABLE `social_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test1`
--
ALTER TABLE `test1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminmaster`
--
ALTER TABLE `adminmaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `adminmenumgr`
--
ALTER TABLE `adminmenumgr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `blog_comment`
--
ALTER TABLE `blog_comment`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `blog_img`
--
ALTER TABLE `blog_img`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `event_img`
--
ALTER TABLE `event_img`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `global_config`
--
ALTER TABLE `global_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `gst_categories`
--
ALTER TABLE `gst_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `menumgr`
--
ALTER TABLE `menumgr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `multiple_image_table`
--
ALTER TABLE `multiple_image_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `multiple_img`
--
ALTER TABLE `multiple_img`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `photo_category`
--
ALTER TABLE `photo_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `photo_gallery`
--
ALTER TABLE `photo_gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;
--
-- AUTO_INCREMENT for table `products1`
--
ALTER TABLE `products1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `productsbk`
--
ALTER TABLE `productsbk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `productsbk1`
--
ALTER TABLE `productsbk1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `product_img`
--
ALTER TABLE `product_img`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1752;
--
-- AUTO_INCREMENT for table `product_imgbk1`
--
ALTER TABLE `product_imgbk1`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=588;
--
-- AUTO_INCREMENT for table `pro_categories`
--
ALTER TABLE `pro_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `sb_group`
--
ALTER TABLE `sb_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `social_links`
--
ALTER TABLE `social_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `test1`
--
ALTER TABLE `test1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
