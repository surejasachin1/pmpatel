<?php session_start();
include('config.php');
if(isset($_POST['submit'])){

	if($_POST['Code']==$_SESSION['cap_code']){
	$mail=$_POST['email'];
		$sql=mysqli_query($con, "select * from event where email ='$mail'");
		$result = mysqli_fetch_array($sql);
		//var_dump($sql);
		//var_dump($result);
		if(count($result)>0){
		
		$pass=$_POST['txtpass'];
		//echo $result['password'];
		if($result['password']==$pass){
		$_SESSION['username']=$mail;
		$_SESSION['password']=$pass;
			echo "<script type='text/javascript'> alert('You Are Login Sucessfully');
				window.location='index1.php';</script>";
		}
		else {
		echo "<script type='text/javascript'> alert('Please Enter Correct Password');
				window.location='knwclientlogin.php';</script>";
				}
	}
	else {
		echo "<script type='text/javascript'> alert('Please Enter a Valid Email Address');
				window.location='knwclientlogin.php';</script>";
	}
	}
	else {
	echo "<script type='text/javascript'> alert('Please Enter Correct Captcha Code');
	window.location='knwclientlogin.php';</script>";
	}
}


?>
