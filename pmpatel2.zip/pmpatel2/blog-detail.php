<? include("template.php");
function main()
{ 
	include("sitecontrol/inc/clsObj.php"); 
	$objBlog->id=$_GET['id'];
	$recDet = $objBlog->selectRecById(); 
	$img=$objBlog->getImages($recDet[0]['id']);
?>
  

<div class="page_top_wrap page_top_title page_top_breadcrumbs">
				<div class="content_wrap">
					<div class="breadcrumbs">
						<a class="breadcrumbs_item home" href="index1.php">Home</a>
						<span class="breadcrumbs_delimiter"></span>
						<span class="breadcrumbs_item current">GST Blog</span>
					</div>
					<h1 class="page_title"><?=$recDet[0]['product_name'];?></h1>
				</div>
			</div>
<div class="page_content_wrap">
				<div class="content_wrap">
					<div class="content">
						
						
						<article class="post_item post_item_excerpt post has-post-thumbnail">
							<div class="post_featured">
								<div class="post_thumb" data-image="<?=BLOG_BIG_IMAGE.$img[0]['name'];?>" data-title="Image Post">
									<a class="hover_icon_link" href="<?=BLOG_BIG_IMAGE.$img[0]['name'];?>" title="">
										<img alt="Image Post" src="<?=BLOG_BIG_IMAGE.$img[0]['name'];?>">
										<div class="img-hover">
											<span class="hover_icon"> </span>
										</div>
									</a>
								</div>
							</div>
                            
							<div class="post_content clearfix">
								<h3 class="post_title">
								<a href="#" title="Image Post">
									<span class="post_icon icon-picture-boxed-2"> </span>
									Image Post
								</a>
								</h3>
								<div class="post_info">
									<span class="post_info_item post_info_posted">
										<a href="#" class="post_info_date" title="May 13, 2015">May 13, 2015</a>
									</span>
								</div>
								<div class="post_descr">
									<p><?=$recDet[0]['description'];?></p>
									
								</div>
							</div>
							<hr />
							<h4 class="sc_title sc_title_regular">Comments</h4>
							<ul class="sc_list  sc_list_style_ul">
							<? include ("config.php");
							$gid=$_GET['id'];	 
							$cmt = mysqli_query($con ,"select * from blog_comment where product_id='$gid'");
							while($res_cmt=mysqli_fetch_array($cmt)){?>
							
    <li class="sc_list_item"><?=$res_cmt['comment']?></li>
  <? } ?>
</ul>
						</article>
						<section class="comments_wrap">
							<div class="comments_form_wrap">
								<h2 class="section_title comments_form_title">Add Comment</h2>
								<div class="comments_form">
									<div id="respond" class="comment-respond">
										<h3 id="reply-title" class="comment-reply-title">
										<small>
										<a rel="nofollow" id="cancel-comment-reply-link" href="#" title="Cancel reply">Cancel reply</a>
										</small>
										</h3>
										<form action="addcomment.php" method="post" id="commentform" class="comment-form">
											<p class="comments_notes">Your email address will not be published. Required fields are marked *</p>
											<div class="columns_wrap">
												<div class="comments_field comments_author column-1_2">
													<label for="author" class="required">Name</label>
													<input id="author" name="author" type="text" placeholder="Name *" value="" size="30" aria-required="true">
													<input id="id" name="id" type="hidden" value="<?=$_GET['id'];?>" size="30" aria-required="true">
												</div>
												<div class="comments_field comments_email column-1_2">
													<label for="email" class="required">Email</label>
													<input id="email" name="email" type="text" placeholder="Email *" value="" size="30" aria-required="true">
												</div>
												<div class="comments_field comments_site column-1_2">
													<label for="url" class="optional">Website</label>
													<input id="url" name="url" type="text" placeholder="Website" value="" size="30" aria-required="true">
												</div>
											</div>
											<div class="comments_field comments_message">
												<label for="comment" class="required">Your Message</label>
												<textarea id="comment" name="comment" placeholder="Comment" aria-required="true"></textarea>
											</div>
											<p class="form-submit">
												<input name="send_comment" type="submit" id="send_comment" class="submit" value="Post Comment">
											</p>
										</form>
									</div>
								</div>
							</div>
						</section>
						
						
						
						
						

					</div>
					<div class="sidebar widget_area bg_tint_light sidebar_style_light" role="complementary">
                    <aside class="widget widget_categories">
							<h5 class="widget_title">Categories dropdown</h5>
							<label class="screen-reader-text" for="cat">Categories dropdown</label>
							<select name="cat" id="cat" class="postform">
								<option value="-1">Select Category</option>
								<option class="level-0" value="13">Accounting</option>
								<option class="level-0" value="12">Corporate Finances</option>
								<option class="level-0" value="10">Finances</option>
								<option class="level-0" value="48">Gallery</option>
								<option class="level-0" value="15">Images</option>
								<option class="level-0" value="14">Investments</option>
								<option class="level-0" value="8">Most Popular</option>
								<option class="level-0" value="11">Our Blog</option>
								<option class="level-0" value="7">Page</option>
								<option class="level-0" value="70">Post Formats</option>
								<option class="level-0" value="71">Post Formats with Sidebar</option>
								<option class="level-0" value="69">Sample Post</option>
								<option class="level-0" value="1">Uncategorized</option>
							</select>
						</aside>
						<aside class="widget widget_categories">
							<h5 class="widget_title">Categories</h5>
							<ul>
								<li class="cat-item">
									<a href="#" title="Accounting">Accounting</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Corporate Finances">Corporate Finances</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Finances">Finances</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Gallery">Gallery</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Images">Images</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Investments">Investments</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Most Popular">Most Popular</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Our Blog">Our Blog</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Page">Page</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Post Formats">Post Formats</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Post Formats with Sidebar">Post Formats with Sidebar</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Sample Post">Sample Post</a>
								</li>
								<li class="cat-item">
									<a href="#" title="Uncategorized">Uncategorized</a>
								</li>
							</ul>
						</aside>
						
						<aside class="widget widget_meta">
							<h5 class="widget_title">Meta</h5>
							<ul>
								<li>
									<a href="#" title="Log in">Log in</a>
								</li>
								<li>
									<a href="#" title="Entries RSS">Entries RSS
									</a>
								</li>
								<li>
									<a href="#" title="Comments RSS">Comments RSS
									</a>
								</li>
							</ul>
						</aside>
						<aside class="widget widget_archive">
							<h5 class="widget_title">Archives</h5>
							<ul>
								<li>
									<a href="#" title="June 2015">June
										<span>2015</span>
									</a>
								</li>
								<li>
									<a href="#" title="May 2015">May
										<span>2015</span>
									</a>
								</li>
								<li>
									<a href="#" title="April 2015">April
										<span>2015</span>
									</a>
								</li>
								<li>
									<a href="#" title="March 2015">March
										<span>2015</span>
									</a>
								</li>
							</ul>
						</aside>
						
						
						
						
						
						<aside class="widget widget_tag_cloud">
							<h5 class="widget_title">Tags</h5>
							<div class="tagcloud">
								<a href="#" title="account">account</a>
								<a href="#" title="accounting">accounting</a>
								<a href="#" title="advising">advising</a>
								<a href="#" title="advisory">advisory</a>
								<a href="#" title="business">business</a>
								<a href="#" title="calculations">calculations</a>
								<a href="#" title="family">family</a>
								<a href="#" title="finance">finance</a>
								<a href="#" title="investments">investments</a>

								<a href="#" title="money">money</a>
								<a href="#" title="pension">pension</a>
								<a href="#" title="reports">reports</a>
								<a href="#" title="sample tag">sample tag</a>
							</div>
						</aside>
					</div>
				</div>
			</div>
            
            
    
<? } ?>