<?php include("template.php"); 

function main()
{ 	
	include("sitecontrol/inc/clsObj.php");
	
		
		if((isset($_GET['pid']) && $_GET['pid']!="")  || (isset($_GET['ctid']) && $_GET['ctid']!="") || (isset($_GET['id']) && $_GET['id']!="") || (isset($_GET['cpname']) && $_GET['cpname']!="") || isset($_GET['tid']) && $_GET['tid']!='')
		{
			if(isset($_GET['pid'])){
				$objProduct->id=$_GET['pid'];
				$product = $objProduct->selectRecById();
				
			}
			elseif(isset($_GET['ctid'])){
				$objProCat->id=$_GET['ctid'];
				$category = $objProCat->selectRecById();
			}
			elseif(isset($_GET['id'])){

				$objFrontMenu->id=$_GET['id'];
				$contentDet = $objFrontMenu->selectRecById();
			}
			elseif(isset($_GET['tid'])){
				$objEvent->id=$_GET['tid'];
				$industries = $objEvent->selectRecById();
			}
			
			elseif(isset($_GET['cpname'])){
				$objProduct->alias_name=$_GET['cpname'];
				$product = $objProduct->selectRecByAlias();		
				
				$objProCat->alias_name=$_GET['cpname'];
				$category = $objProCat->selectRecByAlias();	
				
				$objFrontMenu->alias_name=$_GET['cpname'];
				$contentDet = $objFrontMenu->selectRecByAlias();	
				//echo "<pre>";	print_r($contentDet);
			}


?>
<?	
			
			if(count($product)>0){	
				include("product.php");
			}
			elseif(count($category)>0)
			{
				include("category.php");
			}
			elseif(count($industries)>0)
			{ 
				include("industry.php");
			}
			elseif(count($contentDet)>0){
				?>

<div class="page_top_wrap page_top_title page_top_breadcrumbs">
  <div class="content_wrap">
    <div class="breadcrumbs"> <a class="breadcrumbs_item home" href="index.php">Home</a> <span class="breadcrumbs_delimiter"></span> <span class="breadcrumbs_item current"><? echo $contentDet[0]['menuName'];?></span> </div>
    <h2 class="page_title"><? echo $contentDet[0]['menuName'];?></h2>
  </div>
</div>
<div class="page_content_wrap">
  <div class="content_wrap">
    <div class="content" style="width:1000px;">
      <article class="post_item post_item_single page">
        <section class="post_content"> <? echo $contentDet[0]['menuDesc'];?>
          <div> </div>
        </section>
      </article>
    </div>
  </div>
</div>
<?php
			}
	}
	
} 
?>
